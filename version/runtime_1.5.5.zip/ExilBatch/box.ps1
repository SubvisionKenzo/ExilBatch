Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ============================
# PARAMÈTRES
# ============================

# Si un argument est passé → on scanne ce dossier
if ($args.Count -gt 0) {
    $ScanPath = $args[0]
} else {
    # Sinon → dossier Utility par défaut
    $BasePath = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $ScanPath = Join-Path $BasePath "Utility"
}

if (-not (Test-Path $ScanPath)) {
    [System.Windows.Forms.MessageBox]::Show("Folder : $ScanPath")
    exit
}

# ============================
# FENÊTRE CENTRÉE
# ============================

$form = New-Object System.Windows.Forms.Form
$form.Text = "Installer"
$form.Size = New-Object System.Drawing.Size(700,200)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(25,25,25)
$form.FormBorderStyle = "FixedDialog"
$form.TopMost = $false   # Peut aller en arrière-plan
$form.MaximizeBox = $false
$form.MinimizeBox = $false

# ============================
# BARRE DE PROGRESSION
# ============================

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Width = 630
$progress.Height = 28
$progress.Style = "Continuous"
$progress.ForeColor = "Green"
$progress.Location = New-Object System.Drawing.Point(25,40)
$form.Controls.Add($progress)

# ============================
# TEXTE EN DESSOUS
# ============================

$label = New-Object System.Windows.Forms.Label
$label.ForeColor = "White"
$label.Font = New-Object System.Drawing.Font("Segoe UI", 12)
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(25,90)
$form.Controls.Add($label)

$form.Show()
$form.Refresh()

# ============================
# SCAN DES FICHIERS
# ============================

$items = Get-ChildItem -Recurse $ScanPath
$total = $items.Count
$i = 0

foreach ($item in $items) {

    $i++
    $percent = [math]::Round(($i / $total) * 100)

    # Mise à jour barre
    $progress.Value = $percent

    # Mise à jour texte
    if ($item.PSIsContainer) {
        $label.Text = "Output Folder : $($item.FullName)"
    } else {
        $label.Text = "Output File : $($item.FullName)"
    }

    # Rafraîchir
    $form.Refresh()

    Start-Sleep -Milliseconds 50
}

# ============================
# FERMETURE AUTOMATIQUE
# ============================

Start-Sleep -Milliseconds 300
$form.Close()