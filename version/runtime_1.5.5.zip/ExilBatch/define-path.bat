@echo off
set "pathToAdd=C:\ECB\Utility"

echo %PATH% | findstr /I "%pathToAdd%" >nul
if %errorlevel%==0 (
    exit
) else (
    setx PATH "%PATH%;%pathToAdd%"
)
exit