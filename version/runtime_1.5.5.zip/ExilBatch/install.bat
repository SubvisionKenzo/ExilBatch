@echo off
cd /d "%~dp0"
set "TARGET=%~1"
:: Varriable !
set "name=box"
set "hide=hidden"
setlocal enabledelayedexpansion

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min install.bat %TARGET%
exit
:execut
del %hide%.txt
:: Execution !
pushd "utility/config"
if "%~1"=="" (
    start install.bat
) else (
    echo install.bat %1
    start install.bat %1
    set "target=%1/utility"
)
cd /d "%~dp0"
timeout 1 > nul
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" %target%
cd ..\..
:end
exit > nul