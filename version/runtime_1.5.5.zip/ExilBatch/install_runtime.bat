@echo off
setlocal enabledelayedexpansion

echo ============================
echo   ECB INSTALLER RUNTIME !
echo ============================
echo.

:: 1. Chemin du script
set "BASE=%~dp0"

:: 2. Dossier source = utility

if "%~1"=="" (
    set "SOURCE=%BASE%utility"
) else (
    set "SOURCE=%~1\utility"
)

if not exist "%SOURCE%" (
    echo ERREUR : Le dossier utility/ est introuvable !
    exit /b
)

:: 3. Lire target.txt
if not exist "%BASE%target.txt" (
    echo ERREUR : target.txt introuvable !
    exit /b
)

set /p TARGET=<"%BASE%target.txt"

if "%TARGET%"=="" (
    echo ERREUR : target.txt est vide !
    exit /b
)

echo Installation Directory : %TARGET%
echo.

if not exist "%TARGET%" mkdir "%TARGET%"

:: 4. Charger skip.txt
set "SKIPLIST="

if exist "%BASE%skip.txt" (
    for /f "usebackq delims=" %%A in ("%BASE%skip.txt") do (
        set "SKIPLIST=!SKIPLIST!;%%A"
    )
)

echo Skip : %SKIPLIST%
echo.

echo Installing...
echo.

:: 5. Copier tout sauf exclusions
for /r "%SOURCE%" %%F in (*) do (
    set "FULL=%%F"

    :: Chemin relatif = FULL sans "SOURCE\"
    set "REL=%%F"
    set "REL=!REL:%SOURCE%\=!"

    set "SKIP=0"

    :: V�rifier exclusions
    for %%S in (!SKIPLIST!) do (
        echo %%F | find /i "%%S" >nul
        if not errorlevel 1 set "SKIP=1"
    )

    if !SKIP!==0 (
        echo + Copied : !REL!

        :: Cr�er les sous-dossiers
        for %%D in ("%TARGET%\!REL!") do (
            if not exist "%%~dpD" mkdir "%%~dpD"
        )

        :: Copier le fichier
        copy "%%F" "%TARGET%\!REL!" >nul
    ) else (
        echo - Skipped : !REL!
    )
)

echo.
echo Installation Successful !
cd %TARGET%\config
echo %TARGET%
start install.bat 
regedit /s config.reg
start lang.bat
exit /b
