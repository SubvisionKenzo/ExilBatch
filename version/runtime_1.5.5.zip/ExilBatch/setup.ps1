Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# Détection langue Windows
$Lang = (Get-Culture).TwoLetterISOLanguageName

# ============================
# CONFIG
# ============================

$BasePath    = Split-Path -Parent $MyInvocation.MyCommand.Definition
$LicenseFile = Join-Path $BasePath "licence.txt"
$SideImage   = Join-Path $BasePath "logo.png"
$InstallBat  = Join-Path $BasePath "install.bat"
$IconFile    = Join-Path $BasePath "setup.ico"

$InstallPath = "C:\ECB"

# ============================
# DETECTION THEME WINDOWS
# ============================

$ThemeKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
$IsLight = 1

try {
    $IsLight = (Get-ItemProperty -Path $ThemeKey -Name AppsUseLightTheme).AppsUseLightTheme
} catch {}

$DarkMode = ($IsLight -eq 0)

# ============================
# DETECTION LANGUE WINDOWS
# ============================

$Lang = (Get-Culture).TwoLetterISOLanguageName

switch ($Lang) {
    "fr" { $L = "FR" }
    "es" { $L = "ES" }
    default { $L = "EN" }
}

# ============================
# CHARGEMENT DES LANGUES
# ============================

function Load-LanguageFile {
    param($langCode)

    $langFile = Join-Path $BasePath "lang\$langCode.lang"

    if (-not (Test-Path $langFile)) {
        $langFile = Join-Path $BasePath "lang\EN.lang"
    }

    $Global:LANGDATA = @{}

    foreach ($line in Get-Content $langFile) {
        if ($line -match "^\s*$") { continue }
        if ($line -match "^\s*#") { continue }
        $parts = $line -split "=", 2
        if ($parts.Count -eq 2) {
            $Global:LANGDATA[$parts[0]] = $parts[1]
        }
    }
}

function T {
    param($key)
    if ($Global:LANGDATA.ContainsKey($key)) {
        return $Global:LANGDATA[$key]
    }
    return $key
}


# Charger la langue détectée
Load-LanguageFile $L

# ============================
# FENÊTRE PRINCIPALE
# ============================

$form = New-Object Windows.Forms.Form
$form.Text = "ECB setup installation"
$form.Size = New-Object Drawing.Size(630, 480)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [Drawing.Color]::White

if (Test-Path $IconFile) {
    $form.Icon = New-Object System.Drawing.Icon($IconFile)
}

if ($DarkMode) {

    # Couleurs principales
    $bgDark  = [Drawing.Color]::FromArgb(25,25,25)
    $bgPanel = [Drawing.Color]::FromArgb(35,35,35)
    $bgInput = [Drawing.Color]::FromArgb(45,45,45)
    $bgMode = [Drawing.Color]::FromArgb(250,250,250)
    $fgText  = [Drawing.Color]::White

    # Fenêtre
    $form.BackColor = $bgMode
    $form.ForeColor = $bgDark

    # Bande gauche
    $panelLeft.BackColor = $bgPanel

    # Footer
    $footer.BackColor = $bgPanel
    $line.BackColor = $bgPanel

    # Pages
    foreach ($p in @($page1,$page2,$page3,$page4,$page5)) {
        $p.BackColor = $bgDark
        $p.ForeColor = $fgText
    }

    # Tous les contrôles
    $allControls = @(
        $form.Controls,
        $panelMain.Controls,
        $page1.Controls,
        $page2.Controls,
        $page3.Controls,
        $page4.Controls,
        $page5.Controls
    )

    foreach ($group in $allControls) {
        foreach ($ctrl in $group) {

            # Labels
            if ($ctrl -is [System.Windows.Forms.Label]) {
                $ctrl.ForeColor = $fgText
                $ctrl.BackColor = $bgDark
            }

            # TextBox
            if ($ctrl -is [System.Windows.Forms.TextBox]) {
                $ctrl.BackColor = $bgInput
                $ctrl.ForeColor = $fgText
                $ctrl.BorderStyle = 'FixedSingle'
            }

            # Buttons
            if ($ctrl -is [System.Windows.Forms.Button]) {
                $ctrl.BackColor = $bgPanel
                $ctrl.ForeColor = $fgText
                $ctrl.FlatStyle = 'Flat'
                $ctrl.FlatAppearance.BorderColor = $fgText
            }

            # RadioButtons & CheckBoxes
            if ($ctrl -is [System.Windows.Forms.RadioButton] -or
                $ctrl -is [System.Windows.Forms.CheckBox]) {

                $ctrl.ForeColor = $fgText
                $ctrl.BackColor = $bgDark
            }

            # Panels
            if ($ctrl -is [System.Windows.Forms.Panel]) {
                $ctrl.BackColor = $bgDark
            }
        }
    }
}

# ============================
# BANDE GAUCHE
# ============================

$panelLeft = New-Object Windows.Forms.Panel
$panelLeft.Width = 160
$panelLeft.Dock  = 'Left'
$panelLeft.BackColor = [Drawing.Color]::FromArgb(230,230,230)
$form.Controls.Add($panelLeft)

if (Test-Path $SideImage) {
    $pic = New-Object Windows.Forms.PictureBox
    $pic.Image = [System.Drawing.Image]::FromFile($SideImage)
    # $pic.SizeMode = 'StretchImage'
    $pic.Dock = 'Fill'
    $panelLeft.Controls.Add($pic)
}

# ============================
# BANDE BAS
# ============================

$footer = New-Object Windows.Forms.Panel
$footer.Height = 55
$footer.Dock   = 'Bottom'
$footer.BackColor = [Drawing.Color]::FromArgb(230,230,230)
$form.Controls.Add($footer)

$line = New-Object Windows.Forms.Label
$line.BorderStyle = 'Fixed3D'
$line.Height = 2
$line.Dock   = 'Top'
$form.Controls.Add($line)


# ============================
# BOUTONS (séparés)
# ============================

# Page 1
$btnNext1 = New-Object Windows.Forms.Button
$btnNext1.Text = T "BTN_NEXT"
$btnNext1.Size = "70,28"
$btnNext1.Location = "420,13"
$footer.Controls.Add($btnNext1)

# Page 2
$btnBack2 = New-Object Windows.Forms.Button
$btnBack2.Text = T "BTN_BACK"
$btnBack2.Size = "70,28"
$btnBack2.Location = "300,13"
$btnBack2.Visible = $false
$footer.Controls.Add($btnBack2)

$btnNext2 = New-Object Windows.Forms.Button
$btnNext2.Text = T "BTN_NEXT"
$btnNext2.Size = "70,28"
$btnNext2.Location = "420,13"
$btnNext2.Visible = $false
$footer.Controls.Add($btnNext2)

# Page 3
$btnBack3 = New-Object Windows.Forms.Button
$btnBack3.Text = T "BTN_BACK"
$btnBack3.Size = "70,28"
$btnBack3.Location = "300,13"
$btnBack3.Visible = $false
$footer.Controls.Add($btnBack3)

# Page 5
$btnBack5 = New-Object Windows.Forms.Button
$btnBack5.Text = T "BTN_BACK"
$btnBack5.Size = "70,28"
$btnBack5.Location = "300,13"
$btnBack5.Visible = $false
$footer.Controls.Add($btnBack5)

$btnFinish = New-Object Windows.Forms.Button
$btnFinish.Text = T "BTN_INSTALL"
$btnFinish.Size = "70,28"
$btnFinish.Location = "420,13"
$btnFinish.Visible = $false
$footer.Controls.Add($btnFinish)

$btnInstall = New-Object Windows.Forms.Button
$btnInstall.Text = T "BTN_NEXT"
$btnInstall.Size = "70,28"
$btnInstall.Location = "420,13"
$btnInstall.Visible = $false
$footer.Controls.Add($btnInstall)

# Bouton Annuler
$btnCancel = New-Object Windows.Forms.Button
$btnCancel.Text = T "BTN_CANCEL"
$btnCancel.Size = "70,28"
$btnCancel.Location = "500,13"
$footer.Controls.Add($btnCancel)
$btnCancel.Add_Click({ $form.Close() })

# ============================
# PANNEAU CENTRAL
# ============================

$panelMain = New-Object Windows.Forms.Panel
$panelMain.Left   = 170
$panelMain.Top    = 10
$panelMain.Width  = 520
$panelMain.Height = 380
$form.Controls.Add($panelMain)

# ============================
# PAGE 1 : BIENVENUE
# ============================

$page1 = New-Object Windows.Forms.Panel
$page1.Dock = 'Fill'
$page1.BackColor = 'White'

$lbl1 = New-Object Windows.Forms.Label
$lbl1.Text = T "WELCOME_SETUP"
$lbl1.Font = New-Object Drawing.Font("Segoe UI", 14, [Drawing.FontStyle]::Bold)
$lbl1.AutoSize = $true
$lbl1.Location = "10,20"
$page1.Controls.Add($lbl1)

$lbl1b = New-Object Windows.Forms.Label
$lbl1b.Text = T "MSG_SETUP_INSTALL"
$lbl1b.Font = New-Object Drawing.Font("Segoe UI", 10)
$lbl1b.AutoSize = $true
$lbl1b.Location = "10,60"
$page1.Controls.Add($lbl1b)

# ============================
# LIEN CLIQUABLE (style Windows)
# ============================

$link = New-Object Windows.Forms.Label
$link.Text = T "OPEN_WEBSITE"   # phrase traduite dans tes fichiers .lang
$link.Font = New-Object Drawing.Font("Segoe UI", 9, [Drawing.FontStyle]::Underline)
$link.ForeColor = [Drawing.Color]::FromArgb(0, 102, 204)   # bleu style lien
$link.AutoSize = $true
$link.Location = "10,300"
$link.Cursor = [System.Windows.Forms.Cursors]::Hand

# Effet hover (survol)
$link.Add_MouseEnter({
    $link.ForeColor = [Drawing.Color]::FromArgb(30, 144, 255)
})
$link.Add_MouseLeave({
    $link.ForeColor = [Drawing.Color]::FromArgb(0, 102, 204)
})

# Action au clic → ouvrir index.html
$link.Add_Click({
    $htmlFile = Join-Path $BasePath "link\index.html"
    if (Test-Path $htmlFile) {
        Start-Process $htmlFile   # ouvre avec le navigateur par défaut
    } else {
        [System.Windows.Forms.MessageBox]::Show("index.html not found in /link/")
    }
})

$page1.Controls.Add($link)

$panelMain.Controls.Add($page1)

# ============================
# PAGE 2 : LICENCE
# ============================

$page2 = New-Object Windows.Forms.Panel
$page2.Dock = 'Fill'
$page2.BackColor = 'White'
$page2.Visible = $false

$lbl2 = New-Object Windows.Forms.Label
$lbl2.Text = T "LICENSE_TITLE"
$lbl2.Font = New-Object Drawing.Font("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$lbl2.AutoSize = $true
$lbl2.Location = "10,10"
$page2.Controls.Add($lbl2)

$txtLicense = New-Object Windows.Forms.TextBox
$txtLicense.Multiline = $true
$txtLicense.ScrollBars = 'Vertical'
$txtLicense.ReadOnly = $true
$txtLicense.Size = "430,260"
$txtLicense.Location = "10,40"
$txtLicense.Font = New-Object Drawing.Font("Segoe UI", 9)

if (Test-Path $LicenseFile) {
    $txtLicense.Text = Get-Content $LicenseFile -Raw
} else {
    $txtLicense.Text = "Not found licence.txt"
}

$page2.Controls.Add($txtLicense)

$rbAccept = New-Object Windows.Forms.RadioButton
$rbAccept.Text = "Agree"
$rbAccept.Location = "10,310"
$page2.Controls.Add($rbAccept)

$rbDecline = New-Object Windows.Forms.RadioButton
$rbDecline.Text = "Decline"
$rbDecline.Location = "10,335"
$page2.Controls.Add($rbDecline)

$panelMain.Controls.Add($page2)

# ============================
# PAGE 3 : RÉSUMÉ
# ============================

$page3 = New-Object Windows.Forms.Panel
$page3.Dock = 'Fill'
$page3.BackColor = 'White'
$page3.Visible = $false

$lbl3 = New-Object Windows.Forms.Label
$lbl3.Text = T "READY_INSTALL"
$lbl3.Font = New-Object Drawing.Font("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$lbl3.AutoSize = $true
$lbl3.Location = "10,20"
$page3.Controls.Add($lbl3)

$lbl3b = New-Object Windows.Forms.Label
$lbl3b.Text = "ECB default directory :`n$InstallPath"
$lbl3b.Font = New-Object Drawing.Font("Segoe UI", 10)
$lbl3b.AutoSize = $true
$lbl3b.Location = "10,60"
$page3.Controls.Add($lbl3b)

# Checkbox pour activer le chemin personnalisé
$cbCustomPath = New-Object Windows.Forms.CheckBox
$cbCustomPath.Text = T "USE_CUSTOM_PATH"
$cbCustomPath.Location = "10,120"
$page3.Controls.Add($cbCustomPath)

# TextBox pour entrer le chemin
$txtCustomPath = New-Object Windows.Forms.TextBox
$txtCustomPath.Size = "300,25"
$txtCustomPath.Location = "30,150"
$txtCustomPath.Enabled = $false
$page3.Controls.Add($txtCustomPath)

# Bouton "..." pour choisir un dossier
$btnBrowse = New-Object Windows.Forms.Button
$btnBrowse.Text = "..."
$btnBrowse.Size = "30,23"
$btnBrowse.Location = "340,149"
$btnBrowse.Enabled = $false
$page3.Controls.Add($btnBrowse)

# Texte d’avertissement (multi-langue)
$lblWarning = New-Object Windows.Forms.Label
$lblWarning.SizeMode = "StretchImage"
$lblWarning.Text = T "CUSTOM_PATH_WARNING"
$lblWarning.Font = New-Object Drawing.Font("Segoe UI", 8)
$lblWarning.Location = New-Object Drawing.Point(10 + 14 + 4, 185)
$lblWarning.AutoSize = $true
$lblWarning.ForeColor = "Red"
$lblWarning.Location = "30,185"
$lblWarning.Visible = $false
$page3.Controls.Add($lblWarning)

$panelMain.Controls.Add($page3)

# ============================
# PAGE 4 : PROGRESSION
# ============================

$page4 = New-Object Windows.Forms.Panel
$page4.Dock = 'Fill'
$page4.BackColor = 'White'
$page4.Visible = $false

$lbl4 = New-Object Windows.Forms.Label
$lbl4.Text = "Initializing installation..."
$lbl4.Font = New-Object Drawing.Font("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$lbl4.AutoSize = $true
$lbl4.Location = "10,20"
$page4.Controls.Add($lbl4)

$progress = New-Object Windows.Forms.ProgressBar
$progress.Size = "320,22"
$progress.Location = "10,60"
$page4.Controls.Add($progress)

$lbl4b = New-Object Windows.Forms.Label
$lbl4b.Text = "Please wait."
$lbl4b.Font = New-Object Drawing.Font("Segoe UI", 9)
$lbl4b.AutoSize = $true
$lbl4b.Location = "10,90"
$page4.Controls.Add($lbl4b)

$panelMain.Controls.Add($page4)

# ============================
# PAGE 5 : CHOIX INSTALLATION
# ============================

$page5 = New-Object Windows.Forms.Panel
$page5.Dock = 'Fill'
$page5.BackColor = 'White'
$page5.Visible = $false

$lbl5 = New-Object Windows.Forms.Label
$lbl5.Text = T "CHOSE_INSTALLATION_TYPE"
$lbl5.Font = New-Object Drawing.Font("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$lbl5.AutoSize = $true
$lbl5.Location = "10,20"
$page5.Controls.Add($lbl5)

$rbFull = New-Object Windows.Forms.RadioButton
$rbFull.Text = T "INSTALL_SOFTWARE"
$rbFull.Location = "10,90"
$rbFull.Checked = $true   # sélection par défaut
$page5.Controls.Add($rbFull)

$rbRuntime = New-Object Windows.Forms.RadioButton
$rbRuntime.Text = T "INSTALL_RUNTIME"
$rbRuntime.Location = "10,130"
$page5.Controls.Add($rbRuntime)

$rbUSB = New-Object Windows.Forms.RadioButton
$rbUSB.Text = T "INSTALL_USB"
$rbUSB.Location = "10,170"
$page5.Controls.Add($rbUSB)

# Checkbox fonctionnalité
$cbFeature = New-Object Windows.Forms.CheckBox
$cbFeature.Text = T "FEATURE_NAME"
$cbFeature.Location = "10,220"
$page5.Controls.Add($cbFeature)

# Description sous la checkbox
$lblFeatureDesc = New-Object Windows.Forms.Label
$lblFeatureDesc.Text = T "FEATURE_DESC"
$lblFeatureDesc.Font = New-Object Drawing.Font("Segoe UI", 9)
$lblFeatureDesc.AutoSize = $true
$lblFeatureDesc.MaximumSize = New-Object System.Drawing.Size(300,0)
$lblFeatureDesc.Location = "30,250"
$page5.Controls.Add($lblFeatureDesc)

$panelMain.Controls.Add($page5)

# ============================
# ICONES À CÔTÉ DES MODES
# ============================

$IconFull    = Join-Path $BasePath "utility\assets\ICO\full.png"
$IconRuntime = Join-Path $BasePath "utility\assets\ICO\runtime.png"
$IconUSB     = Join-Path $BasePath "utility\assets\ICO\usb.png"

# Icône FULL
if (Test-Path $IconFull) {
    $picFull = New-Object System.Windows.Forms.PictureBox
    $picFull.Image = [System.Drawing.Image]::FromFile($IconFull)
    $picFull.SizeMode = "StretchImage"
    $picFull.Size = "24,24"
    $picFull.Location = "10,88"   # juste à gauche du RadioButton
    $page5.Controls.Add($picFull)

    # Décale le RadioButton un peu à droite
    $rbFull.Location = "40,90"
}

# Icône RUNTIME
if (Test-Path $IconRuntime) {
    $picRuntime = New-Object System.Windows.Forms.PictureBox
    $picRuntime.Image = [System.Drawing.Image]::FromFile($IconRuntime)
    $picRuntime.SizeMode = "StretchImage"
    $picRuntime.Size = "24,24"
    $picRuntime.Location = "10,128"
    $page5.Controls.Add($picRuntime)

    $rbRuntime.Location = "40,130"
}

# Icône USB
if (Test-Path $IconUSB) {
    $picUSB = New-Object System.Windows.Forms.PictureBox
    $picUSB.Image = [System.Drawing.Image]::FromFile($IconUSB)
    $picUSB.SizeMode = "StretchImage"
    $picUSB.Size = "24,24"
    $picUSB.Location = "10,168"
    $page5.Controls.Add($picUSB)

    $rbUSB.Location = "40,170"
}

$cbCustomPath.Add_CheckedChanged({
    $txtCustomPath.Enabled = $cbCustomPath.Checked
    $btnBrowse.Enabled = $cbCustomPath.Checked
    $lblWarning.Visible = $cbCustomPath.Checked
})

$btnBrowse.Add_Click({
    $folder = New-Object System.Windows.Forms.FolderBrowserDialog
    $folder.Description = T "SELECT_FOLDER"

    if ($folder.ShowDialog() -eq "OK") {
        $txtCustomPath.Text = $folder.SelectedPath
    }
})

# ============================
# LOGIQUE DES BOUTONS
# ============================

# PAGE 1 → PAGE 2
$btnNext1.Add_Click({
    $page1.Visible = $false
    $page2.Visible = $true

    $btnNext1.Visible = $false
    $btnBack2.Visible = $true
    $btnNext2.Visible = $true
})

# PAGE 2 → PAGE 1
$btnBack2.Add_Click({
    $page2.Visible = $false
    $page1.Visible = $true

    $btnBack2.Visible = $false
    $btnNext2.Visible = $false
    $btnNext1.Visible = $true
})

# PAGE 2 → PAGE 3
$btnNext2.Add_Click({
    if (-not $rbAccept.Checked) {
        [System.Windows.Forms.MessageBox]::Show("You can't install if you chose decline!")
        return
    }

    $page2.Visible = $false
    $page3.Visible = $true

    $btnBack2.Visible = $false
    $btnNext2.Visible = $false

    $btnBack3.Visible = $true
    $btnInstall.Visible = $true
})

# PAGE 3 → PAGE 2
$btnBack3.Add_Click({
    $page3.Visible = $false
    $page2.Visible = $true

    $btnBack3.Visible = $false
    $btnInstall.Visible = $false

    $btnBack2.Visible = $true
    $btnNext2.Visible = $true
})

$btnBack5.Add_Click({
    $page5.Visible = $false
    $page3.Visible = $true

    $btnBack5.Visible = $false
    $btnFinish.Visible = $false

    $btnBack3.Visible = $true
    $btnInstall.Visible = $true
})

# PAGE 3 -> PAGE 4 (INSTALLATION)

# Si chemin personnalisé activé → on remplace InstallPath
if ($cbCustomPath.Checked -and $txtCustomPath.Text -ne "") {
    $Global:InstallPath = $txtCustomPath.Text
}

# PAGE -> PAGE 5
$btnInstall.Add_Click({
    $page3.Visible = $false
    $page5.Visible = $true

    $btnBack3.Visible = $false
    $btnInstall.Visible = $false

    $btnBack5.Visible = $true
    $btnFinish.Visible = $true
})

$btnFinish.Add_Click({
    if ($cbFeature.Checked) {
        $fileToRun = Join-Path $BasePath "define-path.bat"
        if (Test-Path $fileToRun) {
            Start-Process $fileToRun
        }
    }

    # Choix du script
    if ($rbUSB.Checked) {

        # Sélecteur de dossier USB
        $folder = New-Object System.Windows.Forms.FolderBrowserDialog
        $folder.Description = "Select your USB drive"
        $folder.ShowNewFolderButton = $false

        if ($folder.ShowDialog() -ne "OK") {
            [System.Windows.Forms.MessageBox]::Show("USB installation cancelled.")
            return
        }

        $usbPath = $folder.SelectedPath

        # Script USB
        $scriptToRun = Join-Path $BasePath "usb.install.bat"

        if (-not (Test-Path $scriptToRun)) {
            [System.Windows.Forms.MessageBox]::Show("USB installation file missing: $scriptToRun")
            return
        }

        # Lancer le script USB avec argument
        Start-Process $scriptToRun -ArgumentList "`"$usbPath`""

        # Fermer immédiatement
        $form.Close()
        return
    }

    # Choix du script normal
    if ($rbRuntime.Checked) {
        $scriptToRun = Join-Path $BasePath "install_runtime.bat"
    } else {
        $scriptToRun = Join-Path $BasePath "install.bat"
    }

    if (-not (Test-Path $scriptToRun)) {
        [System.Windows.Forms.MessageBox]::Show("Installation file missing: $scriptToRun")
        return
    }

    # Passer à la page 4 (progression)
    $page5.Visible = $false
    $page4.Visible = $true

    $btnBack5.Visible = $false
    $btnFinish.Visible = $false
    $btnCancel.Enabled = $false

    # Lancer le script choisi
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $scriptToRun

    # Si chemin personnalisé → on passe l’argument
    if ($cbCustomPath.Checked -and $txtCustomPath.Text -ne "") {
        $path = $txtCustomPath.Text
        $psi.Arguments = '"' + $path + '"'
    }
    $psi.WorkingDirectory = $BasePath
    $psi.UseShellExecute = $true

    $proc = [System.Diagnostics.Process]::Start($psi)

    # Barre de progression
    $timer = New-Object Windows.Forms.Timer
    $timer.Interval = 300

    $timer.Add_Tick({
        if (-not $proc.HasExited) {
            if ($progress.Value -lt 100) { $progress.Value += 2 }
        }
        else {
            $timer.Stop()
            $form.Close()
        }
    })
    $form.Close()
    $timer.Start()
})

# ============================
# LANCEMENT
# ============================

(New-Object System.Media.SoundPlayer "C:\Windows\Media\Windows Notify Calendar.wav").Play()
$form.ShowDialog()
