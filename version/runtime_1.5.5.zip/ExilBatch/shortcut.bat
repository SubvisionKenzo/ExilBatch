@echo off
cd /d "%~dp0"
set "base=%cd%"
:: 1 = chemain + nom 2 = chemain de l'application 3 chemain de l'icone !
cd ..
set "basepath=%cd%"
cd %base%\utility
set "ICO=%cd%\icon\editor.ico"
cd config
PowerShell -ExecutionPolicy Bypass -File autoshortcut.ps1 "%basepath%" "%cd%\portable software\starter.cmd" "%ICO%"
exit