@echo off
setlocal enabledelayedexpansion

cd "%~dp0"

mkdir %1/ExilBatch

xcopy "utility" "%1/ExilBatch" /E /I
shortcut.bat
exit