@echo off
setlocal enabledelayedexpansion
set "json=%~1"
cd ..
powershell -NoLogo -ExecutionPolicy Bypass -File "%base%wingui.ps1" "%json%"
exit