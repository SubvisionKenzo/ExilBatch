@echo off
cd ..
notif.bat %*
exit