@echo off
cd ..
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0use.ps1" %*
exit