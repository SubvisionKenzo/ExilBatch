@echo off
cd /d "%~dp0"
:: Varriable !
set "name=panel"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min Panel.bat
exit
:execut
del %hide%.txt
:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
set ERR=%ERRORLEVEL%

:: V�rifier si PowerShell a plant�
if %ERR% NEQ 0 (
    start panel.vbs
    exit /b
)
exit > nul