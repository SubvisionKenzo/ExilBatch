Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Lecture du fichier de langue ---
$langFile = "panel.dialog.txt"
$lang = @{}

foreach ($line in Get-Content $langFile) {
    if ($line -match "^(.*)=(.*)$") {
        $lang[$matches[1]] = $matches[2]
    }
}

# --- Lecture du fichier settings.txt ---
$settingsFile = "settings.txt"
$settings = @()

foreach ($line in Get-Content $settingsFile) {
    if ($line -match "^(.*)=(.*)$") {
        $settings += @{
            name = $matches[1]
            value = [int]$matches[2]
        }
    }
}

# --- Fonction pour r��crire settings.txt ---
function Save-Settings {
    $out = ""
    foreach ($s in $settings) {
        $out += "$($s.name)=$($s.value)`n"
    }
    Set-Content -Path $settingsFile -Value $out
}

# --- Lecture du th�me ---
$themeFile = "..\assets\save\themesbar.txt"
$themeColor = "#0078D7"   # bleu par d�faut

if (Test-Path $themeFile) {
    $raw = (Get-Content $themeFile | Select-Object -First 1).Trim()
    if ($raw -match "^#([0-9A-Fa-f]{6})$") {
        $themeColor = $raw
    }
}

if ($themeColor -eq "#262626") {
    $themeColor = "#0078D7"   # bleu Windows
}

# Convertir hex ? couleur .NET
function Convert-HexColor($hex) {
    $r = [Convert]::ToInt32($hex.Substring(1,2),16)
    $g = [Convert]::ToInt32($hex.Substring(3,2),16)
    $b = [Convert]::ToInt32($hex.Substring(5,2),16)
    return [System.Drawing.Color]::FromArgb($r,$g,$b)
}

$ThemeBrush = Convert-HexColor $themeColor

# --- Fen�tre principale ---
$baseHeight = 250
$perSetting = 55
$formHeight = $baseHeight + ($settings.Count * $perSetting)

$form = New-Object System.Windows.Forms.Form
$form.Text = $lang["Title"]
$form.Size = New-Object System.Drawing.Size(500, $formHeight)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(25,25,25)
$form.ForeColor = [System.Drawing.Color]::White

# --- Bandeau violet ---
$header = New-Object System.Windows.Forms.Panel
$header.Size = New-Object System.Drawing.Size(500, 50)
$header.Location = New-Object System.Drawing.Point(0,0)
$header.BackColor = [System.Drawing.Color]::FromArgb(120, 0, 255)
$form.Controls.Add($header)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = $lang["Title"]
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = [System.Drawing.Color]::White
$titleLabel.Location = New-Object System.Drawing.Point(15, 10)
$titleLabel.AutoSize = $true
$header.Controls.Add($titleLabel)

# --- Cr�ation dynamique des boutons ---
$y = 70

foreach ($setting in $settings) {

    # Label
    $label = New-Object System.Windows.Forms.Label
    $label.Text = "> $($setting.name)"
    $label.Location = New-Object System.Drawing.Point(20, $y)
    $label.Size = New-Object System.Drawing.Size(200, 30)
    $label.ForeColor = [System.Drawing.Color]::White
    $label.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($label)

    # Switch
    $btn = New-Object System.Windows.Forms.Button
    $btn.Location = New-Object System.Drawing.Point(300, $y)
    $btn.Size = New-Object System.Drawing.Size(80, 30)
    $btn.FlatStyle = "Flat"
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)

    # Style initial
    if ($setting.value -eq 1) {
        $btn.Text = "ON"
        $btn.BackColor = $ThemeBrush
    } else {
        $btn.Text = "OFF"
        $btn.BackColor = [System.Drawing.Color]::FromArgb(80,80,80)
    }

    # La cl� : attacher la variable au bouton
    $btn.Tag = $setting

    # L'�v�nement qui marche � 100%
    $btn.Add_Click({
        param($sender, $event)

        # Le bouton r�ellement cliqu�
        $button = $sender

        # La variable associ�e � CE bouton
        $ref = $button.Tag

        if ($ref.value -eq 1) {
            $ref.value = 0
            $button.Text = "OFF"
            $button.BackColor = [System.Drawing.Color]::FromArgb(80,80,80)
        } else {
            $ref.value = 1
            $button.Text = "ON"
            $button.BackColor = $ThemeBrush
        }

        Save-Settings
    })

    $form.Controls.Add($btn)

    $y += 50
}

# --- Bouton ouvrir settings.txt dans le bandeau ---
$openBtn = New-Object System.Windows.Forms.Button
$openBtn.Text = $lang["OpenSettings"]
$openBtn.Location = New-Object System.Drawing.Point(300, 10)
$openBtn.Size = New-Object System.Drawing.Size(170, 30)
$openBtn.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
$openBtn.ForeColor = [System.Drawing.Color]::White
$openBtn.FlatStyle = "Flat"
$openBtn.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$openBtn.Add_Click({
    Start-Process notepad.exe $settingsFile
})
$header.Controls.Add($openBtn)

# --- Bouton langue ---
# --- Bouton langue ---
$langBtn = New-Object System.Windows.Forms.Button
$langBtn.Text = $lang["LangButton"]
$langBtn.Location = New-Object System.Drawing.Point(148, 10)
$langBtn.Size = New-Object System.Drawing.Size(150, 30)
$langBtn.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
$langBtn.ForeColor = [System.Drawing.Color]::White
$langBtn.FlatStyle = "Flat"
$langBtn.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)

$langBtn.Add_Click({

    # --- Fen�tre de confirmation traduite ---
    $result = [System.Windows.Forms.MessageBox]::Show(
        $lang["LangConfirmText"],
        $lang["LangConfirmTitle"],
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )

    if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
        return
    }

    # --- Dossiers ---
    $scriptPath = $PSScriptRoot
    $rootPath = Split-Path -Parent $scriptPath
    $langFolder = Join-Path $rootPath "lang"
    $otherFolder = Join-Path $langFolder "other"

    # --- V�rifier les fichiers dans other ---
    $files = Get-ChildItem $otherFolder -File -Filter *.txt

    if ($files.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show($lang["LangNoFile"])
        return
    }

    # --- D�placer tous les fichiers .txt vers lang/ ---
    foreach ($f in $files) {
        Move-Item $f.FullName $langFolder -Force
    }

    # --- Lancer lang.bat ---
    $bat = Join-Path $rootPath "config/lang.bat"
    if (Test-Path $bat) {
        Start-Process $bat
    }

    # --- Mise � jour du bouton ---
    $langBtn.Text = $lang["LangChanged"] + " OK"
})

$header.Controls.Add($langBtn)

# --- Affichage ---
$form.ShowDialog()
