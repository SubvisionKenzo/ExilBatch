' ============================
' Chargement des ressources
' ============================
Do
Set fso = CreateObject("Scripting.FileSystemObject")

' si dialog.txt = null alors
defaultTitle = "Setting panel"
defaultMessage = "Current settings :"
defaultEditPrompt = "Which setting do you want to change?"
defaultValuePrompt = "New value for :"
defaultErrorParam = "This parameter does not exist."
defaultErrorSettings = "settings.txt the file may have been moved, corrupted, or it may not exist."

' Ressources utilis�es
title = defaultTitle
message = defaultMessage
editPrompt = defaultEditPrompt
valuePrompt = defaultValuePrompt
errorParam = defaultErrorParam
errorSettings = defaultErrorSettings

' Lecture du fichier panel.dialog.txt si disponible
If fso.FileExists("panel.dialog.txt") Then
    Set dlg = fso.OpenTextFile("panel.dialog.txt", 1)
    Do Until dlg.AtEndOfStream
        line = Trim(dlg.ReadLine)
        If InStr(line, "=") > 0 Then
            key = Trim(Left(line, InStr(line, "=") - 1))
            value = Trim(Mid(line, InStr(line, "=") + 1))

            Select Case LCase(key)
                Case "title": Title = value
                Case "message": message = value
                Case "editprompt": editPrompt = value
                Case "valueprompt": valuePrompt = value
                Case "errorparam": errorParam = value
                Case "errorsettings": errorSettings = value
            End Select
        End If
    Loop
    dlg.Close
End If

' ============================
' Lecture des param�tres
' ============================

If Not fso.FileExists("settings.txt") Then
    MsgBox errorSettings, 16, title
    WScript.Quit
End If

Set file = fso.OpenTextFile("settings.txt", 1)
Set params = CreateObject("Scripting.Dictionary")

Do Until file.AtEndOfStream
    line = Trim(file.ReadLine)
    If InStr(line, "=") > 0 Then
        key = Trim(Left(line, InStr(line, "=") - 1))
        value = Trim(Mid(line, InStr(line, "=") + 1))
        params(key) = value
    End If
Loop
file.Close

' ============================
' Affichage des param�tres
' ============================

msg = message & vbCrLf & vbCrLf

For Each k In params.Keys
    msg = msg & k & " = " & params(k) & vbCrLf
Next

paramToEdit = InputBox(msg & vbCrLf & editPrompt, title)

If paramToEdit = "" Then WScript.Quit

If Not params.Exists(paramToEdit) Then
    MsgBox errorParam, 16, title
    WScript.Quit
End If

' ============================
' Modification du param�tre
' ============================

newValue = InputBox(valuePrompt & paramToEdit & " :", title)

If newValue = "" Then WScript.Quit

params(paramToEdit) = newValue

' ============================
' Sauvegarde
' ============================

Set file = fso.OpenTextFile("settings.txt", 2, True)

For Each k In params.Keys
    file.WriteLine k & "=" & params(k)
Next

file.Close

MsgBox "Parameter saved !", 64, title

Loop
