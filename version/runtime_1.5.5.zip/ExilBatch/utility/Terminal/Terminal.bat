powershell -ExecutionPolicy Bypass -File "%~dp0Terminal_host.ps1"
exit > nul