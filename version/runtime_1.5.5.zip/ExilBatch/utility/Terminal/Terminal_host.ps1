Set-Location ..
Clear-Host

Write-Host "=== ECB terminal shell ===" -ForegroundColor Cyan
Write-Host "For help enter : /help to show all commands list !" -ForegroundColor DarkGray
Write-Host ""

while ($true) {

    Write-Host -NoNewline ">> " -ForegroundColor Yellow
    $input = Read-Host

    # Commande HELP
    if ($input -eq "/help") {
        Write-Host ""
        Write-Host "--------------------------------------------------------" -ForegroundColor DarkCyan
        Write-Host "-                   Commandes list                     -" -ForegroundColor Cyan
        Write-Host "--------------------------------------------------------" -ForegroundColor DarkCyan

        if (Test-Path "$PSScriptRoot\list.txt") {
            Get-Content "$PSScriptRoot\list.txt" | ForEach-Object {
                Write-Host $_ -ForegroundColor Green
            }
        } else {
            Write-Host "Fichier list.txt introuvable." -ForegroundColor Red
        }

        Write-Host "--------------------------------------------------------" -ForegroundColor DarkCyan
        continue
    }

    # Commande EXIT
    if ($input -eq "/exit") {
        Write-Host "EXITING ECB Shell..." -ForegroundColor DarkGray
        break
    }

    # --- COLORATION FIABLE (sans ANSI) ---
    Write-Host -NoNewline ">> " -ForegroundColor DarkGray

    $tokens = $input.Split(" ")

    foreach ($t in $tokens) {

        if ($t -match "^start$") {
            Write-Host "$t " -ForegroundColor Blue -NoNewline
        }
        elseif ($t -match '^".*"$') {
            Write-Host "$t " -ForegroundColor Red -NoNewline
        }
        elseif ($t -match "^\(" -or $t -match "\)$") {
            Write-Host "$t " -ForegroundColor Cyan -NoNewline
        }
        elseif ($t -match "^/") {
            Write-Host "$t " -ForegroundColor Green -NoNewline
        }
        else {
            Write-Host "$t " -ForegroundColor Gray -NoNewline
        }
    }

    Write-Host ""

    # Exécution réelle de la commande PowerShell
    try {
        Invoke-Expression $input
    } catch {
        Write-Host "Error : $($_.Exception.Message)" -ForegroundColor Red
    }

    Write-Host ""
}
