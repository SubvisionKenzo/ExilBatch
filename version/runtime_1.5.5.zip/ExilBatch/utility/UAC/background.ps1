Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Définition WinAPI pour rendre la fenêtre non cliquable
Add-Type @"
using System;
using System.Runtime.InteropServices;

public class WinAPI {
    [DllImport("user32.dll")]
    public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
"@

# Création de la fenêtre
$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = 'None'
$form.WindowState = 'Maximized'
$form.BackColor = [System.Drawing.Color]::Black
$form.Opacity = 0.45
$form.TopMost = $false
$form.ShowInTaskbar = $false

# Rendre la fenêtre non cliquable
$WS_EX_TRANSPARENT = 0x20
$WS_EX_LAYERED = 0x80000

$hwnd = $form.Handle
$style = [WinAPI]::GetWindowLong($hwnd, -20)
[WinAPI]::SetWindowLong($hwnd, -20, $style -bor $WS_EX_TRANSPARENT -bor $WS_EX_LAYERED)

[console]::beep(200,230); [console]::beep(400,400);
#$form.ShowDialog()
