Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# === Dossier UAC ===
$uacPath = Split-Path -Parent $MyInvocation.MyCommand.Path

# === Lecture du texte principal ===
$uacTextFile = Join-Path $uacPath 'UACtext.txt'
$uacText = Get-Content $uacTextFile -Raw

# === WARNINGINFO ===
$warningFile = Join-Path $uacPath 'WARNINGINFO.txt'
$warningInfo = ""
if (Test-Path $warningFile) {
    $warningInfo = Get-Content $warningFile -Raw
}

# === D�tection langue syst�me ===
$culture = (Get-Culture).TwoLetterISOLanguageName

$translations = @{
    "en" = @{ Yes="Yes"; No="No"; Scan="Scan" }
    "fr" = @{ Yes="Oui"; No="Non"; Scan="Scanner" }
    "es" = @{ Yes="S�"; No="No"; Scan="Escanear" }
    "de" = @{ Yes="Ja"; No="Nein"; Scan="Scannen" }
}

if (-not $translations.ContainsKey($culture)) { $culture = "en" }
$T = $translations[$culture]

# === Lecture des infos dynamiques ===
$dialogFile = Join-Path $uacPath 'uac.dialog.txt'
$appName = ""; $appPath = ""; $appTitle = ""

if (Test-Path $dialogFile) {
    foreach ($line in Get-Content $dialogFile) {
        if ($line -like 'AppName=*')  { $appName  = $line.Split('=')[1] }
        if ($line -like 'AppPath=*')  { $appPath  = $line.Split('=')[1] }
        if ($line -like 'AppTitle=*') { $appTitle = $line.Split('=')[1] }
    }
}

# === Overlay noir (bloque les clics) ===
$overlay = New-Object System.Windows.Forms.Form
$overlay.FormBorderStyle = 'None'
$overlay.WindowState = 'Maximized'
$overlay.BackColor = [System.Drawing.Color]::Black
$overlay.Opacity = 0.45
$overlay.TopMost = $true
$overlay.ShowInTaskbar = $false
$overlay.Show()

# === Ombre port�e ===
$shadow = New-Object System.Windows.Forms.Form
$shadow.FormBorderStyle = 'None'
$shadow.StartPosition = 'CenterScreen'
$shadow.Size = New-Object System.Drawing.Size(610, 360)
$shadow.BackColor = [System.Drawing.Color]::Black
$shadow.Opacity = 0.25
$shadow.ShowInTaskbar = $false
$shadow.TopMost = $true
$shadow.Show()

# === Fen�tre principale ===
$form = New-Object System.Windows.Forms.Form
$form.Text = $appTitle
$form.FormBorderStyle = 'None'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(600, 350)
$form.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)
$form.TopMost = $true
$form.ShowInTaskbar = $false

# === Coins arrondis Windows 11 ===
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$path.AddArc(0,0,20,20,180,90)
$path.AddArc(580,0,20,20,270,90)
$path.AddArc(580,330,20,20,0,90)
$path.AddArc(0,330,20,20,90,90)
$path.CloseFigure()
$form.Region = New-Object System.Drawing.Region($path)

# === Bandeau jaune UAC ===
$panelTop = New-Object System.Windows.Forms.Panel
$panelTop.Size = New-Object System.Drawing.Size(600, 50)
$panelTop.Location = New-Object System.Drawing.Point(0,0)
$panelTop.BackColor = [System.Drawing.Color]::FromArgb(230, 200, 60)
$form.Controls.Add($panelTop)

$labelTop = New-Object System.Windows.Forms.Label
$labelTop.Text = $appTitle
$labelTop.AutoSize = $true
$labelTop.Location = New-Object System.Drawing.Point(15, 15)
$labelTop.ForeColor = [System.Drawing.Color]::Black
$labelTop.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$panelTop.Controls.Add($labelTop)

# === WARNINGINFO ===
$warningLabel = New-Object System.Windows.Forms.Label
$warningLabel.Text = $warningInfo
$warningLabel.Size = New-Object System.Drawing.Size(560, 50)
$warningLabel.Location = New-Object System.Drawing.Point(20, 60)
$warningLabel.ForeColor = [System.Drawing.Color]::Orange
$warningLabel.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($warningLabel)

# === Texte principal ===
$labelText = New-Object System.Windows.Forms.Label
$labelText.Text = $uacText
$labelText.Size = New-Object System.Drawing.Size(560, 70)
$labelText.Location = New-Object System.Drawing.Point(20, 115)
$labelText.ForeColor = [System.Drawing.Color]::White
$labelText.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$form.Controls.Add($labelText)

# === Zone APP / Chemin ===
$labelInfo = New-Object System.Windows.Forms.Label
$labelInfo.Text = "APP : $appName`nChemin : $appPath"
$labelInfo.Size = New-Object System.Drawing.Size(560, 50)
$labelInfo.Location = New-Object System.Drawing.Point(20, 190)
$labelInfo.ForeColor = [System.Drawing.Color]::LightGray
$labelInfo.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$form.Controls.Add($labelInfo)

# === Footer Windows 11 ===
$footer = New-Object System.Windows.Forms.Panel
$footer.Size = New-Object System.Drawing.Size(600, 60)
$footer.Location = New-Object System.Drawing.Point(0, 290)
$footer.BackColor = [System.Drawing.Color]::FromArgb(45,45,45)
$form.Controls.Add($footer)

# === Boutons arrondis Windows 11 ===
function New-W11Button {
    param($text, $x, $bg)

    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Size = New-Object System.Drawing.Size(110, 38)
    $btn.Location = New-Object System.Drawing.Point($x, 10)
    $btn.BackColor = $bg
    $btn.ForeColor = [System.Drawing.Color]::White
    $btn.FlatStyle = 'Flat'
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $btn.FlatAppearance.BorderSize = 0

    # Coins arrondis
    $pathBtn = New-Object System.Drawing.Drawing2D.GraphicsPath
    $pathBtn.AddArc(0,0,20,20,180,90)
    $pathBtn.AddArc(90,0,20,20,270,90)
    $pathBtn.AddArc(90,18,20,20,0,90)
    $pathBtn.AddArc(0,18,20,20,90,90)
    $pathBtn.CloseFigure()
    $btn.Region = New-Object System.Drawing.Region($pathBtn)

    return $btn
}

# Bouton Scan ? antimalware.bat "<chemin>"
$buttonScan = New-W11Button $T.Scan 230 ([System.Drawing.Color]::FromArgb(0,150,50))
$buttonScan.Add_Click({
    $bat = Join-Path $uacPath 'antimalware.bat'
    Start-Process $bat "`"$appPath`""
})
$footer.Controls.Add($buttonScan)

# Bouton Oui
$buttonYes = New-W11Button $T.Yes 350 ([System.Drawing.Color]::FromArgb(0,122,204))
$buttonYes.Add_Click({ $form.Close() })
$footer.Controls.Add($buttonYes)

# Bouton Non
$buttonNo = New-W11Button $T.No 470 ([System.Drawing.Color]::FromArgb(64,64,64))
$buttonNo.Add_Click({
    Set-Content -Path (Join-Path $uacPath 'x.txt') -Value "REFUSED"
    $form.Close()
})
$footer.Controls.Add($buttonNo)

# Fermeture de l�overlay + ombre
$form.Add_FormClosed({
    $overlay.Close()
    $shadow.Close()
})

# Affichage
$form.ShowDialog()