@echo off
for %%l in (%*) do (
	set "arg=%%l"
	goto creatfile
)
if exist x.txt goto supfile
exit

:supfile
del x.txt
exit

:creatfile
if exist uac.dialog.txt goto SUPUACdialog
:returncreat
echo AppTitle=%2 > uac.dialog.txt
echo AppPath=%1 >> uac.dialog.txt
exit

:SUPUACdialog
goto returncreat
exit