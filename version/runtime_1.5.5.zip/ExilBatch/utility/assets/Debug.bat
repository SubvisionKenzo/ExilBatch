@echo off
cd /d "%~dp0"
cd Debug
start Debug.bat
exit