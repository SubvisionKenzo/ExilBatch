@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

set "fichier=%1"
if "%fichier%"=="" (
    echo Usage : debug.bat fichier.bat
    PowerShell -ExecutionPolicy Bypass -File "open.ps1" /wait
    exit /b
)

set "dict=dictionnaire.txt"
if not exist "%dict%" (
    echo dictionnaire.txt introuvable.
    exit /b
)

set "rapport=rapport_analyse.txt"
del "%rapport%" 2>nul

echo Analyse starting...
echo -------------------------------------------- >> "%rapport%"
echo Lignes                :    Commands  >> "%rapport%"
echo -------------------------------------------- >> "%rapport%"

:: LECTURE S�CURIS�E
for /f "tokens=1* delims=:" %%A in ('findstr /n "^" "%fichier%"') do call :analyse "%%A" "%%B"

echo ---------------------- >> "%rapport%"
echo Analyse terminee. >> "%rapport%"
cd /d "%~dp0"
start rapport_analyse.txt
exit /b

:: --------------------------
::   FONCTION D�ANALYSE
:: --------------------------

:analyse
setlocal enabledelayedexpansion
set "ligne=%~1"
set "texte=%~2"

:: ignorer lignes vides
if "!texte!"=="" goto :eof

:: extraire premier mot
for /f "tokens=1" %%X in ("!texte!") do set "cmd=%%X"

:: ignorer labels
if "!cmd:~0,1!"==":" goto :eof

:: ignorer parenth�ses
if "!cmd!"=="(" goto :eof
if "!cmd!"==")" goto :eof

:: ignorer echo.
if /i "!cmd:~0,5!"=="echo." goto :eof

:: ignorer commentaires
if /i "!cmd!"=="rem" goto :eof
if "!cmd:~0,2!"=="::" goto :eof
if "!cmd:~0,1!"==";" goto :eof
if "!cmd:~0,1!"=="#" goto :eof

:: ignorer PowerShell
if /i "!cmd!"=="powershell" goto :eof
if /i "!cmd!"=="powershell.exe" goto :eof

:: ignorer mots textuels (non commandes Batch)
for %%T in (
    Name Version Programme Messages Configuration Analise Boucle Liste App Load
    Lancement Fichier Skip Skip2 Return1 Continue
) do (
    if /i "!cmd!"=="%%T" goto :eof
)

:: v�rifier dans le dictionnaire
set "trouve=0"
for /f "delims=" %%C in (dictionnaire.txt) do (
    if /i "%%C"=="!cmd!" set "trouve=1"
)

if "!trouve!"=="0" (
    >>"%rapport%" echo ligne !ligne! : commande inconnue "!cmd!" : !texte!
    echo ligne !ligne! : commande inconnue "!cmd!" : !texte!
)

endlocal
goto :eof
exit /b