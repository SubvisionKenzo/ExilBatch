Add-Type -AssemblyName System.Windows.Forms

# Fen�tre de s�lection
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.InitialDirectory = (Get-Location).Path
$dialog.Filter = "All file (*.*)|*.*"

if ($dialog.ShowDialog() -eq "OK") {

    $selectedFile = $dialog.FileName
    Write-Host "File selected : $selectedFile"

    # Chemin de debug.bat dans le m�me dossier que le script PS1
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $debugPath = Join-Path $scriptDir "debug.bat"

    if (Test-Path $debugPath) {
        Write-Host "Debuging..."
        Start-Process $debugPath -ArgumentList "`"$selectedFile`""
    } else {
        Write-Host "(X) debug.bat in : $scriptDir"
    }
}