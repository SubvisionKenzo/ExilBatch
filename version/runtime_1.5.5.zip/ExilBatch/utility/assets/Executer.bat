@echo off
set "execut=0"

cd Projects
dir *.bat /b | findstr /v /i "use.bat" >> run.txt
for /f "delims=" %%a in (run.txt) do set execut=%%a
del run.txt
start %execut%
for /f "tokens=2 delims==;" %%A in ('
    wmic process call create "%execut%" ^| find "ProcessId"
') do set "PID=%%A"

echo PID : %PID%

:: --- 2. Attendre la fin du programme
:waitloop
tasklist /FI "PID eq %PID%" | find "%PID%" >nul
if %errorlevel%==0 (
    timeout /t 1 >nul
    goto waitloop
)
exit
:error
echo Notification = msgbox("Aucun fichier ou projet trouver !",vbError,"Editore ECB projet") >> informe.vbs
start informe.vbs /wait
del informe.vbs
del run.txt
exit