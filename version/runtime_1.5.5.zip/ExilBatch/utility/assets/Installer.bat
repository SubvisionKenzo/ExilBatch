@echo off
cd ..
cd Config
powershell -Command "Start-Process 'install.bat' -Verb RunAs"
exit