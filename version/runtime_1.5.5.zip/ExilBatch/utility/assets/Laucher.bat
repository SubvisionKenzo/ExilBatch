@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
:: Varriable !
set "name=editor"
set "hide=hidden"

cd ..

set "SettingFolder=Panel"

rem === D�tection automatique du fichier settings ===
for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found1
)
exit /b
:found1

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%S in ("%settingsFile%") do (
    set "lignes=%%S"

    rem --- Ignore lignes vides ---
    if "!lignes!"=="" (
        rem skip
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligneS! | findstr /r "^[#;]" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%T in ("!lignes!") do (
                set "varName=%%T"
                set "varValue=%%U"
                set "!varName!=!varValue!"
            )
        )
    )
)
if "%editorlegacy%"=="1" (
    set "name=editor.legacy"
)

rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === D�tection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.

cd assets

if exist hide.txt goto skip

if "%Hidecmdicone%"=="1" goto skip
echo >> hide.txt

cmd /c start /min Laucher.bat %1
exit
:skip
del hide.txt
start splash.bat
echo TITLE=%TITLE% > editor.dialog.txt
echo BTN_NEW=%BTN_NEW% >> editor.dialog.txt
echo BTN_OPEN=%BTN_OPEN% >> editor.dialog.txt
echo BTN_SAVE=%BTN_SAVE% >> editor.dialog.txt
echo BTN_RUN=%BTN_RUN% >> editor.dialog.txt
echo BTN_DEBUG=%BTN_DEBUG% >> editor.dialog.txt
echo BTN_PROJECT=%BTN_PROJECT% >> editor.dialog.txt
echo BTN_SEARCH=%BTN_SEARCH% >> editor.dialog.txt
echo LBL_PROJECT=%LBL_PROJECT% >> editor.dialog.txt
echo LBL_REFRESH=%LBL_REFRESH% >> editor.dialog.txt
echo MSG_DELETE=%MSG_DELETE% >> editor.dialog.txt
echo MSG_RENAME=%MSG_RENAME% >> editor.dialog.txt
echo MSG_NEWFILE=%MSG_NEWFILE% >> editor.dialog.txt
echo LBL_RUN_TITLE=%LBL_RUN_TITLE% >> editor.dialog.txt
echo LBL_PROJECT_NAME=%LBL_PROJECT_NAME% >> editor.dialog.txt
echo LBL_EXTENSION=%LBL_EXTENSION% >> editor.dialog.txt
echo BTN_RUN_CMD=%BTN_RUN_CMD% >> editor.dialog.txt
echo BTN_RUN_PS=%BTN_RUN_PS% >> editor.dialog.txt
echo BTN_RUN_EXE=%BTN_RUN_EXE% >> editor.dialog.txt
echo PROP_TITLE=%PROP_TITLE% >> editor.dialog.txt
echo PROP_NAME=%PROP_NAME% >> editor.dialog.txt
echo PROP_EXT=%PROP_EXT% >> editor.dialog.txt
echo PROP_SIZE=%PROP_SIZE% >> editor.dialog.txt
echo PROP_CREATED=%PROP_CREATED% >> editor.dialog.txt
echo PROP_MODIFIED=%PROP_MODIFIED% >> editor.dialog.txt
echo BTN_OK=%BTN_OK% >> editor.dialog.txt
echo THEME_LIGHT=%THEME_LIGHT% >> editor.dialog.txt
echo THEME_DARK=%THEME_DARK% >> editor.dialog.txt
echo FILE=%FILE% >> editor.dialog.txt
echo FILE_RECENT=%FILE_RECENT% >> editor.dialog.txt
echo FILE_SAVEALL=%FILE_SAVEALL% >> editor.dialog.txt
echo BTN_NEWPROJECTCONTINU=%BTN_NEWPROJECTCONTINU% >> editor.dialog.txt
echo EXPLORER_TITLE_TEXT=%EXPLORER_TITLE_TEXT% >> editor.dialog.txt
echo BTN_IMPORTE_FILE=%BTN_IMPORTE_FILE% >> editor.dialog.txt
echo BTN_CREATE_PROJECT=%BTN_CREATE_PROJECT% >> editor.dialog.txt
if not exist splash goto runapp
cd splash
del splash.txt
echo SPLASHSCREEN=%SPLASHSCREEN% > splash.txt
cd ..
:runapp

:: Execution !
PowerShell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%name%.ps1"
exit > nul