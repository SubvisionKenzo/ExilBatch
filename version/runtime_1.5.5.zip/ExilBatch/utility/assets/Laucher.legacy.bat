@echo off
set "name=editor.legacy"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min Laucher.legacy.bat %1
exit
:execut
del %hide%.txt
PowerShell -STA -ExecutionPolicy Bypass -File "%name%.ps1" %1
exit > nul