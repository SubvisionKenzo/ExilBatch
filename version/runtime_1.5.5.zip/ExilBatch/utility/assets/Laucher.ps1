Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase

# --- Coins arrondis fenêtre ---
function Set-WindowRoundCorners {
    param([System.Windows.Forms.Form]$Form, [int]$Radius = 20)

    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $diam = $Radius * 2

    $path.AddArc(0, 0, $diam, $diam, 180, 90)
    $path.AddArc($Form.Width - $diam, 0, $diam, $diam, 270, 90)
    $path.AddArc($Form.Width - $diam, $Form.Height - $diam, $diam, $diam, 0, 90)
    $path.AddArc(0, $Form.Height - $diam, $diam, $diam, 90, 90)
    $path.CloseFigure()

    $Form.Region = New-Object System.Drawing.Region($path)
}

[System.Windows.Forms.Application]::EnableVisualStyles()

# --- Chemins ---
$BasePath      = Split-Path -Parent $MyInvocation.MyCommand.Path
$EditorBAT     = Join-Path $BasePath "Laucher.bat"
$PackagerBAT   = Join-Path $BasePath "packager.bat"
$UpdateBAT     = Join-Path $BasePath "updatecheck.bat"
$InstallBAT    = Join-Path $BasePath "Installer.bat"
$report        = Join-Path $BasePath "report.bat"
$SettingsPanel = Join-Path $BasePath "Setting_Panel.bat"
$ConvertBAT    = Join-Path $BasePath "BAT-PS1-to-EXE.bat"
$PackCSharpBAT = Join-Path $BasePath "PackagerCSharp.bat"
$Store         = Join-Path $BasePath "Store.bat"
$help          = Join-Path $BasePath "notice.txt"
$Uninstaller   = Join-Path $BasePath "uninstall.bat"
$Customer      = Join-Path $BasePath "customer.bat"

# --- Traduction via editor.dialog.txt ---
$DialogFile   = Join-Path $BasePath "editor.dialog.txt"
$Translations = @{}

if (Test-Path $DialogFile) {
    foreach ($line in Get-Content $DialogFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $Translations[$matches[1].Trim()] = $matches[2].Trim()
        }
    }
}

function Get-Translation {
    param([string]$Key)
    if ($Translations.ContainsKey($Key)) { return $Translations[$Key] }
    return $Key
}

# --- Fenêtre principale ---
$form = New-Object System.Windows.Forms.Form
$form.Text = Get-Translation "TITLE"
$form.Size = New-Object Drawing.Size(710, 350)
$form.FormBorderStyle = 'None'
$form.StartPosition = "CenterScreen"
$form.BackColor = [Drawing.Color]::FromArgb(25,25,25)
$form.MaximizeBox = $false

$form.Add_Shown({ Set-WindowRoundCorners -Form $form -Radius 20 })
$form.Add_Resize({ Set-WindowRoundCorners -Form $form -Radius 20 })

# --- Icône fenêtre ---
$iconPath = Join-Path $BasePath "ICO\64x64.ico"
if (Test-Path $iconPath) {
    $form.Icon = New-Object System.Drawing.Icon($iconPath)
}

# --- Image en bas à droite ---
$imagePath = Join-Path $BasePath "fenicon.png"
if (Test-Path $imagePath) {
    $img = [System.Drawing.Image]::FromFile($imagePath)
    $pictureBox = New-Object System.Windows.Forms.PictureBox
    $pictureBox.Image = $img
    $pictureBox.SizeMode = "Zoom"
    $pictureBox.Width = 60
    $pictureBox.Height = 60
    $pictureBox.Anchor = "Bottom,Right"
    $pictureBox.Left = $form.ClientSize.Width - $pictureBox.Width - 10
    $pictureBox.Top  = $form.ClientSize.Height - $pictureBox.Height - 10
    $form.Controls.Add($pictureBox)
    $form.Add_Resize({
        $pictureBox.Left = $form.ClientSize.Width - $pictureBox.Width - 10
        $pictureBox.Top  = $form.ClientSize.Height - $pictureBox.Height - 10
    })
}

# --- Bande latérale violette ---
$side = New-Object System.Windows.Forms.Panel
$side.Width = 160
$side.Dock = "Left"
$side.BackColor = [Drawing.Color]::FromArgb(120,0,200)
$form.Controls.Add($side)

$lblSide = New-Object System.Windows.Forms.Label
$lblSide.Text = "Ecrion"
$lblSide.ForeColor = "White"
$lblSide.Font = New-Object Drawing.Font("Segoe UI", 16, [Drawing.FontStyle]::Bold)
$lblSide.AutoSize = $true
$lblSide.Location = "20,20"
$side.Controls.Add($lblSide)

# --- Bouton moderne arrondi (radius 6) ---
function New-ModernButton {
    param($text)

    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Width = 200
    $btn.Height = 40
    $btn.Font = New-Object Drawing.Font("Segoe UI", 10, [Drawing.FontStyle]::Bold)
    $btn.BackColor = [Drawing.Color]::FromArgb(45,45,45)
    $btn.ForeColor = "White"
    $btn.FlatStyle = "Flat"
    $btn.FlatAppearance.BorderSize = 0
    $btn.Cursor = "Hand"

    # Coins arrondis
    $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
    $radius = 6
    $diam   = $radius * 2
    $gp.AddArc(0,0,$diam,$diam,180,90)
    $gp.AddArc($btn.Width-$diam,0,$diam,$diam,270,90)
    $gp.AddArc($btn.Width-$diam,$btn.Height-$diam,$diam,$diam,0,90)
    $gp.AddArc(0,$btn.Height-$diam,$diam,$diam,90,90)
    $gp.CloseFigure()
    $btn.Region = New-Object System.Drawing.Region($gp)

    # Hover (utiliser $this pour éviter l’erreur BackColor)
    $btn.Add_MouseEnter({ $this.BackColor = [Drawing.Color]::FromArgb(70,70,70) })
    $btn.Add_MouseLeave({ $this.BackColor = [Drawing.Color]::FromArgb(45,45,45) })

    return $btn
}

# --- Boutons centraux visibles ---
$btnEditor = New-ModernButton (Get-Translation "BTN_EDITOR")
$btnEditor.Location = "220,80"

$btnUpdate = New-ModernButton (Get-Translation "BTN_UPDATE")
$btnUpdate.Location = "220,130"

$btnStore = New-ModernButton (Get-Translation "BTN_STORE")
$btnStore.Location = "220,180"

$btnSettings = New-ModernButton (Get-Translation "BTN_SETTINGS")
$btnSettings.Location = "220,230"

$btnreport = New-ModernButton (Get-Translation "BTN_REPORT")
$btnreport.Width = 150
$btnreport.Location = "500,130"

$btnCustomer = New-ModernButton (Get-Translation "BTN_CUSTOMER")
$btnCustomer.Width = 150
$btnCustomer.Location = "500,180"

$form.Controls.AddRange(@(
    $btnEditor, $btnUpdate, $btnStore,
    $btnSettings, $btnreport, $btnCustomer
))

# --- Actions boutons ---
$RootPath = Split-Path -Parent $BasePath

# Aller dans Panel/settings.txt
$SettingsFile = Join-Path $RootPath "Panel\settings.txt"

$Settings = @{}

if (Test-Path $SettingsFile) {
    foreach ($line in Get-Content $SettingsFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $Settings[$matches[1].Trim()] = $matches[2].Trim()
        }
    }
}

function Get-Setting {
    param([string]$Key)
    if ($Settings.ContainsKey($Key)) { return $Settings[$Key] }
    return $null
}

$HideCmd = Get-Setting "Hidecmdicone"

# --- Fonction PRO pour lancer les .bat ---
function Launch-BAT {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        [System.Windows.Forms.MessageBox]::Show("$Path introuvable.")
        return
    }

    if ($HideCmd -eq "1") {
        Start-Process "WindowHide.exe" -ArgumentList "/file `"$Path`""
    }
    else {
        Start-Process $Path
    }
}

# --- Actions boutons ---
$btnEditor.Add_Click({ Launch-BAT $EditorBAT })
$btnUpdate.Add_Click({ Launch-BAT $UpdateBAT })
$btnStore.Add_Click({ Launch-BAT $Store })
$btnSettings.Add_Click({ Launch-BAT $SettingsPanel })
$btnreport.Add_Click({ Launch-BAT $report })
$btnCustomer.Add_Click({ Launch-BAT $Customer })

# --- Menu items ---
$mEditorItem.Add_Click({ Launch-BAT $EditorBAT })
$mSettingsItem.Add_Click({ Launch-BAT $SettingsPanel })
$mPackCItem.Add_Click({ Launch-BAT $PackCSharpBAT })
$mCustomerItem.Add_Click({ Launch-BAT $Customer })

$mPackItem.Add_Click({ Launch-BAT $PackagerBAT })
$mInstallItem.Add_Click({ Launch-BAT $InstallBAT })

$mCheckItem.Add_Click({ Launch-BAT $UpdateBAT })

$mUninstallItem.Add_Click({ Launch-BAT $Uninstaller })

# ---------------------------------------------------------

# --- Menu complet ---
$menu = New-Object System.Windows.Forms.MenuStrip

$mFile = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_FILE")
$mExit = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_EXIT")
$mExit.Add_Click({ $form.Close() })
$mFile.DropDownItems.Add($mExit)

$mTools = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_TOOLS")
$mEditorItem   = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_EDITOR")
$mSettingsItem = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_SETTINGS")
$mPackCItem    = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_PACKC")
$mCustomerItem = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_CUSTOMER")

$mEditorItem.Add_Click({ Start-Process $UpdateBAT })
$mSettingsItem.Add_Click({ Start-Process $SettingsPanel })
$mPackCItem.Add_Click({ Start-Process $PackCSharpBAT })
$mCustomerItem.Add_Click({ Start-Process $Customer })

$mTools.DropDownItems.AddRange(@($mEditorItem, $mSettingsItem, $mPackCItem, $mCustomerItem))

$mBuild = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_BUILD")
$mPackItem    = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_PACK")
$mInstallItem = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_INSTALL")

$mPackItem.Add_Click({ Start-Process $PackagerBAT })
$mInstallItem.Add_Click({ Start-Process $InstallBAT })

$mBuild.DropDownItems.AddRange(@($mPackItem, $mInstallItem))

$mUpdateMenu = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_UPDATE")
$mCheckItem  = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_UPDATE")
$mCheckItem.Add_Click({ Start-Process $UpdateBAT })
$mUpdateMenu.DropDownItems.Add($mCheckItem)

$mHelp = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_HELP")
$mAbout = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_HELP")
$mAbout.Add_Click({
    if (Test-Path $help) { Start-Process $help }
    else { [System.Windows.Forms.MessageBox]::Show("help introuvable.") }
})
$mHelp.DropDownItems.Add($mAbout)

$mUninstall = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "MENU_UNINSTALL")
$mUninstallItem = New-Object System.Windows.Forms.ToolStripMenuItem (Get-Translation "BTN_UNINSTALL")
$mUninstallItem.Add_Click({
    if (Test-Path $Uninstaller) { Start-Process $Uninstaller }
    else { [System.Windows.Forms.MessageBox]::Show("uninstall.bat introuvable.") }
})
$mUninstall.DropDownItems.Add($mUninstallItem)

$menu.Items.AddRange(@($mFile, $mTools, $mBuild, $mUpdateMenu, $mHelp, $mUninstall))
$form.MainMenuStrip = $menu
$form.Controls.Add($menu)

# --- Barre de titre custom ---
$TitleBar = New-Object System.Windows.Forms.Panel
$TitleBar.Height = 35
$TitleBar.Dock = "Top"
$TitleBar.BackColor = [Drawing.Color]::FromArgb(40,40,40)
$form.Controls.Add($TitleBar)

$iconBox = New-Object System.Windows.Forms.PictureBox
if (Test-Path $iconPath) {
    $iconBox.Image = [System.Drawing.Icon]::ExtractAssociatedIcon($iconPath).ToBitmap()
}
$iconBox.SizeMode = "StretchImage"
$iconBox.Width = 24
$iconBox.Height = 24
$iconBox.Location = "5,5"
$TitleBar.Controls.Add($iconBox)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = $form.Text
$titleLabel.ForeColor = "White"
$titleLabel.Font = New-Object Drawing.Font("Segoe UI", 11)
$titleLabel.AutoSize = $true
$titleLabel.Location = "35,7"
$TitleBar.Controls.Add($titleLabel)

# --- Bouton fermer ---
$btnClose = New-Object System.Windows.Forms.PictureBox
$btnClose.Image = [System.Drawing.Image]::FromFile(".\ICO\close.png")
$btnClose.SizeMode = "Zoom"
$btnClose.Width = 30
$btnClose.Height = 30
$btnClose.Anchor = "Top,Right"
$btnClose.Location = "$($form.Width - 35),2"
$btnClose.Add_Click({ $form.Close() })
$TitleBar.Controls.Add($btnClose)

$btnClose.Add_MouseEnter({
    $this.BackColor = [Drawing.Color]::FromArgb(200,50,50)
})
$btnClose.Add_MouseLeave({
    $this.BackColor = [Drawing.Color]::FromArgb(40,40,40)
})

# --- Bouton minimiser ---
$btnMin = New-Object System.Windows.Forms.PictureBox
$btnMin.Image = [System.Drawing.Image]::FromFile(".\ICO\minimal.png")
$btnMin.SizeMode = "Zoom"
$btnMin.Width = 30
$btnMin.Height = 30
$btnMin.Anchor = "Top,Right"
$btnMin.Location = "$($form.Width - 55),2"
$btnMin.Add_Click({ $form.WindowState = "Minimized" })
$TitleBar.Controls.Add($btnMin)

$btnMin.Add_MouseEnter({
    $this.BackColor = [Drawing.Color]::FromArgb(60,60,60)
})
$btnMin.Add_MouseLeave({
    $this.BackColor = [Drawing.Color]::FromArgb(40,40,40)
})

# --- Drag fenêtre ---
$global:dragging   = $false
$global:startPoint = [System.Drawing.Point]::Empty

$TitleBar.Add_MouseDown({
    $global:dragging = $true
    $global:startPoint = [System.Windows.Forms.Cursor]::Position
})

$TitleBar.Add_MouseMove({
    if ($global:dragging) {
        $pos = [System.Windows.Forms.Cursor]::Position
        $form.Left += $pos.X - $global:startPoint.X
        $form.Top  += $pos.Y - $global:startPoint.Y
        $global:startPoint = $pos
    }
})

$TitleBar.Add_MouseUp({
    $global:dragging = $false
})

$form.Add_Resize({
    $btnClose.Left = $form.ClientSize.Width - 35
    $btnMin.Left   = $form.ClientSize.Width - 85
})

# --- Affichage ---
$form.ShowDialog()