@echo off
setlocal enabledelayedexpansion
cd "%~dp0"
set "SettingFolder=Panel"
set "directoryauto=%~dp0"

cd ..
rem === Détection automatique du fichier settings ===
for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found
)
exit /b

:found
echo loading : %settingsFile%
echo.
rem === Lecture du fichier et création des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%settingsFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem skip
    ) else (

        rem --- Ignore commentaires commençant par # ou ; ---
        echo !ligne! | findstr /r "^[#;]" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.
cd assets
goto %Hidecmdicone%
:1
WindowHide.exe /file "Lauchrun.bat"
exit
:0
:run
start cmd /c start /min Lauchrun.bat
exit /b