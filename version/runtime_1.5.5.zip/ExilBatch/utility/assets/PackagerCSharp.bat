@echo off
cd /d "%~dp0"
cd ..
cd packager/CSharpCompiler
start Compil_Panel.bat
exit > nul