@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
cd ..

rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === D�tection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.

cd Panel
del panel.dialog.txt
echo Title=%Title% >> panel.dialog.txt
echo OpenSettings=%OpenSettings% >> panel.dialog.txt
echo message=%message%  >> panel.dialog.txt
echo editPrompt=%editPrompt%  >> panel.dialog.txt
echo valuePrompt=%valuePrompt%  >> panel.dialog.txt
echo errorParam=%errorParam%  >> panel.dialog.txt
echo errorSettings=%errorSettings%  >> panel.dialog.txt
echo LangButton=%LangButton%  >> panel.dialog.txt
echo LangConfirmTitle=%LangConfirmTitle%  >> panel.dialog.txt
echo LangConfirmText=Voulez-%LangConfirmText%  >> panel.dialog.txt
echo LangNoFile=%LangNoFile%  >> panel.dialog.txt
echo LangChanged=%LangChanged%  >> panel.dialog.txt
start Panel.bat
exit > nul