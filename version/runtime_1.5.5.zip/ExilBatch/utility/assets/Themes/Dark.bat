@echo off
cd /d "%~dp0"
cd ..
cd save
echo 1 > themes.txt
exit /b