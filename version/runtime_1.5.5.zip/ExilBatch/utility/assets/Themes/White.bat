@echo off
cd /d "%~dp0"
cd ..
cd save
echo 0 > themes.txt
exit /b