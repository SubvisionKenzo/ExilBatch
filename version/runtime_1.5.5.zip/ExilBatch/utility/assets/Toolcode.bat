@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
:: Varriable !
set "name=toolcode"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min Toolcode.bat
exit
:execut
del %hide%.txt

:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul