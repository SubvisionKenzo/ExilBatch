Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# --- Dossier Tools ---
$ToolsDir = Join-Path $PSScriptRoot "Tools"

if (-not (Test-Path $ToolsDir)) {
    [System.Windows.MessageBox]::Show("Le dossier 'Tools' est introuvable.")
    exit
}

# --- Fen�tre sombre ---
$window = New-Object System.Windows.Window
$window.Title = "Tools Launcher"
$window.Width = 500
$window.Height = 600
$window.Background = "#1E1E1E"
$window.Foreground = "White"
$window.WindowStartupLocation = "CenterScreen"

# --- Liste ---
$list = New-Object System.Windows.Controls.ListView
$list.Margin = "10"
$list.Background = "#2A2A2A"
$list.Foreground = "White"
$list.BorderThickness = 0

# Style moderne
$itemTemplate = @"
<DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>
    <StackPanel Orientation='Horizontal' Margin='5'>
        <Image Source='{Binding Icon}' Width='24' Height='24' Margin='0,0,10,0'/>
        <TextBlock Text='{Binding Name}' FontSize='16' VerticalAlignment='Center'/>
    </StackPanel>
</DataTemplate>
"@

$reader = New-Object System.Xml.XmlNodeReader ([xml]$itemTemplate)
$list.ItemTemplate = [Windows.Markup.XamlReader]::Load($reader)

# --- Charger les fichiers ---
$items = @()

Get-ChildItem $ToolsDir -File | Where-Object {
    $_.Extension -in ".exe", ".bat"
} | ForEach-Object {

    $icon = "$PSScriptRoot\ICO\file.png"

    $items += [pscustomobject]@{
        Name = $_.BaseName
        FullPath = $_.FullName
        Icon = $icon
    }
}

$list.ItemsSource = $items

# --- Double clic pour lancer ---
$list.Add_MouseDoubleClick({
    $sel = $list.SelectedItem
    if ($sel -and (Test-Path $sel.FullPath)) {
        Start-Process $sel.FullPath
    }
})

$window.Content = $list
$window.ShowDialog() | Out-Null