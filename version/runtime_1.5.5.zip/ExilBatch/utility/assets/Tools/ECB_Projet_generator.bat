@echo off
cd /d "%~dp0"
set "name=Extractor"
set "hide=hidden"
if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min ECB_Projet_generator.bat %1
exit
:execut
del %hide%.txt
cd templates
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" %1
exit > nul