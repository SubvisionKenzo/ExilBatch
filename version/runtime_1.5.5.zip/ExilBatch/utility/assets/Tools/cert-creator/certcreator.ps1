Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Chargement des textes depuis dialog.lang.txt ---
$langFile = Join-Path $PSScriptRoot "dialog.lang.txt"
if (-not (Test-Path $langFile)) {
    [System.Windows.Forms.MessageBox]::Show("dialog.lang.txt introuvable","Erreur")
    exit
}

$Lang = @{}
Get-Content $langFile -Encoding UTF8 | ForEach-Object {
    if ($_ -match "^\s*#" -or $_.Trim() -eq "") { return }
    $parts = $_ -split "=",2
    if ($parts.Count -eq 2) {
        $Lang[$parts[0].Trim()] = $parts[1].Trim()
    }
}

function T($key) {
    if ($Lang.ContainsKey($key)) { return $Lang[$key] }
    return $key
}

# --- Fen�tre ---
$form = New-Object System.Windows.Forms.Form
$form.Text = T "TITLE"
$form.Size = New-Object System.Drawing.Size(650, 560)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(15,23,42)
$form.FormBorderStyle = "FixedDialog"

$fontLabel = New-Object System.Drawing.Font("Segoe UI", 12)
$fontInput = New-Object System.Drawing.Font("Segoe UI", 12)
$fontTitle = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)

# --- Titre ---
$title = New-Object System.Windows.Forms.Label
$title.Text = T "TITLE"
$title.ForeColor = [System.Drawing.Color]::White
$title.Font = $fontTitle
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($title)

# -------------------------
# PLACEMENT MANUEL X/Y
# -------------------------

# Nom du certificat
$lblName = New-Object System.Windows.Forms.Label
$lblName.Text = T "LABEL_NAME"
$lblName.ForeColor = [System.Drawing.Color]::White
$lblName.Font = $fontLabel
$lblName.AutoSize = $true
$lblName.Location = New-Object System.Drawing.Point(40, 100)
$form.Controls.Add($lblName)

$txtName = New-Object System.Windows.Forms.TextBox
$txtName.Width = 500
$txtName.Font = $fontInput
$txtName.Location = New-Object System.Drawing.Point(40, 135)
$txtName.BackColor = [System.Drawing.Color]::FromArgb(30,41,59)
$txtName.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($txtName)

# Mot de passe
$lblPass = New-Object System.Windows.Forms.Label
$lblPass.Text = T "LABEL_PASS"
$lblPass.ForeColor = [System.Drawing.Color]::White
$lblPass.Font = $fontLabel
$lblPass.AutoSize = $true
$lblPass.Location = New-Object System.Drawing.Point(40, 200)
$form.Controls.Add($lblPass)

$txtPass = New-Object System.Windows.Forms.TextBox
$txtPass.Width = 500
$txtPass.Font = $fontInput
$txtPass.Location = New-Object System.Drawing.Point(40, 235)
$txtPass.BackColor = [System.Drawing.Color]::FromArgb(30,41,59)
$txtPass.ForeColor = [System.Drawing.Color]::White
$txtPass.UseSystemPasswordChar = $true
$form.Controls.Add($txtPass)

# Domaine
$lblDomain = New-Object System.Windows.Forms.Label
$lblDomain.Text = T "LABEL_DOMAIN"
$lblDomain.ForeColor = [System.Drawing.Color]::White
$lblDomain.Font = $fontLabel
$lblDomain.AutoSize = $true
$lblDomain.Location = New-Object System.Drawing.Point(40, 300)
$form.Controls.Add($lblDomain)

$txtDomain = New-Object System.Windows.Forms.TextBox
$txtDomain.Width = 500
$txtDomain.Font = $fontInput
$txtDomain.Location = New-Object System.Drawing.Point(40, 335)
$txtDomain.BackColor = [System.Drawing.Color]::FromArgb(30,41,59)
$txtDomain.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($txtDomain)

# Chemin de sortie
$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Text = T "LABEL_PATH"
$lblPath.ForeColor = [System.Drawing.Color]::White
$lblPath.Font = $fontLabel
$lblPath.AutoSize = $true
$lblPath.Location = New-Object System.Drawing.Point(40, 400)
$form.Controls.Add($lblPath)

$txtPath = New-Object System.Windows.Forms.TextBox
$txtPath.Width = 380
$txtPath.Font = $fontInput
$txtPath.Location = New-Object System.Drawing.Point(40, 435)
$txtPath.BackColor = [System.Drawing.Color]::FromArgb(30,41,59)
$txtPath.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($txtPath)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = T "BTN_BROWSE"
$btnBrowse.Width = 120
$btnBrowse.Height = 32
$btnBrowse.Location = New-Object System.Drawing.Point(430, 435)
$btnBrowse.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
$btnBrowse.ForeColor = [System.Drawing.Color]::White
$btnBrowse.FlatStyle = "Flat"
$btnBrowse.Add_Click({
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = "PFX (*.pfx)|*.pfx"
    $dialog.FileName = "certificat.pfx"
    if ($dialog.ShowDialog() -eq "OK") {
        $txtPath.Text = $dialog.FileName
    }
})
$form.Controls.Add($btnBrowse)

# --- Bouton Cr�er ---
$btnCreate = New-Object System.Windows.Forms.Button
$btnCreate.Text = T "BTN_CREATE"
$btnCreate.Width = 230
$btnCreate.Height = 40
$btnCreate.Location = New-Object System.Drawing.Point(190, 475)
$btnCreate.BackColor = [System.Drawing.Color]::FromArgb(34,197,94)
$btnCreate.ForeColor = [System.Drawing.Color]::White
$btnCreate.FlatStyle = "Flat"
$btnCreate.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnCreate)

# --- Logique ---
$btnCreate.Add_Click({
    if ($txtName.Text -eq "" -or $txtPass.Text -eq "" -or $txtPath.Text -eq "") {
        [System.Windows.Forms.MessageBox]::Show((T "MSG_MISSING"))
        return
    }

    try {
        $domain = $txtDomain.Text
        if ($domain -eq "") { $domain = "localhost" }

        $cert = New-SelfSignedCertificate `
            -DnsName $domain `
            -CertStoreLocation "Cert:\CurrentUser\My" `
            -FriendlyName $txtName.Text

        Export-PfxCertificate `
            -Cert $cert `
            -FilePath $txtPath.Text `
            -Password (ConvertTo-SecureString $txtPass.Text -AsPlainText -Force)

        [System.Windows.Forms.MessageBox]::Show((T "MSG_SUCCESS"))
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show((T "MSG_ERROR") + "`n$($_.Exception.Message)")
    }
})

$form.ShowDialog()
