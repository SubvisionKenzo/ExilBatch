@echo off
cd /d "%~dp0"
set "name=certcreator"
set "hide=hidden"
if exist %hide%.txt goto execut
echo >> %hide%.txt
cmd /c start /min certcreator.bat
exit
:execut
del %hide%.txt
cd cert-creator
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul