@echo off
cd /d "%~dp0"
:: Varriable !
set "name=window_ruler"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min ruler.bat
exit
:execut
del %hide%.txt
:: Execution !
cd ruler
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul