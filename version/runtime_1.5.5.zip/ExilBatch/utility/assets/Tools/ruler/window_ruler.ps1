Add-Type -AssemblyName PresentationFramework

$window = New-Object Windows.Window
$window.Width = 400
$window.Height = 60
$window.Title = "Ruler"
$window.WindowStartupLocation = "CenterScreen"
$window.Background = "White"

$canvas = New-Object Windows.Controls.Canvas
$window.Content = $canvas

$step = 20

function Draw-Grid {
    $canvas.Children.Clear()

    $width  = $window.ActualWidth  - 16
    $height = $window.ActualHeight - 39

    $window.Title = "{0} x {1}" -f [int]$width, [int]$height

    for ($x = 0; $x -lt $width; $x += $step) {
        $line = New-Object Windows.Shapes.Line
        $line.X1 = $x; $line.Y1 = 0
        $line.X2 = $x; $line.Y2 = $height
        $line.Stroke = 'LightGray'
        $canvas.Children.Add($line) | Out-Null

        $text = New-Object Windows.Controls.TextBlock
        $text.Text = $x
        $text.Margin = [Windows.Thickness]::new($x+2, 2, 0, 0)
        $canvas.Children.Add($text) | Out-Null
    }

    for ($y = 0; $y -lt $height; $y += $step) {
        $line = New-Object Windows.Shapes.Line
        $line.X1 = 0; $line.Y1 = $y
        $line.X2 = $width; $line.Y2 = $y
        $line.Stroke = 'LightGray'
        $canvas.Children.Add($line) | Out-Null

        $text = New-Object Windows.Controls.TextBlock
        $text.Text = $y
        $text.Margin = [Windows.Thickness]::new(2, $y+2, 0, 0)
        $canvas.Children.Add($text) | Out-Null
    }
}

$window.Add_SourceInitialized({ Draw-Grid })
$window.Add_SizeChanged({ Draw-Grid })

[void]$window.ShowDialog()