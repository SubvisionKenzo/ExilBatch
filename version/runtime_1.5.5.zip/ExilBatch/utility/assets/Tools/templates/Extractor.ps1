Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem

# ============================
# CONFIG : ZIP PAR ARGUMENT OU PAR D�FAUT
# ============================

$BasePath = Split-Path -Parent $MyInvocation.MyCommand.Definition

if ($args.Count -gt 0) {
    $ZipFile = $args[0]
} else {
    $ZipFile = Join-Path $BasePath "ECBPROJECT_Template.zip"
}

if (-not (Test-Path $ZipFile)) {
    [System.Windows.Forms.MessageBox]::Show("ZIP introuvable :`n$ZipFile")
    exit
}

$ZipName = Split-Path $ZipFile -Leaf

# ============================
# CHOIX DU DOSSIER
# ============================

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "Extract : $ZipName"

if ($dialog.ShowDialog() -ne "OK") {
    exit
}

$TargetPath = $dialog.SelectedPath

if (-not (Test-Path $TargetPath)) {
    New-Item -ItemType Directory -Path $TargetPath -Force | Out-Null
}

# ============================
# EXTRACTION
# ============================

try {
    [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipFile, $TargetPath)
}
catch {
    [System.Windows.Forms.MessageBox]::Show("Erreur lors de l'extraction :`n$($_.Exception.Message)")
    exit
}

# ============================
# LANCEMENT DU SCRIPT BATCH
# ============================

$BatchFile = Join-Path $BasePath "run_project.bat"

if (Test-Path $BatchFile) {
    Start-Process -FilePath "$BasePath\run_project.bat" -ArgumentList "`"$TargetPath`""
    [System.Windows.Forms.MessageBox]::Show("run_project.bat introuvable dans :`n$BasePath")
}