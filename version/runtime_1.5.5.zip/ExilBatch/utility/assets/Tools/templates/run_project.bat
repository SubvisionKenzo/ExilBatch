@echo off
if exist %1 goto run
exit
:run
pushd %1
for %%F in (*) do (
    set "FirstFile=%%F"
    goto :found
)
exit
:found
popd
cd ..\..
start main.bat %~1\%FirstFile%
echo %~1\%FirstFile%
exit