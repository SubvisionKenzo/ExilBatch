@echo off
cd /d "%~dp0"
cd ..
start color.bat
exit