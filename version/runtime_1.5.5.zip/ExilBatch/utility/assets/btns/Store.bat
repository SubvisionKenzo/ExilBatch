@echo off
cd /d "%~dp0"
cd ..
start store.bat
exit