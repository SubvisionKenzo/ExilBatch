@echo off
cd /d "%~dp0"
cd ..
start Toolcode.bat
exit