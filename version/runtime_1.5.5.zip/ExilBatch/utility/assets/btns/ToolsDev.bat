@echo off
cd /d "%~dp0"
set "name=Tools"
set "hide=hidden"
if exist %hide%.txt goto execut
echo >> %hide%.txt
cmd /c start /min ToolsDev.bat
exit
:execut
del %hide%.txt
cd ..
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul