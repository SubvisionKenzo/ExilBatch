@echo off
cd /d "%~dp0"
cd ..
start consol.bat
exit