@echo off
cd /d "%~dp0"
cd ..
start packager.bat
exit