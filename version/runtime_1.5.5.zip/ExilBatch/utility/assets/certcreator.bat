@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
cd ..

rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === D�tection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.

cd cert-creator
del dialog.lang.txt
echo TITLE=%TITLE% >> dialog.lang.txt
echo LABEL_NAME=%LABEL_NAME% >> dialog.lang.txt
echo LABEL_PASS=%LABEL_PASS% >> dialog.lang.txt
echo LABEL_DOMAIN=%LABEL_DOMAIN% >> dialog.lang.txt
echo LABEL_PATH=%LABEL_PATH% >> dialog.lang.txt
echo BTN_BROWSE=%BTN_BROWSE% >> dialog.lang.txt
echo BTN_CREATE=%BTN_CREATE% >> dialog.lang.txt
echo MSG_SUCCESS=%MSG_SUCCESS% >> dialog.lang.txt
echo MSG_ERROR=%MSG_ERROR% >> dialog.lang.txt
echo MSG_MISSING=%MSG_MISSING% >> dialog.lang.txt
echo DIALOG_BROWSE_TITLE=%DIALOG_BROWSE_TITLE% >> dialog.lang.txt
start certcreator.bat
exit > nul