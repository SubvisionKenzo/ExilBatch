@echo off
cd /d "%~dp0"
for %%l in (%*) do (
	set "arg=%%l"
)
cd ..
cd Terminal
start Terminal.bat
exit > nul