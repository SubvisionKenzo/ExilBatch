@echo off
cd /d "%~dp0"
cd ..
cd icon
start icons_customer.bat
exit