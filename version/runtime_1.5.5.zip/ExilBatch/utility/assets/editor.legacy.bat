@echo off
set "hide=hidden"
cd ..
rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === Détection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    ech %langFile%
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et création des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commençant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
                echo %varName%
            )
        )
    )
)
echo.
cd assets
echo TITLE=%TITLELAUCHER% > editor.dialog.txt
echo BTN_EDITOR=%BTN_EDITOR2% >> editor.dialog.txt
echo BTN_PACK=%BTN_PACK% >> editor.dialog.txt
echo BTN_UPDATE=%BTN_UPDATE% >> editor.dialog.txt
echo BTN_INSTALL=%BTN_INSTALL% >> editor.dialog.txt
echo BTN_SETTINGS=%BTN_SETTINGS% >> editor.dialog.txt
echo BTN_STORE=%BTN_STORE% >> editor.dialog.txt
echo BTN_REPORT=%BTN_REPORT% >> editor.dialog.txt
echo BTN_CUSTOMER=%BTN_CUSTOMER% >> editor.dialog.txt
echo BTN_LANG=%BTN_LANG% >> editor.dialog.txt
echo MENU_HELP=%MENU_HELP% >> editor.dialog.txt
echo MENU_UNINSTALL=%MENU_UNINSTALL% >> editor.dialog.txt
echo MENU_BUILD=%MENU_BUILD% >> editor.dialog.txt
echo MENU_TOOLS=%MENU_TOOLS% >> editor.dialog.txt
echo MENU_FILE=%MENU_FILE% >> editor.dialog.txt
echo BTN_EXIT=%BTN_EXIT% >> editor.dialog.txt
echo BTN_EXIT=%BTN_EXIT% >> editor.dialog.txt
echo BTN_PACKC=%BTN_PACKC% >> editor.dialog.txt
echo MENU_UPDATE=%MENU_UPDATE% >> editor.dialog.txt
echo FILE=%FILE% >> editor.dialog.txt
echo FILE_RECENT=%FILE_RECENT% >> editor.dialog.txt
echo FILE_SAVEALL=%FILE_SAVEALL% >> editor.dialog.txt
PowerShell -ExecutionPolicy Bypass -File editor.legacy.ps1 %1
set ERR=%ERRORLEVEL%
if %ERR% NEQ 0 (
    start editor.vbs
    exit /b
)
exit > nul