Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -Path "$PSScriptRoot\libs\net462\border\WindowStyler.dll"
# --- Force STA mode ---
if ($host.Runspace.ApartmentState -ne "STA") {
    powershell.exe -STA -File $PSCommandPath
    exit
}

# =========================
#   Splash screen
# =========================
$splashPath = Join-Path $PSScriptRoot "splash"
if (-not (Test-Path $splashPath)) {
    New-Item -ItemType Directory -Path $splashPath | Out-Null
}
Start-Sleep -Seconds 1
$readyFile = Join-Path $splashPath "ready.txt"
"READY=1" | Out-File -FilePath $readyFile -Encoding UTF8

# --- Assemblies WPF ---
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName WindowsBase

# --- Windows Forms ---
Add-Type -AssemblyName System.Windows.Forms

# --- AvalonEdit ---
$AvalonPath = Join-Path $PSScriptRoot "libs\net35\ICSharpCode.AvalonEdit.dll"
if (-not (Test-Path $AvalonPath)) {
    [System.Windows.MessageBox]::Show("Erreur : AvalonEdit.dll introuvable.`nChemin attendu : $AvalonPath")
    exit
}
Add-Type -Path $AvalonPath

# --- Dossiers de base ---
$Root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigDir   = Join-Path $Root "config"
$IconsDir    = Join-Path $Root "ICO"
$ProjectRoot = Join-Path $Root "project"
$BtnsDir     = Join-Path $Root "btns"

foreach ($d in @($ConfigDir,$IconsDir,$ProjectRoot,$BtnsDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}

# R�pertoire courant de l�explorateur
$script:CurrentProjectDir = $ProjectRoot
$script:NavHistory = New-Object System.Collections.Generic.List[string]
$script:NavIndex   = -1

# --- Chargement des textes depuis editor.dialog.txt ---
$DialogFile = Join-Path $Root "editor.dialog.txt"
$DIALOG = @{}
if (Test-Path $DialogFile) {
    Get-Content $DialogFile | ForEach-Object {
        if ($_ -match "=") {
            $k,$v = $_ -split "=",2
            $DIALOG[$k.Trim()] = $v.Trim()
        }
    }
} else {
    $DIALOG["TITLE"]       = "Mon Super �diteur"
    $DIALOG["BTN_NEW"]     = "Nouveau"
    $DIALOG["BTN_OPEN"]    = "Ouvrir"
    $DIALOG["BTN_SAVE"]    = "Enregistrer"
    $DIALOG["BTN_RUN"]     = "Ex�cuter"
    $DIALOG["BTN_DEBUG"]   = "D�boguer"
    $DIALOG["BTN_PROJECT"] = "Projet"
    $DIALOG["BTN_SEARCH"]  = "Rechercher"
    $DIALOG["LBL_PROJECT"] = "Explorateur de projet"
    $DIALOG["LBL_REFRESH"] = "Actualiser"
    $DIALOG["MSG_DELETE"]  = "Supprimer cet �l�ment ?"
    $DIALOG["MSG_RENAME"]  = "Nouveau nom :"
    $DIALOG["MSG_NEWFILE"] = "Nouveau fichier"
}

# --- XAML de la fen�tre principale ---
$xaml = @'
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
        xmlns:avalon="http://icsharpcode.net/sharpdevelop/avalonedit"
        Title='Ecrion Editor'
        Width='1200' Height='800'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'>

    <Window.Resources>
        <Style x:Key='TabItemStyle' TargetType='TabItem'>
            <Setter Property='Foreground' Value='White'/>
            <Setter Property='Padding' Value='0'/>
            <Setter Property='Margin' Value='2,0'/>
            <Setter Property='Background' Value='#2D2D2D'/>
            <Setter Property='MinWidth' Value='150'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='TabItem'>
                        <Grid>
                            <Border x:Name='TabBorder'
                                    Background='{TemplateBinding Background}'
                                    CornerRadius='8,8,0,0'
                                    Padding='8,4'>
                                <StackPanel Orientation='Horizontal'>
                                    <ContentPresenter
                                        Content='{TemplateBinding Header}'
                                        VerticalAlignment='Center'
                                        Margin='0,0,6,0'/>
                                    <Button x:Name='CloseBtn'
                                            Content='�'
                                            Width='18' Height='18'
                                            Background='Transparent'
                                            Foreground='White'
                                            BorderThickness='0'
                                            Padding='0'
                                            Cursor='Hand'/>
                                </StackPanel>
                            </Border>
                            <Border x:Name='Underline'
                                    Height='2'
                                    VerticalAlignment='Bottom'
                                    CornerRadius='2'
                                    Background='#555'
                                    Margin='6,0,6,0'/>
                        </Grid>
                        <ControlTemplate.Triggers>
                            <Trigger Property='IsSelected' Value='True'>
                                <Setter TargetName='TabBorder' Property='Background' Value='#3A3A3A'/>
                                <Setter TargetName='Underline' Property='Background' Value='#C586C0'/>
                                <Setter TargetName='Underline' Property='Height' Value='4'/>
                            </Trigger>
                            <Trigger Property='IsMouseOver' Value='True'>
                                <Setter TargetName='TabBorder' Property='Background' Value='#404040'/>
                                <Setter TargetName='Underline' Property='Background' Value='#8A2BE2'/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <DockPanel Name='Root' LastChildFill='True'>

<ToolBar DockPanel.Dock='Top'
         Name='Toolbar'
         Background='#333333'
         Height='40'>

    <!-- Bouton Param�tres -->
<Button Name="BtnSettings"
        Width="32" Height="32"
        Background="Transparent"
        BorderThickness="0"
        Margin="5">
    <Image Name="ImgSettings" Stretch="Uniform"/>
</Button>

</ToolBar>

        <!-- LISTE DES R�SULTATS DE RECHERCHE -->
        <ListBox Name='SearchResults'
                 DockPanel.Dock='Top'
                 Visibility='Collapsed'
                 Background='#1E1E1E'
                 Foreground='White'
                 BorderBrush='#444'
                 BorderThickness='1'
                 MaxHeight='200'
                 Margin='10,2,10,5'/>

        <StatusBar DockPanel.Dock='Bottom' Background='#222222'>
            <StatusBarItem><TextBlock Name='StatusWords' Foreground='White'/></StatusBarItem>
            <StatusBarItem><TextBlock Name='StatusPos'   Foreground='White'/></StatusBarItem>
        </StatusBar>

        <Border DockPanel.Dock='Bottom'
                Name='ProjectPane'
                Background='#1A1025'
                BorderBrush='#7B3FFF'
                BorderThickness='1'
                Padding='5'
                Visibility='Collapsed'
                Height='250'>
            <DockPanel>
                <StackPanel DockPanel.Dock='Top' Orientation='Horizontal'>
                    <TextBlock Name='LblProject' Foreground='White' FontWeight='Bold' Margin='0,0,10,0'/>
                    <Button Name='BtnBack' Width='30' Height='24' Margin='0,0,5,0'/>
                    <Button Name='BtnForward' Width='30' Height='24' Margin='0,0,5,0'/>
                    <Button Name='BtnRefresh' Width='30' Height='24' Margin='0,0,5,0'/>
                    <Button Name='BtnAddRef' Width='30' Height='24' Margin='0,0,5,0'/>
                </StackPanel>
                <ListView Name='ProjectList' Margin='0,5,0,0'>
                    <ListView.View>
                        <GridView>
                            <GridViewColumn Width='30'>
                                <GridViewColumn.CellTemplate>
                                    <DataTemplate>
                                        <Image Width='16' Height='16' Source='{Binding Icon}'/>
                                    </DataTemplate>
                                </GridViewColumn.CellTemplate>
                            </GridViewColumn>
                            <GridViewColumn Header='Nom'  Width='300' DisplayMemberBinding='{Binding Name}'/>
                            <GridViewColumn Header='Type' Width='100' DisplayMemberBinding='{Binding Type}'/>
                            <GridViewColumn Header='Date' Width='150' DisplayMemberBinding='{Binding Date}'/>
                        </GridView>
                    </ListView.View>
                </ListView>
            </DockPanel>
        </Border>

        <TabControl Name='Tabs'
                    TabStripPlacement='Top'
                    HorizontalContentAlignment='Stretch'
                    VerticalContentAlignment='Stretch'/>
    </DockPanel>
</Window>
'@

# --- Fen�tre RUN avec choix CMD / PS / EXE et nom+extension ---

$xamlRun = @"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        Title='Run Options'
        Width='400' Height='320'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'>

    <StackPanel Margin='10'>
        <TextBlock Text='Nom du fichier (avec extension) :' Foreground='White'/>
        <TextBox Name='TxtFileName' Margin='0,5,0,10'/>

        <StackPanel Orientation='Horizontal' Margin='0,10,0,0'>
            <Button Name='BtnRunCmd' Content='CMD' Width='80' Margin='0,0,10,0'/>
            <Button Name='BtnRunPS'  Content='PowerShell' Width='80' Margin='0,0,10,0'/>
            <Button Name='BtnRunExe' Content='EXE...' Width='80'/>
        </StackPanel>
    </StackPanel>

</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

$window.Add_SourceInitialized({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#F01D6E", "#333333")
})

$window.Add_Deactivated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#BA547A", "#333333")
})

$window.Add_Activated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#F01D6E", "#333333")
})

# R�cup�ration des contr�les
$Tabs        = $window.FindName("Tabs")
$Toolbar     = $window.FindName("Toolbar")
$SearchResults = $window.FindName("SearchResults")
$StatusWords = $window.FindName("StatusWords")
$StatusPos   = $window.FindName("StatusPos")
$ProjectPane = $window.FindName("ProjectPane")
$ProjectList = $window.FindName("ProjectList")
$BtnRefresh  = $window.FindName("BtnRefresh")
$BtnBack     = $window.FindName("BtnBack")
$BtnForward  = $window.FindName("BtnForward")
$BtnAddRef   = $window.FindName("BtnAddRef")
$LblProject  = $window.FindName("LblProject")
$BtnSettings = $window.FindName("BtnSettings")
$ImgSettings = $window.FindName("ImgSettings")

$LblProject.Text = $DIALOG["LBL_PROJECT"]

$TabItemStyle = $window.Resources["TabItemStyle"]

$ImgSettings.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]"$Root\ICO\settings.png")

# --- D�tection .NET ---
function Test-NET {
    try {
        $v = [System.Environment]::Version
        return $v.Major -ge 4
    } catch {
        return $false
    }
}

$HasNet = Test-NET

if (-not $HasNet) {

    Add-Type -AssemblyName PresentationFramework

    $xamlWarn = @"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        Title='$($DIALOG["WARNING_TITLE"])'
        Width='480' Height='260'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'
        ResizeMode='NoResize'>

    <Grid Margin='15'>
        <Grid.RowDefinitions>
            <RowDefinition Height='Auto'/>
            <RowDefinition Height='*'/>
            <RowDefinition Height='Auto'/>
        </Grid.RowDefinitions>

        <StackPanel Orientation='Horizontal' Grid.Row='0' Margin='0,0,0,10'>
            <TextBlock Text='?' FontSize='28' Foreground='#E5C07B' Margin='0,0,10,0'/>
            <TextBlock Text='$($DIALOG["WARNING_TEXT"])'
                       Foreground='White'
                       FontSize='14'
                       TextWrapping='Wrap'/>
        </StackPanel>

        <TextBlock Grid.Row='1'
                   Foreground='White'
                   TextWrapping='Wrap'
                   Text='$($DIALOG["WARNING_INFO"])' />

        <StackPanel Grid.Row='2' Orientation='Horizontal' HorizontalAlignment='Right' Margin='0,15,0,0'>
            <Button Name='BtnLink'
                    Content='$($DIALOG["WARNING_LINK"])'
                    Background='#444'
                    Foreground='White'
                    Padding='6'
                    Margin='0,0,10,0'/>

            <Button Name='BtnCancel'
                    Content='$($DIALOG["WARNING_CANCEL"])'
                    Background='#444'
                    Foreground='White'
                    Padding='6'
                    Margin='0,0,10,0'/>

            <Button Name='BtnOk'
                    Content='$($DIALOG["WARNING_CONTINUE"])'
                    Background='#7B3FFF'
                    Foreground='White'
                    Padding='6'/>
        </StackPanel>
    </Grid>
</Window>
"@

    $readerWarn = New-Object System.Xml.XmlNodeReader ([xml]$xamlWarn)
    $winWarn    = [Windows.Markup.XamlReader]::Load($readerWarn)

    $BtnLink   = $winWarn.FindName("BtnLink")
    $BtnCancel = $winWarn.FindName("BtnCancel")
    $BtnOk     = $winWarn.FindName("BtnOk")

    $BtnLink.Add_Click({
        Start-Process "https://dotnet.microsoft.com/en-us/download/dotnet-framework"
    })

    $BtnCancel.Add_Click({
        $winWarn.Close()
        exit
    })

    $BtnOk.Add_Click({
        $winWarn.Close()
    })

    $winWarn.ShowDialog() | Out-Null
}

# --- Construction de la ToolBar : boutons principaux + barre de recherche ---

function New-ToolbarButton {
    param(
        [string]$textKey,
        [string]$iconName,
        [scriptblock]$action
    )

    $btn = New-Object System.Windows.Controls.Button
    $btn.Margin = "5,0,0,0"
    $btn.Background = "#444444"
    $btn.Foreground = "White"
    $btn.Padding = "4"

    $stack = New-Object System.Windows.Controls.StackPanel
    $stack.Orientation = "Horizontal"

    $imgPath = Join-Path $IconsDir $iconName
    if (Test-Path $imgPath) {
        $img = New-Object System.Windows.Controls.Image
        $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$imgPath)
        $img.Width = 16
        $img.Height = 16
        $img.Margin = "0,0,5,0"
        $stack.Children.Add($img) | Out-Null
    }

    $txt = New-Object System.Windows.Controls.TextBlock
    $txt.Text = $DIALOG[$textKey]
    $txt.Foreground = "White"
    $stack.Children.Add($txt) | Out-Null

    $btn.Content = $stack
    if ($action) { $btn.Add_Click($action) }

    return $btn
}

# --- Boutons principaux ---
$btnOpen = New-ToolbarButton "BTN_OPEN" "open.png" {
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        New-Tab
        $editor = Get-ActiveEditor
        $editor.Text = (Get-Content $dlg.FileName -Raw)
        $Tabs.SelectedItem.Header = [IO.Path]::GetFileName($dlg.FileName)
        Update-Status
    }
}

$btnSave = New-ToolbarButton "BTN_SAVE" "save.png" {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        [IO.File]::WriteAllText($dlg.FileName,$editor.Text)
        $Tabs.SelectedItem.Header = [IO.Path]::GetFileName($dlg.FileName)
    }
}

$btnNew = New-ToolbarButton "BTN_NEW" "new.png" {
    New-Tab
}

$btnRun = New-ToolbarButton "BTN_RUN" "run.png" {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $code = $editor.Text

    # Charger la fen�tre Run
    $readerRun = New-Object System.Xml.XmlNodeReader ([xml]$xamlRun)
    $runWin = [Windows.Markup.XamlReader]::Load($readerRun)

    if (-not $runWin) {
        [System.Windows.MessageBox]::Show("Erreur : impossible de charger la fen�tre Run.")
        return
    }

    $txtFileName = $runWin.FindName("TxtFileName")
    $btnRunCmd   = $runWin.FindName("BtnRunCmd")
    $btnRunPS    = $runWin.FindName("BtnRunPS")
    $btnRunExe   = $runWin.FindName("BtnRunExe")

    # V�rification
    if (-not $txtFileName -or -not $btnRunCmd -or -not $btnRunPS -or -not $btnRunExe) {
        [System.Windows.MessageBox]::Show("Erreur : un �l�ment de la fen�tre Run est introuvable.")
        return
    }

    # Nom par d�faut
    $defaultName = $Tabs.SelectedItem.Header
    if (-not $defaultName -or $defaultName -like "Untitled*") {
        $defaultName = "script.ps1"
    }
    $txtFileName.Text = $defaultName

    # Fonction utilitaire
    $getTempPath = {
        param($name)
        if (-not $name) { $name = "script.ps1" }
        return (Join-Path ([IO.Path]::GetTempPath()) $name)
    }

    # Bouton CMD
    $btnRunCmd.Add_Click({
        $fileName = $txtFileName.Text
        $path = & $getTempPath $fileName
        [IO.File]::WriteAllText($path,$code)
        Start-Process "cmd.exe" "/k `"$path`""
    })

    # Bouton PowerShell
    $btnRunPS.Add_Click({
        $fileName = $txtFileName.Text
        $path = & $getTempPath $fileName
        [IO.File]::WriteAllText($path,$code)
        Start-Process "powershell" "-ExecutionPolicy Bypass -File `"$path`""
    })

    # Bouton EXE
    $btnRunExe.Add_Click({
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Executable|*.exe"
        if ($dlg.ShowDialog() -eq "OK") {
            $fileName = $txtFileName.Text
            $path = & $getTempPath $fileName
            [IO.File]::WriteAllText($path,$code)
            Start-Process $dlg.FileName $path
        }
    })

    $runWin.ShowDialog() | Out-Null
}

$btnDebug = New-ToolbarButton "BTN_DEBUG" "debug.png" {
    $bat = Join-Path $Root "debug.bat"
    if (Test-Path $bat) {
        Start-Process $bat
    }
}

$btnProject = New-ToolbarButton "BTN_PROJECT" "project.png" {
    if ($ProjectPane.Visibility -eq "Collapsed") {
        $ProjectPane.Visibility = "Visible"
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$true
    } else {
        $ProjectPane.Visibility = "Collapsed"
    }
}

# --- Ajout des boutons dans la ToolBar ---
$Toolbar.Items.Add($btnOpen) | Out-Null
$Toolbar.Items.Add($btnSave) | Out-Null
$Toolbar.Items.Add($btnNew)  | Out-Null

$sep = New-Object System.Windows.Controls.Separator
$sep.Margin = "10,0,10,0"
$Toolbar.Items.Add($sep) | Out-Null

$Toolbar.Items.Add($btnRun)     | Out-Null
$Toolbar.Items.Add($btnDebug)   | Out-Null
$Toolbar.Items.Add($btnProject) | Out-Null

# --- Nouvelle barre de recherche dans la ToolBar ---
$SearchBox = New-Object System.Windows.Controls.TextBox
$SearchBox.Width = 200
$SearchBox.Height = 26
$SearchBox.Margin = "10,0,5,0"
$SearchBox.Background = "#2A2A2A"
$SearchBox.Foreground = "White"
$SearchBox.BorderBrush = "#555"

$BtnSearch = New-Object System.Windows.Controls.Button
$BtnSearch.Width = 26
$BtnSearch.Height = 26
$BtnSearch.Background = "Transparent"
$BtnSearch.BorderThickness = 0
$BtnSearch.Cursor = "Hand"

$searchIconPath = Join-Path $IconsDir "send.png"
if (Test-Path $searchIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$searchIconPath)
    $img.Width = 16
    $img.Height = 16
    $BtnSearch.Content = $img
}

$Toolbar.Items.Add($SearchBox) | Out-Null
$Toolbar.Items.Add($BtnSearch) | Out-Null

# --- Boutons de scroll horizontal ---
$btnLeft = New-Object System.Windows.Controls.Button
$btnLeft.Width = 20
$btnLeft.Height = 20
$btnLeft.Margin = "5,0,0,0"
$btnLeft.Background = "Transparent"
$btnLeft.BorderThickness = 0
$btnLeft.Foreground = "White"

$leftIconPath = Join-Path $IconsDir "left.png"
if (Test-Path $leftIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$leftIconPath)
    $img.Width = 16
    $img.Height = 16
    $btnLeft.Content = $img
} else {
    $btnLeft.Content = "<"
}

$btnRight = New-Object System.Windows.Controls.Button
$btnRight.Width = 20
$btnRight.Height = 20
$btnRight.Margin = "0,0,5,0"
$btnRight.Background = "Transparent"
$btnRight.BorderThickness = 0
$btnRight.Foreground = "White"

$rightIconPath = Join-Path $IconsDir "right.png"
if (Test-Path $rightIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$rightIconPath)
    $img.Width = 16
    $img.Height = 16
    $btnRight.Content = $img
} else {
    $btnRight.Content = ">"
}

$btnStripPanel = New-Object System.Windows.Controls.StackPanel
$btnStripPanel.Orientation = "Horizontal"

$scrollViewer = New-Object System.Windows.Controls.ScrollViewer
$scrollViewer.HorizontalScrollBarVisibility = "Hidden"
$scrollViewer.VerticalScrollBarVisibility = "Disabled"
$scrollViewer.Content = $btnStripPanel
$scrollViewer.Width = 350
$scrollViewer.Margin = "10,0,10,0"

$Toolbar.Items.Add($btnLeft)      | Out-Null
$Toolbar.Items.Add($scrollViewer) | Out-Null
$Toolbar.Items.Add($btnRight)     | Out-Null

$btnLeft.Add_Click({
    $scrollViewer.ScrollToHorizontalOffset([Math]::Max(0, $scrollViewer.HorizontalOffset - 50))
})
$btnRight.Add_Click({
    $scrollViewer.ScrollToHorizontalOffset($scrollViewer.HorizontalOffset + 50)
})

function Get-ActiveInfo {
    if (-not $Tabs.SelectedItem) { return $null }
    return $Tabs.SelectedItem.Tag
}

function Get-ActiveEditor {
    $info = Get-ActiveInfo
    if (-not $info) { return $null }
    return $info.Editor
}

# --- Mise � jour de la barre d��tat (ligne / colonne / mots) ---
function Update-Status {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $caretIndex = $editor.CaretOffset
    $text = $editor.Text

    if ($caretIndex -gt $text.Length) { $caretIndex = $text.Length }

    $before = $text.Substring(0, $caretIndex)
    $lines = $before -split "`r?`n"

    $line = $lines.Count
    $col  = $lines[-1].Length + 1

    $StatusPos.Text = "Ligne $line, Col $col"

    $words = ($text -split "\s+").Count
    $StatusWords.Text = "Mots : $words"
}

# --- Cr�ation d�un nouvel onglet avec AvalonEdit ---
function New-Tab {
    param(
        [string]$FilePath = $null
    )

    $NoTabsLogo.Visibility = "Collapsed"

    $tabCount = $Tabs.Items.Count + 1

    # Cr�er l�onglet
    $tab = New-Object System.Windows.Controls.TabItem
    if ($FilePath) {
        $tab.Header = [IO.Path]::GetFileName($FilePath)
    } else {
        $tab.Header = "Untitled $tabCount"
    }
    if ($TabItemStyle) { $tab.Style = $TabItemStyle }

    # Conteneur principal
    $grid = New-Object System.Windows.Controls.Grid
    $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height="*" }))

    # --- AVALONEDIT ---
    $editor = New-Object ICSharpCode.AvalonEdit.TextEditor
    $editor.FontFamily = "Consolas"
    $editor.FontSize = 14
    $editor.ShowLineNumbers = $true
    $editor.Background = "#2A2A2A"
    $editor.Foreground = "White"
    $editor.HorizontalAlignment = "Stretch"
    $editor.VerticalAlignment = "Stretch"

    # --- SYNTAXE AUTOMATIQUE ---
    if ($FilePath) {
        $ext = [IO.Path]::GetExtension($FilePath).ToLower()

        switch ($ext) {
            ".ps1" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("PowerShell")
            }
            ".bat" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("Batch")
            }
            ".json" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("JavaScript")
            }
            ".xml" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("XML")
            }
            ".cs" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("C#")
            }
            ".java" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("JAVA")
            }
            ".html" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("HTML")
            }
            ".java" {
                # Chargement syntaxe ECB (si tu as un fichier ecb.xshd)
                try {
                    $reader = [System.Xml.XmlReader]::Create("libs\syntax\java.xshd")
                    $editor.SyntaxHighlighting = 
                        [ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader]::Load(
                            $reader,
                            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance
                        )
                } catch {
                    $editor.SyntaxHighlighting = $null
                }
            }
            ".ecb" {
                # Chargement syntaxe ECB (si tu as un fichier ecb.xshd)
                try {
                    $reader = [System.Xml.XmlReader]::Create("libs\syntax\ecb.xshd")
                    $editor.SyntaxHighlighting = 
                        [ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader]::Load(
                            $reader,
                            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance
                        )
                } catch {
                    $editor.SyntaxHighlighting = $null
                }
            }
            default {
                $editor.SyntaxHighlighting = $null
            }
        }
    } else {
        # Par d�faut si pas de fichier ? PowerShell (comme ton code original)
        $editor.SyntaxHighlighting = 
            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("PowerShell")
    }

    # --- DRAG & DROP ---
    $editor.AllowDrop = $true
    $editor.Add_Drop({
        param($sender, $e)

        if ($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)) {
            $files = $e.Data.GetData([Windows.DataFormats]::FileDrop)

            if ($files.Count -gt 0) {
                $file = $files[0]

                if (Test-Path $file) {
                    $sender.Text = Get-Content $file -Raw

                    $tab = $Tabs.SelectedItem
                    if ($tab) {
                        $tab.Header = [IO.Path]::GetFileName($file)
                        $tab.Tag.Path = $file
                    }

                    $SolutionList.Items.Add([pscustomobject]@{
                        Name = [IO.Path]::GetFileName($file)
                        Path = $file
                        Tab  = $tab
                    })
                }
            }
        }
    })

    # Tag = Editor + Path
    $tab.Tag = [pscustomobject]@{
        Editor = $editor
        Path   = $FilePath
    }

    # Si on a un fichier, charger le contenu et l�ajouter dans SolutionList
    if ($FilePath -and (Test-Path $FilePath)) {
        $editor.Text = Get-Content $FilePath -Raw

        $SolutionList.Items.Add([pscustomobject]@{
            Name = [IO.Path]::GetFileName($FilePath)
            Path = $FilePath
            Tab  = $tab
        })
    }

    # Mise � jour de la barre d��tat
    $editor.Add_TextChanged({ Update-Status })
    $editor.Add_KeyDown({ Update-Status })
    $editor.Add_MouseDown({ Update-Status })

    [System.Windows.Controls.Grid]::SetRow($editor, 0)
    $grid.Children.Add($editor)

    ApplyThemeToEditor -editor $editor

    $tab.Content = $grid
    $Tabs.Items.Add($tab)
    $Tabs.SelectedItem = $tab

    # Bouton fermer
    $tab.ApplyTemplate()
    $closeBtn = $tab.Template.FindName("CloseBtn", $tab)

    $closeBtn.Add_Click({
        $parentTab = $this.TemplatedParent
        if ($parentTab) {
            $tabToRemove = $parentTab

            $toDelete = $null
            foreach ($item in $SolutionList.Items) {
                if ($item.Tab -eq $tabToRemove) {
                    $toDelete = $item
                    break
                }
            }
            if ($toDelete) {
                $SolutionList.Items.Remove($toDelete)
            }

            $Tabs.Items.Remove($parentTab)

            # --- Afficher le logo si plus aucun onglet ---
            if ($Tabs.Items.Count -eq 0) {
                $NoTabsLogo.Visibility = "Visible"
            }
        }
    })

    Update-Status
}

function Search-GenerateResults {
    param($editor, $query)

    $SearchResults.Items.Clear()

    if ([string]::IsNullOrWhiteSpace($query)) {
        $SearchResults.Visibility = "Collapsed"
        return
    }

    $text = $editor.Text
    $lines = $text -split "`n"

    foreach ($i in 0..($lines.Count - 1)) {
        if ($lines[$i] -match [regex]::Escape($query)) {
            $SearchResults.Items.Add("Ligne $($i+1) : $($lines[$i].Trim())")
        }
    }

    if ($SearchResults.Items.Count -gt 0) {
        $SearchResults.Visibility = "Visible"
    } else {
        $SearchResults.Visibility = "Collapsed"
    }
}

# Double-clic sur un r�sultat ? aller � la ligne
$SearchResults.Add_MouseDoubleClick({
    $tab = $Tabs.SelectedItem
    if (-not $tab) { return }

    $editor = $tab.Tag.Editor
    if (-not $editor) { return }

    $selected = $SearchResults.SelectedItem
    if (-not $selected) { return }

    if ($selected -match "Ligne (\d+)") {
        $line = [int]$matches[1]

        $editor.ScrollToLine($line)
        $offset = $editor.Document.GetOffset($line, 0)
        $editor.Select($offset, 0)
        $editor.Focus()
    }
})

# Recherche en temps r�el
$SearchBox.Add_TextChanged({
    $tab = $Tabs.SelectedItem
    if ($tab -and $tab.Tag.Editor) {
        Search-GenerateResults $tab.Tag.Editor $SearchBox.Text
    }
})

# Bouton de recherche
$BtnSearch.Add_Click({
    $tab = $Tabs.SelectedItem
    if ($tab -and $tab.Tag.Editor) {
        Search-GenerateResults $tab.Tag.Editor $SearchBox.Text
    }
})

# --- Explorateur de projet ---

# --- Historique de navigation ---
function Push-History {
    param([string]$path)

    if ($script:NavIndex -lt $script:NavHistory.Count - 1) {
        $script:NavHistory.RemoveRange($script:NavIndex+1, $script:NavHistory.Count - ($script:NavIndex+1))
    }

    $script:NavHistory.Add($path)
    $script:NavIndex = $script:NavHistory.Count - 1
}

# --- Rafra�chir l�explorateur ---
function Refresh-ProjectExplorer {
    param(
        [string]$Path,
        [bool]$AddHistory = $false
    )

    if (-not $Path) { $Path = $ProjectRoot }
    if (-not (Test-Path $Path)) { return }

    $script:CurrentProjectDir = $Path
    if ($AddHistory) { Push-History $Path }

    $ProjectList.Items.Clear()

    $items = Get-ChildItem $Path | Sort-Object PSIsContainer, Name

    foreach ($it in $items) {

    $iconPath = if ($it.PSIsContainer) {
        Join-Path $IconsDir "folder.png"
    } else {
        Join-Path $IconsDir "file.png"
    }

    $iconImage = $null
    if (Test-Path $iconPath) {
        $iconImage = New-Object System.Windows.Media.Imaging.BitmapImage
        $iconImage.BeginInit()
        $iconImage.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
        $iconImage.CacheOption = "OnLoad"
        $iconImage.EndInit()
    }

    $ProjectList.Items.Add([pscustomobject]@{
        Name     = $it.Name
        Type     = if ($it.PSIsContainer) { "Dossier" } else { "Fichier" }
        Date     = $it.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
        Icon     = $iconImage
        FullPath = $it.FullName
        IsFolder = $it.PSIsContainer
    }) | Out-Null
    }
}

function Set-ButtonIcon {
    param($button, $fileName)

    if ($null -eq $button) {
        Write-Host "Button is NULL"
        return
    }

    $iconPath = Join-Path $IconsDir $fileName

    if (-not (Test-Path $iconPath)) {
        Write-Host "Icon not found: $iconPath"
        return
    }

    $img = New-Object System.Windows.Controls.Image
    $bmp = New-Object System.Windows.Media.Imaging.BitmapImage

    $bmp.BeginInit()
    $bmp.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
    $bmp.CacheOption = "OnLoad"
    $bmp.EndInit()

    $img.Source = $bmp
    $img.Width = 16
    $img.Height = 16

    $button.Content = $img
}

Set-ButtonIcon $BtnBack    "back.png"
Set-ButtonIcon $BtnForward "forward.png"
Set-ButtonIcon $BtnRefresh "refresh.png"
Set-ButtonIcon $BtnAddRef  "addref.png"

# --- Clic droit : menu contextuel ---
$ctx = New-Object System.Windows.Controls.ContextMenu

# Ouvrir
$miOpen = New-Object System.Windows.Controls.MenuItem
$miOpen.Header = $DIALOG["BTN_OPEN"]
$miOpen.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel -and -not $sel.IsFolder) {
        New-Tab
        $editor = Get-ActiveEditor
        $editor.Text = (Get-Content $sel.FullPath -Raw)
        $Tabs.SelectedItem.Header = $sel.Name
        Update-Status
    }
})

# Supprimer
$miDelete = New-Object System.Windows.Controls.MenuItem
$miDelete.Header = $DIALOG["MSG_DELETE"]
$miDelete.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel) {
        if ([System.Windows.MessageBox]::Show($DIALOG["MSG_DELETE"], "Confirm", "YesNo","Warning") -eq "Yes") {
            Remove-Item $sel.FullPath -Recurse -Force
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Renommer
$miRename = New-Object System.Windows.Controls.MenuItem
$miRename.Header = $DIALOG["MSG_RENAME"]
$miRename.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel) {
        $newName = [Microsoft.VisualBasic.Interaction]::InputBox($DIALOG["MSG_RENAME"], "Renommer", $sel.Name)
        if ($newName -and $newName -ne $sel.Name) {
            $dir = Split-Path $sel.FullPath -Parent
            $newPath = Join-Path $dir $newName
            Rename-Item -Path $sel.FullPath -NewName $newName -Force
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Nouveau fichier
$miNewFile = New-Object System.Windows.Controls.MenuItem
$miNewFile.Header = $DIALOG["MSG_NEWFILE"]
$miNewFile.Add_Click({
    $ProjectList.Focus()
    $path = Join-Path $script:CurrentProjectDir "nouveau.ps1"
    if (-not (Test-Path $path)) {
        "" | Out-File $path -Encoding UTF8
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
    }
})

# Nouveau dossier
$miNewFolder = New-Object System.Windows.Controls.MenuItem
$miNewFolder.Header = "Nouveau dossier"
$miNewFolder.Add_Click({
    $ProjectList.Focus()
    $name = [Microsoft.VisualBasic.Interaction]::InputBox("Nom du dossier :", "Nouveau dossier", "NouveauDossier")
    if ($name) {
        $path = Join-Path $script:CurrentProjectDir $name
        if (-not (Test-Path $path)) {
            New-Item -ItemType Directory -Path $path | Out-Null
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Ajouter au menu
$ctx.Items.Add($miOpen)      | Out-Null
$ctx.Items.Add($miDelete)    | Out-Null
$ctx.Items.Add($miRename)    | Out-Null
$ctx.Items.Add($miNewFile)   | Out-Null
$ctx.Items.Add($miNewFolder) | Out-Null

# Attacher le menu
$ProjectList.ContextMenu = $ctx

# --- Double-clic : ouvrir fichier ou dossier ---
$ProjectList.Add_MouseDoubleClick({
    $sel = $ProjectList.SelectedItem
    if (-not $sel) { return }
    if ($sel.IsFolder) {
        Refresh-ProjectExplorer -Path $sel.FullPath -AddHistory:$true
        return
    }
    if (-not (Test-Path $sel.FullPath)) {
        return
    }
    if ($sel.FullPath -match "\.(ps1|txt|json|xml|cfg|ini)$") {
        New-Tab
        $editor = Get-ActiveEditor
        $editor.Text = (Get-Content $sel.FullPath -Raw)
        $Tabs.SelectedItem.Header = $sel.Name
        return
    }
    Start-Process $sel.FullPath
})


# --- Boutons navigation ---
$BtnRefresh.Add_Click({
    Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
})

$BtnBack.Add_Click({
    if ($script:NavIndex -gt 0) {
        $script:NavIndex--
        $path = $script:NavHistory[$script:NavIndex]
        Refresh-ProjectExplorer -Path $path -AddHistory:$false
    }
})

$BtnForward.Add_Click({
    if ($script:NavIndex -lt $script:NavHistory.Count - 1) {
        $script:NavIndex++
        $path = $script:NavHistory[$script:NavIndex]
        Refresh-ProjectExplorer -Path $path -AddHistory:$false
    }
})

$BtnAddRef.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        $dest = Join-Path $script:CurrentProjectDir ([IO.Path]::GetFileName($dlg.FileName))
        Copy-Item $dlg.FileName $dest -Force
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
    }
})

# --- Boutons dynamiques depuis le dossier btns ---

function Load-CustomButtons {
    param(
        [string]$BtnsDir,
        [string]$IconsDir
    )

    $buttons = @()

    if (-not (Test-Path $BtnsDir)) {
        return $buttons
    }

    $allowedExt = ".txt",".exe",".cmd",".cs",".bat",".ps1"

    Get-ChildItem $BtnsDir | Where-Object {
        -not $_.PSIsContainer -and $allowedExt -contains $_.Extension.ToLower()
    } | ForEach-Object {

        $file = $_
        $name = [IO.Path]::GetFileNameWithoutExtension($file.Name)

        $btn = New-Object System.Windows.Controls.Button
        $btn.Margin = "2,0,2,0"
        $btn.Padding = "4,2,4,2"
        $btn.Background = "#444444"
        $btn.Foreground = "White"
        $btn.BorderThickness = 0

        $stack = New-Object System.Windows.Controls.StackPanel
        $stack.Orientation = "Horizontal"

        $iconPath = Join-Path $IconsDir ($name + ".png")
        if (Test-Path $iconPath) {
            $img = New-Object System.Windows.Controls.Image
            $bmp = New-Object System.Windows.Media.Imaging.BitmapImage

            $bmp.BeginInit()
            $bmp.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
            $bmp.CacheOption = "OnLoad"
            $bmp.EndInit()

            $img.Source = $bmp
            $img.Width = 16
            $img.Height = 16
            $img.Margin = "0,0,5,0"

            $stack.Children.Add($img) | Out-Null
        }

        $txt = New-Object System.Windows.Controls.TextBlock
        $txt.Text = $name
        $txt.Foreground = "White"
        $stack.Children.Add($txt) | Out-Null

        $btn.Content = $stack

        # ? LA LIGNE QUI R�GLE TOUT
        $btn.Tag = $file.FullName

        $btn.Add_Click({
            Start-Process $this.Tag
        })

        $buttons += $btn
    }

    return $buttons
}

$buttons = Load-CustomButtons -BtnsDir $BtnsDir -IconsDir $IconsDir

$btnStripPanel.Children.Clear()
foreach ($b in $buttons) {
    $btnStripPanel.Children.Add($b) | Out-Null
}

# --- D�marrage ---
Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$true
New-Tab

Write-Host "BtnAddRef type = $($BtnAddRef.GetType().FullName)"

if ($args.Count -gt 0) {
    foreach ($file in $args) {
        if (Test-Path $file) {
            New-Tab
            $editor = Get-ActiveEditor
            $editor.Text = Get-Content $file -Raw
            $Tabs.SelectedItem.Header = [IO.Path]::GetFileName($file)
        }
    }
}

$BtnSettings.Add_Click({
    # Charger la fen�tre de param�tres
    $xamlPath = "$Root\xaml\settings.xaml"
    $xaml = Get-Content $xamlPath -Raw
    $reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
    $settingsWindow = [Windows.Markup.XamlReader]::Load($reader)

    # D�finir la fen�tre parente
    $settingsWindow.Owner = $Window

    # Charger la logique du fichier settings.ps1
    . "$Root\windows\settings.ps1"

    # Recharger les th�mes apr�s fermeture
    Reload-Themes
})

function Reload-Themes {

    $ThemeFile = "$Root\save\themes.txt"
    $ThemeBarFile = "$Root\save\themesbar.txt"

    # Th�me clair / sombre
    if (Test-Path $ThemeFile) {
        $theme = (Get-Content $ThemeFile -Raw).Trim()

        if ($theme -eq "0") {
            # Th�me clair
            $Window.Background = "#F0F0F0"
            $Tabs.Background = "#FFFFFF"
            $SearchResults.Background = "#FFFFFF"
            $ProjectPane.Background = "#EEEEEE"
            $Toolbar.Background = "#DDDDDD"
        }
        else {
            # Th�me sombre
            $Window.Background = "#1E1E1E"
            $Tabs.Background = "#1E1E1E"
            $SearchResults.Background = "#1E1E1E"
            $ProjectPane.Background = "#1A1025"

            # Couleur de barre personnalis�e
            if (Test-Path $ThemeBarFile) {
                $Toolbar.Background = (Get-Content $ThemeBarFile -Raw).Trim()
            }
            else {
                $Toolbar.Background = "#333333"
            }
        }
    }
}

Reload-Themes

$window.ShowDialog() | Out-Null