Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path "$PSScriptRoot\libs\net462\border\WindowStyler.dll"

# ============================
#   Chargement des traductions
# ============================

$DialogFile = Join-Path $ScriptRoot "editor.dialog.txt"
$Translations = @{}

if (Test-Path $DialogFile) {
    $lines = Get-Content $DialogFile | Where-Object { $_ -match "=" }

    foreach ($line in $lines) {
        $split = $line.Split("=")
        if ($split.Count -ge 2) {
            $key = $split[0].Trim()
            $value = ($split[1..($split.Count-1)] -join "=").Trim()
            $Translations[$key] = $value
        }
    }
} else {
    Write-Host "Fichier de traduction introuvable : $DialogFile"
}

# ============================
#   Application des traductions
# ============================

function Apply-Translations {

    if ($Translations.ContainsKey("BTN_NEWPROJECTCONTINU")) {
        $BtnContinue.Content = $Translations["BTN_NEWPROJECTCONTINU"]
    }

    if ($Translations.ContainsKey("BTN_IMPORTE_FILE")) {
        $BtnImport.Content = $Translations["BTN_IMPORTE_FILE"]
    }

    if ($Translations.ContainsKey("BTN_CREATE_PROJECT")) {
        $BtnCreate.Content = $Translations["BTN_CREATE_PROJECT"]
    }

    if ($Translations.ContainsKey("EXPLORER_TITLE_TEXT")) {
        # Le TextBlock de l'explorateur est dans le XAML
        # On le r�cup�re via FindName
        $ExplorerTitle = $window.FindName("ExplorerTitle")
        if ($ExplorerTitle) {
            $ExplorerTitle.Text = $Translations["EXPLORER_TITLE_TEXT"]
        }
    }

    # Footer
    if ($Translations.ContainsKey("FILE_RECENT")) {
        # Tu peux ajouter un label dans le footer si tu veux
    }

    # Barre de recherche
    if ($Translations.ContainsKey("BTN_SEARCH")) {
        $SearchBox.Text = $Translations["BTN_SEARCH"]
    }
}

# =========================
#   Splash screen
# =========================
$splashPath = Join-Path $PSScriptRoot "splash"
if (-not (Test-Path $splashPath)) {
    New-Item -ItemType Directory -Path $splashPath | Out-Null
}
Start-Sleep -Seconds 1
$readyFile = Join-Path $splashPath "ready.txt"
"READY=1" | Out-File -FilePath $readyFile -Encoding UTF8

# ============================
#   XAML
# ============================
$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Ecrion-ExilBatch Studio"
        WindowStyle="SingleBorderWindow"
        ResizeMode="NoResize"
        Width="950" Height="600"
        Background="#1E1E1E"
        AllowsTransparency="False"
        Name="MainWin">

    <Grid>

        <!-- Barre de titre -->
        <Grid Background="#2D2D30" Height="48" VerticalAlignment="Top" Name="TopBar">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="Auto" />
                <ColumnDefinition Width="*" />
                <ColumnDefinition Width="Auto" />
            </Grid.ColumnDefinitions>

            <!-- Menu hamburger -->
            <Button Name="BtnMenu"
                    Width="40" Height="40"
                    Margin="8,4,0,4"
                    Background="#2D2D30"
                    BorderThickness="0">
                <Image Name="ImgMenu" Stretch="Uniform"/>
            </Button>

            <TextBlock Grid.Column="1"
                       Text="Ecrion-ExilBatch Studio"
                       Margin="10,14,0,0"
                       Foreground="White"
                       FontFamily="Segoe UI"
                       FontSize="11"
                       FontWeight="Bold"
                       VerticalAlignment="Top"/>
        </Grid>

        <!-- Contenu principal -->
        <Grid Margin="0,48,0,50">

            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- Barre de recherche -->
            <Grid Grid.Row="0" Margin="220,8,20,8">
                <TextBox Name="SearchBox"
                         Height="32"
                         Background="#3A3A3A"
                         Foreground="Gray"
                         BorderThickness="0"
                         FontFamily="Segoe UI"
                         FontSize="10"
                         Text="Rechercher un projet..."
                         VerticalContentAlignment="Center"/>
                <Rectangle Height="2"
                           VerticalAlignment="Bottom"
                           Fill="#307FFF"
                           RadiusX="2" RadiusY="2"/>
            </Grid>

            <!-- Zone principale -->
            <Grid Grid.Row="1" Margin="10,10,10,10">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="280"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>

                <!-- Explorateur / r�cents -->
                <StackPanel Grid.Column="0" Background="#252526">
                    <TextBlock Text="Explorateur"
                               Margin="10,10,0,10"
                               Foreground="#8A2BE2"
                               FontFamily="Segoe UI"
                               FontSize="10"
                               FontWeight="Bold"/>

                    <ListView Name="RecentList"
                              Margin="10,0,10,10"
                              Background="#1E1E1E"
                              Foreground="White"
                              BorderThickness="0"
                              AllowDrop="True">
                        <ListView.ItemTemplate>
                            <DataTemplate>
                                <StackPanel Orientation="Horizontal" Margin="2">
                                    <Image Width="16" Height="16" Margin="0,0,6,0"
                                           Source="{Binding Icon}"/>
                                    <StackPanel>
                                        <TextBlock Text="{Binding Name}" FontSize="10"/>
                                        <TextBlock Text="{Binding Date}" FontSize="9" Foreground="Gray"/>
                                    </StackPanel>
                                </StackPanel>
                            </DataTemplate>
                        </ListView.ItemTemplate>
                    </ListView>
                </StackPanel>

                <!-- Panneau droit : boutons -->
                <StackPanel Grid.Column="1"
                            Background="#1E1E1E"
                            HorizontalAlignment="Center"
                            VerticalAlignment="Top"
                            Margin="0,80,0,0">

                    <Button Name="BtnContinue"
                            Content="Lancer l'�diteur sans code"
                            Width="260" Height="42"
                            Margin="0,0,0,10"
                            Background="#307FFF"
                            Foreground="White"
                            BorderThickness="0"
                            FontFamily="Segoe UI"
                            FontSize="10"
                            HorizontalContentAlignment="Center"
                            Cursor="Hand">
                        <Button.Template>
                            <ControlTemplate TargetType="Button">
                                <Border CornerRadius="21"
                                        Background="{TemplateBinding Background}">
                                    <ContentPresenter HorizontalAlignment="Center"
                                                      VerticalAlignment="Center"
                                                      Margin="10,0,10,0"/>
                                </Border>
                            </ControlTemplate>
                        </Button.Template>
                    </Button>

                    <Button Name="BtnImport"
                            Content="Importer un fichier"
                            Width="260" Height="42"
                            Margin="0,0,0,10"
                            Background="#2F2F2F"
                            Foreground="White"
                            BorderThickness="0"
                            FontFamily="Segoe UI"
                            FontSize="10"
                            HorizontalContentAlignment="Center"
                            Cursor="Hand">
                        <Button.Template>
                            <ControlTemplate TargetType="Button">
                                <Border CornerRadius="21"
                                        Background="{TemplateBinding Background}">
                                    <ContentPresenter HorizontalAlignment="Center"
                                                      VerticalAlignment="Center"
                                                      Margin="10,0,10,0"/>
                                </Border>
                            </ControlTemplate>
                        </Button.Template>
                    </Button>

                    <Button Name="BtnCreate"
                            Content="Cr�er un projet"
                            Width="260" Height="42"
                            Margin="0,0,0,10"
                            Background="#2F2F2F"
                            Foreground="White"
                            BorderThickness="0"
                            FontFamily="Segoe UI"
                            FontSize="10"
                            HorizontalContentAlignment="Center"
                            Cursor="Hand">
                        <Button.Template>
                            <ControlTemplate TargetType="Button">
                                <Border CornerRadius="21"
                                        Background="{TemplateBinding Background}">
                                    <ContentPresenter HorizontalAlignment="Center"
                                                      VerticalAlignment="Center"
                                                      Margin="10,0,10,0"/>
                                </Border>
                            </ControlTemplate>
                        </Button.Template>
                    </Button>
                </StackPanel>
            </Grid>
        </Grid>

        <!-- Footer -->
        <Grid Background="#2D2D30" Height="50" VerticalAlignment="Bottom">
            <TextBlock Text="ExilBatch Explorer"
                       Margin="10,0,0,0"
                       VerticalAlignment="Center"
                       Foreground="Gray"
                       FontFamily="Segoe UI"
                       FontSize="10"/>
        </Grid>
    </Grid>
</Window>
"@

# ============================
#   Charger le XAML
# ============================
$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

# R�cup�ration des contr�les
$BtnMenu     = $window.FindName("BtnMenu")
$ImgMenu     = $window.FindName("ImgMenu")
$BtnContinue = $window.FindName("BtnContinue")
$BtnImport   = $window.FindName("BtnImport")
$BtnCreate   = $window.FindName("BtnCreate")
$RecentList  = $window.FindName("RecentList")
$SearchBox   = $window.FindName("SearchBox")
$TopBar      = $window.FindName("TopBar")

$window.Add_SourceInitialized({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#F01D6E", "#333333")
})

$window.Add_Deactivated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#BA547A", "#212020")
})

$window.Add_Activated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#F01D6E", "#333333")
})

# ============================
#   Logicque identique
# ============================
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SaveDir  = Join-Path $ScriptRoot "save"
$SaveFile = Join-Path $SaveDir "save.txt"

if (-not (Test-Path $SaveDir))  { New-Item -ItemType Directory -Path $SaveDir | Out-Null }
if (-not (Test-Path $SaveFile)) { "" | Out-File $SaveFile }

# ============================
#   Ic�ne menu hamburger
# ============================
$menuPng      = Join-Path $ScriptRoot "ICO\menu.png"
$menuAfterPng = Join-Path $ScriptRoot "ICO\menu_after.png"
$script:MenuOpen = $false

if (Test-Path $menuPng) {
    $ImgMenu.Source = [System.Windows.Media.Imaging.BitmapImage]::new([Uri]$menuPng)
}

# ============================
#   Charger r�cents
# ============================
$script:RecentItems = @()

function Load-Recent {
    $RecentList.Items.Clear()
    $script:RecentItems = @()

    $recent = Get-Content $SaveFile | Where-Object { $_ -ne "" }

    foreach ($file in $recent) {
        if (-not (Test-Path $file)) { continue }
        $fi = Get-Item $file

        # Ic�ne du fichier
        $iconPath = $null
        try {
            $ico = [System.Drawing.Icon]::ExtractAssociatedIcon($fi.FullName)
            if ($ico) {
                $tmp = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), [System.IO.Path]::GetRandomFileName() + ".png")
                $bmp = $ico.ToBitmap()
                $bmp.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png)
                $iconPath = $tmp
            }
        } catch {}

        # Correction PowerShell
        $iconValue = if ($iconPath) { $iconPath } else { "" }

        $obj = New-Object PSObject -Property @{
            Name = $fi.Name
            Date = $fi.CreationTime.ToString("dd/MM/yyyy")
            Full = $fi.FullName
            Icon = $iconValue
        }

        $script:RecentItems += $obj
        $RecentList.Items.Add($obj) | Out-Null
    }
}

# --- Settings ---
$RootPath = Split-Path -Parent $ScriptRoot
$SettingsFile = Join-Path $RootPath "Panel\settings.txt"

$Settings = @{}

if (Test-Path $SettingsFile) {
    foreach ($line in Get-Content $SettingsFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $Settings[$matches[1].Trim()] = $matches[2].Trim()
        }
    }
}

function Get-Setting {
    param([string]$Key)
    if ($Settings.ContainsKey($Key)) { return $Settings[$Key] }
    return $null
}

$HideCmd = Get-Setting "Hidecmdicone"

# --- Fonction PRO pour lancer les .bat ---
function Launch-BAT {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        [System.Windows.Forms.MessageBox]::Show("$Path introuvable.")
        return
    }

    if ($HideCmd -eq "1") {
        Start-Process "WindowHide.exe" -ArgumentList "/file `"$Path`""
    }
    else {
        Start-Process $Path
    }
}

# ============================
#   Lancer main.bat / WindowHide.exe
# ============================
function Launch-Main($file) {
    $main = Join-Path $ScriptRoot "main.bat"
    $hide = Join-Path $ScriptRoot "WindowHide.exe"

    if (-not (Test-Path $main)) {
        [System.Windows.Forms.MessageBox]::Show("main.bat introuvable.")
        return
    }

    if ($file) {
        Add-Content $SaveFile $file

        if ($HideCmd -eq "1" -and (Test-Path $hide)) {
            Start-Process $main "`"$file`""
        }
        else {
            Start-Process $main "`"$file`""
        }
    }
    else {
        if ($HideCmd -eq "1" -and (Test-Path $hide)) {
            Start-Process "WindowHide.exe" -ArgumentList "/file `"$main`""
        }
        else {
            Start-Process $main
        }
    }

    $window.Close()
}

# ============================
#   �v�nements
# ============================

# Fermer
$BtnClose.Add_Click({ $window.Close() })

# Drag window
$TopBar.Add_MouseLeftButtonDown({
    $window.DragMove()
})

# Menu hamburger (toggle)
$BtnMenu.Add_Click({
    $script:MenuOpen = -not $script:MenuOpen
    if ($script:MenuOpen -and (Test-Path $menuAfterPng)) {
        $ImgMenu.Source = [System.Windows.Media.Imaging.BitmapImage]::new([Uri]$menuAfterPng)
    } else {
        if (Test-Path $menuPng) {
            $ImgMenu.Source = [System.Windows.Media.Imaging.BitmapImage]::new([Uri]$menuPng)
        }
    }
})

# Bouton "Lancer l'�diteur sans code"
$BtnContinue.Add_Click({
    Launch-Main $null
})

# Importer
$BtnImport.Add_Click({
    $fd = New-Object System.Windows.Forms.OpenFileDialog
    $fd.Filter = "Tous les fichiers|*.*"
    if ($fd.ShowDialog() -eq "OK") {
        Launch-Main $fd.FileName
    }
})

# Cr�er projet
$BtnCreate.Add_Click({
    $newProject = Join-Path $ScriptRoot "new_project.bat"
    if (Test-Path $newProject) {
        Start-Process $newProject
    } else {
        [System.Windows.MessageBox]::Show("new_project.bat introuvable.")
    }
})

# Double clic sur un projet
$RecentList.Add_MouseDoubleClick({
    if ($RecentList.SelectedItem) {
        Launch-Main $RecentList.SelectedItem.Full
    }
})

# Drag & Drop sur la liste
$RecentList.Add_Drop({
    $data = $_.Data
    if ($data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $files = $data.GetData([System.Windows.DataFormats]::FileDrop)
        if ($files.Count -gt 0) {
            Launch-Main $files[0]
        }
    }
})
$RecentList.Add_DragEnter({
    if ($_.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $_.Effects = "Copy"
    }
})

# Barre de recherche intelligente
$SearchBox.Add_GotFocus({
    if ($SearchBox.Text -eq "Rechercher un projet...") {
        $SearchBox.Text = ""
        $SearchBox.Foreground = "White"
    }
})
$SearchBox.Add_LostFocus({
    if ($SearchBox.Text -eq "") {
        $SearchBox.Text = "Rechercher un projet..."
        $SearchBox.Foreground = "Gray"
    }
})
$SearchBox.Add_TextChanged({
    if ($SearchBox.Text -eq "Rechercher un projet...") { return }

    $RecentList.Items.Clear()
    $query = $SearchBox.Text.ToLower()

    foreach ($item in $script:RecentItems) {
        if ($item.Name.ToLower().Contains($query) -or $item.Full.ToLower().Contains($query)) {
            $RecentList.Items.Add($item) | Out-Null
        }
    }
})

Apply-Translations
Load-Recent

$window.ShowDialog()