Set shell = CreateObject("WScript.Shell")
Set args = WScript.Arguments

' --- Si un argument est donn� ---
If args.Count > 0 Then
    RunCommand args(0)
    WScript.Quit
End If

' --- Sinon afficher le menu ---
menu = "=== Command Menu ===" & vbCrLf & vbCrLf
menu = menu & "/setting   -> Launch Setting_Panel.bat" & vbCrLf
menu = menu & "/update    -> Launch updatecheck.bat" & vbCrLf
menu = menu & "/install   -> Launch Installer.bat" & vbCrLf
menu = menu & "/packager  -> Launch packager.bat" & vbCrLf
menu = menu & "/consol    -> Launch consol.bat" & vbCrLf
menu = menu & "/BAT-EXE   -> Launch PackagerCSharp.bat" & vbCrLf & vbCrLf
menu = menu & "Enter your command :"

cmd = InputBox(menu, "Launcher")

If cmd <> "" Then RunCommand cmd

WScript.Quit


' --- Fonction d'ex�cution ---
Sub RunCommand(c)
    Select Case LCase(c)
        Case "/setting"
            shell.Run "Setting_Panel.bat", 1, False

        Case "/update"
            shell.Run "updatecheck.bat", 1, False

        Case "/install"
            shell.Run "Installer.bat", 1, False

        Case "/packager"
            shell.Run "packager.bat", 1, False

        Case "/consol"
            shell.Run "consol.bat", 1, False

        Case "/bat-exe"
            shell.Run "PackagerCSharp.bat", 1, False

        Case Else
            MsgBox "Unknown command: " & c, 16, "Error"
    End Select
End Sub
