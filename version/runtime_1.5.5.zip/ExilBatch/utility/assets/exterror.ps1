param(
    [string]$AppName,
    [string]$Extension
)

# --- Charger le texte traduit depuis showdialog.txt ---
$dialogFile = ".\showdialog.txt"
$translations = @{}

foreach ($line in Get-Content $dialogFile) {
    if ($line -match "^(.*?)=(.*)$") {
        $key = $matches[1].Trim()
        $value = $matches[2].Trim()
        $translations[$key] = $value
    }
}

# --- Identifiant à récupérer dans le fichier ---
$identifier = "ERROR_TEXT"

if (-not $translations.ContainsKey($identifier)) {
    $translatedText = "Texte introuvable dans showdialog.txt"
} else {
    $translatedText = $translations[$identifier]
}

# --- Construire le texte final ---
$message = @"
Erreur : le fichier $AppName n'a pas d'environnement portable associé au type de script ($Extension)

$translatedText

L'installation via le Store devrait corriger le problème.
"@

# --- Charger Windows Forms ---
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Créer la fenêtre ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "Erreur - $AppName ($Extension)"
$form.Size = New-Object System.Drawing.Size(500,300)
$form.StartPosition = "CenterScreen"

# --- Icône PNG personnalisée ---
$iconPath = ".\assets\ICO\error64x64.png"
if (Test-Path $iconPath) {
    $img = [System.Drawing.Image]::FromFile($iconPath)
    $form.Icon = [System.Drawing.Icon]::FromHandle($img.GetHicon())
}

# --- Zone de texte ---
$label = New-Object System.Windows.Forms.Label
$label.Text = $message
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20,20)
$form.Controls.Add($label)

# --- Bouton Store ---
$button = New-Object System.Windows.Forms.Button
$button.Text = "Ouvrir le Store"
$button.Location = New-Object System.Drawing.Point(20,200)
$button.Add_Click({
    Start-Process ".\store\store.bat"
})
$form.Controls.Add($button)

# --- Afficher la fenêtre ---
$form.ShowDialog()