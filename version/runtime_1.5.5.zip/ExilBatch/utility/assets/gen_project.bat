@echo off
cd  Tools
start ECB_Projet_generator.bat %1
exit