Ce fichier a était fait sous .NET 4.6.2
Créateur : SubvisionKenzo
.NET : 4.6.2