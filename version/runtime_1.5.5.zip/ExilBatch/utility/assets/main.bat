@echo off
setlocal enabledelayedexpansion
cd ..
rem === Détection automatique du fichier settings ===
for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found
)
exit /b

:found
echo loading : %settingsFile%
echo.
rem === Lecture du fichier et création des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%settingsFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem skip
    ) else (

        rem --- Ignore commentaires commençant par # ou ; ---
        echo !ligne! | findstr /r "^[#;]" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.
cd assets
set "name=main"
set "hide=hidden"
if exist %hide%.txt goto execut
if "%Hidecmdicone%"=="0" goto skip
if "%~1"=="" goto skipcheck
:skip

echo >> %hide%.txt

cmd /c start /min main.bat %1
exit
:execut
del %hide%.txt
:skipcheck
PowerShell -ExecutionPolicy Bypass -File %name%.ps1 %1
set ERR=%ERRORLEVEL%

if %ERR% NEQ 0 (
    start editor.vbs
    exit /b
)
exit > nul