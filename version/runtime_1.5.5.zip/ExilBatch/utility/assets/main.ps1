Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName WindowsFormsIntegration
Add-Type -Path "$PSScriptRoot\libs\net462\ICSharpCode.AvalonEdit.dll"
Add-Type -Path "$PSScriptRoot\libs\net462\border\WindowStyler.dll"

# --- Dossiers de base ---
$Root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigDir   = Join-Path $Root "config"
$IconsDir    = Join-Path $Root "ICO"
$ProjectRoot = Join-Path $Root "projet"
$BtnsDir     = Join-Path $Root "btns"

foreach ($d in @($ConfigDir,$IconsDir,$ProjectRoot,$BtnsDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}

# R�pertoire courant de l�explorateur
$script:CurrentProjectDir = $ProjectRoot
$script:NavHistory = New-Object System.Collections.Generic.List[string]
$script:NavIndex   = -1

# --- Chargement des textes depuis editor.dialog.txt ---
$DialogFile = Join-Path $Root "editor.dialog.txt"
$DIALOG = @{}
if (Test-Path $DialogFile) {
    Get-Content $DialogFile | ForEach-Object {
        if ($_ -match "=") {
            $k,$v = $_ -split "=",2
            $DIALOG[$k.Trim()] = $v.Trim()
        }
    }
} else {
    $DIALOG["TITLE"]       = "Ecrion Editor"
    $DIALOG["BTN_NEW"]     = "Nouveau"
    $DIALOG["BTN_OPEN"]    = "Ouvrir"
    $DIALOG["BTN_SAVE"]    = "Enregistrer"
    $DIALOG["BTN_RUN"]     = "Ex�cuter"
    $DIALOG["BTN_DEBUG"]   = "D�boguer"
    $DIALOG["BTN_PROJECT"] = "Projet"
    $DIALOG["BTN_SEARCH"]  = "Rechercher"
    $DIALOG["LBL_PROJECT"] = "Explorateur de projet"
    $DIALOG["LBL_REFRESH"] = "Actualiser"
    $DIALOG["MSG_DELETE"]  = "Supprimer cet �l�ment ?"
    $DIALOG["MSG_RENAME"]  = "Nouveau nom :"
    $DIALOG["MSG_NEWFILE"] = "Nouveau fichier"
    $DIALOG["PROP_TITLE"]    = "Propri�t�s"
    $DIALOG["PROP_NAME"]     = "Nom"
    $DIALOG["PROP_EXT"]      = "Extension"
    $DIALOG["PROP_SIZE"]     = "Taille"
    $DIALOG["PROP_CREATED"]  = "Cr�� le"
    $DIALOG["PROP_MODIFIED"] = "Modifi� le"
    $DIALOG["BTN_OK"]        = "OK"
    $DIALOG["LBL_PROJECT"] = "..."
    $DIALOG["FILE"]        = "File"
    $DIALOG["FILE_RECENT"] = "Ouvrir un ficheir recent"
    $DIALOG["FILE_SAVEALL"] = "Anregistrer tout"
}

# ============================================================
#  LECTURE DU FICHIER DE CONFIGURATION
# ============================================================

$themeFile = ".\save\bordertheme.txt"

if (Test-Path $themeFile) {
    $themeValue = (Get-Content $themeFile).Trim()
} else {
    # Valeur par d�faut si le fichier n'existe pas
    $themeValue = "1"
    "1" | Out-File $themeFile
}

Write-Host "Theme value = $themeValue"

# --- XAML de la fen�tre principale ---
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:avalon="http://icsharpcode.net/sharpdevelop/avalonedit"
        xmlns:sys="clr-namespace:System;assembly=mscorlib"
        Title="Ecrion Editor"
        Width="1200" Height="800"
        Background="#1E1E1E"
        WindowStartupLocation="CenterScreen"
        WindowStyle="None"
        ResizeMode="CanResize">

    <Window.Resources>

        <!-- STYLE DES TABS (style VS Code, arrondi 4px) -->
        <Style x:Key="TabItemStyle" TargetType="TabItem">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="Padding" Value="10,4"/>
            <Setter Property="Margin" Value="2,0"/>
            <Setter Property="Background" Value="#2D2D2D"/>
            <Setter Property="MinWidth" Value="120"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TabItem">
                        <Grid>
                            <Border x:Name="TabBorder"
                                    Background="{TemplateBinding Background}"
                                    CornerRadius="4"
                                    Padding="8,4">
                                <StackPanel Orientation="Horizontal">
                                    <ContentPresenter
                                        Content="{TemplateBinding Header}"
                                        VerticalAlignment="Center"
                                        Margin="0,0,6,0"/>
                                    <Button x:Name="CloseBtn"
                                            Content="�"
                                            Width="18" Height="18"
                                            Background="Transparent"
                                            Foreground="red"
                                            BorderThickness="0"
                                            Padding="0"
                                            Cursor="Hand"/>
                                </StackPanel>
                            </Border>

                            <Border x:Name="Underline"
                                    Height="2"
                                    VerticalAlignment="Bottom"
                                    CornerRadius="2"
                                    Background="#555"
                                    Margin="6,0,6,0"/>
                        </Grid>

                        <ControlTemplate.Triggers>

                            <!-- S�lection -->
                            <Trigger Property="IsSelected" Value="True">
                                <Setter TargetName="TabBorder" Property="Background" Value="#3A3A3A"/>
                                <Setter TargetName="Underline" Property="Background" Value="#C586C0"/>
                                <Setter TargetName="Underline" Property="Height" Value="4"/>
                            </Trigger>

                            <!-- Survol -->
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="TabBorder" Property="Background" Value="#404040"/>
                                <Setter TargetName="Underline" Property="Background" Value="#8A2BE2"/>
                            </Trigger>

                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- STYLE DES BOUTONS MIN / MAX -->
        <Style x:Key="TitleButtonStyle" TargetType="Button">
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}">
                            <ContentPresenter HorizontalAlignment="Center"
                                              VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#303030"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- STYLE DU BOUTON CLOSE -->
        <Style x:Key="CloseButtonStyle" TargetType="Button" BasedOn="{StaticResource TitleButtonStyle}">
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}">
                            <ContentPresenter HorizontalAlignment="Center"
                                              VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#C62828"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

    </Window.Resources>

    <!-- CONTENEUR GLOBAL -->
    <Border Name="WindowBorder" BorderThickness="1" BorderBrush="#7B3FFF">

        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="32"/>
                <RowDefinition Height="0"/>   
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- BARRE CUSTOM -->
            <Grid Grid.Row="0"
                  Name="TitleBar"
                  Background="#2B2B2B"
                  Height="32">

                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="40"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="120"/>
                </Grid.ColumnDefinitions>

                <Image Grid.Column="0"
                       Source="ICO/logo.png"
                       Width="20" Height="20"
                       Margin="10,6,0,6"/>

                <TextBlock Grid.Column="1"
                           Text="Ecrion Editor"
                           Foreground="White"
                           VerticalAlignment="Center"
                           FontSize="14"
                           Margin="6,0,0,0"/>

                <!-- BOUTONS DE FEN�TRE -->
                <StackPanel Grid.Column="2"
                            Orientation="Horizontal"
                            HorizontalAlignment="Right">

                    <!-- MINIMISER -->
                    <Button Name="BtnMin"
                            Style="{StaticResource TitleButtonStyle}"
                            Width="40"
                            Background="Transparent">
                        <TextBlock Text="-"
                                   FontSize="20"
                                   Foreground="White"
                                   VerticalAlignment="Center"
                                   HorizontalAlignment="Center"/>
                    </Button>

                    <!-- MAXIMISER / RESTAURER -->
                    <Button Name="BtnMax"
                            Style="{StaticResource TitleButtonStyle}"
                            Width="40"
                            Background="Transparent">
                        <Grid Margin="0,2,0,0">

                            <!-- Ic�ne Max (petit carr� fin) -->
                            <Border x:Name="MaxIcon"
                                    Width="8" Height="8"
                                    BorderBrush="White"
                                    BorderThickness="1.5"/>

                            <!-- Ic�ne Restore (deux petits carr�s) -->
                            <Grid x:Name="RestoreIcon" Visibility="Collapsed">
                                <Border Width="8" Height="8"
                                        BorderBrush="White" BorderThickness="1.5"
                                        Margin="3,0,0,3"/>
                                <Border Width="8" Height="8"
                                        BorderBrush="White" BorderThickness="1.5"/>
                            </Grid>

                        </Grid>
                    </Button>

                    <!-- FERMER -->
                    <Button Name="BtnClose"
                            Style="{StaticResource CloseButtonStyle}"
                            Width="40"
                            Background="Transparent">
                        <TextBlock Text="x"
                                   FontSize="16"
                                   Foreground="White"
                                   VerticalAlignment="Center"
                                   HorizontalAlignment="Right"/>
                    </Button>

                </StackPanel>
            </Grid>

            <Grid Grid.Row="0"
                  Name="MenuHost"
                  Background="#2B2B2B"
                  Height="24"/>

            <!-- CONTENU PRINCIPAL -->
            <Grid Grid.Row="2" Name="MainGrid">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="0"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="260"/>
                </Grid.ColumnDefinitions>

                <!-- PANNEAU PROPRI�T�S -->
                <Border Grid.Column="0"
                        Name="PropertiesPanel"
                        Background="#1A1D24"
                        BorderBrush="#333"
                        BorderThickness="0,0,1,0"
                        Padding="10"
                        Visibility="Collapsed"/>

                <!-- �DITEUR -->
                <DockPanel Grid.Column="1" Name="Root" LastChildFill="True">

                    <ToolBar DockPanel.Dock="Top"
                             Name="Toolbar"
                             Background="#2C2C2C"
                             Height="39"
                             BorderThickness="0"
                             Padding="4"/>

                    <ListBox Name="SearchResults"
                             DockPanel.Dock="Top"
                             Visibility="Collapsed"
                             Background="#1E1E1E"
                             Foreground="White"
                             BorderBrush="#444"
                             BorderThickness="1"
                             MaxHeight="200"
                             Margin="10,2,10,5"/>

                    <StatusBar DockPanel.Dock="Bottom" Background="#222222">
                        <StatusBarItem><TextBlock Name="StatusWords" Foreground="White"/></StatusBarItem>
                        <StatusBarItem><TextBlock Name="StatusPos"   Foreground="White"/></StatusBarItem>
                    </StatusBar>

                    <!-- EXPLORATEUR DE PROJET -->
                    <Border DockPanel.Dock="Bottom"
                            Name="ProjectPane"
                            Background="#1A1025"
                            BorderBrush="#7B3FFF"
                            Visibility="Collapsed"
                            BorderThickness="1"
                            Padding="5"
                            Height="250">

                        <DockPanel>
                            <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,0,0,5">
                                <TextBlock Text="Project Explorer"
                                           Foreground="White"
                                           FontWeight="Bold"
                                           Margin="0,0,10,0"/>

                                <Button Name="BtnBack"    Width="30" Height="24" Margin="0,0,5,0"/>
                                <Button Name="BtnForward" Width="30" Height="24" Margin="0,0,5,0"/>
                                <Button Name="BtnRefresh" Width="30" Height="24" Margin="0,0,5,0"/>
                                <Button Name="BtnAddRef"  Width="30" Height="24" Margin="0,0,5,0"/>

                                <TextBox Name="TxtPath"
                                         Width="300"
                                         Background="#2A2A2A"
                                         Foreground="White"
                                         Padding="4"
                                         Margin="10,0,0,0"
                                         IsReadOnly="True"/>

                                <TextBox Name="TxtProjectSearch"
                                         Width="180"
                                         Background="#2A2A2A"
                                         Foreground="White"
                                         Padding="4"
                                         Margin="20,0,5,0"/>

                                <Button Name="BtnProjectSearch"
                                        Content="Go"
                                        Width="40"
                                        Background="#333"
                                        Foreground="White"
                                        BorderThickness="0"/>
                            </StackPanel>

                            <ListView Name="ProjectList" Margin="0,5,0,0">
                                <ListView.View>
                                    <GridView>
                                        <GridViewColumn Width="30">
                                            <GridViewColumn.CellTemplate>
                                                <DataTemplate>
                                                    <Image Width="16" Height="16" Source="{Binding Icon}"/>
                                                </DataTemplate>
                                            </GridViewColumn.CellTemplate>
                                        </GridViewColumn>

                                        <GridViewColumn Header="Nom"  Width="300" DisplayMemberBinding="{Binding Name}"/>
                                        <GridViewColumn Header="Type" Width="100" DisplayMemberBinding="{Binding Type}"/>
                                        <GridViewColumn Header="Date" Width="150" DisplayMemberBinding="{Binding Date}"/>
                                    </GridView>
                                </ListView.View>
                            </ListView>
                        </DockPanel>
                    </Border>

                    <TabControl Name="Tabs"
                                TabStripPlacement="Top"
                                ItemContainerStyle="{StaticResource TabItemStyle}"
                                HorizontalContentAlignment="Stretch"
                                VerticalContentAlignment="Stretch"/>
                </DockPanel>

                <!-- EXPLORATEUR DE SOLUTIONS -->
                <Border Grid.Column="2"
                        Name="SolutionPanel"
                        Background="#1A1D24"
                        BorderBrush="#333"
                        BorderThickness="1,0,0,0"
                        Padding="10">

                    <StackPanel>
                        <TextBlock Text="Solutions Explorer"
                                   Foreground="White"
                                   FontWeight="Bold"
                                   FontSize="14"
                                   Margin="0,0,0,10"/>

                        <ListBox Name="SolutionList"
                                 Background="#1A1D24"
                                 BorderThickness="0"
                                 Foreground="White">

                            <ListBox.ItemTemplate>
                                <DataTemplate>
                                    <StackPanel>
                                        <StackPanel Orientation="Horizontal"
                                                    Name="HeaderPanel"
                                                    Cursor="Hand"
                                                    Margin="0,4">
                                            <TextBlock Name="Arrow"
                                                       Text=">"
                                                       Margin="0,0,6,0"
                                                       Foreground="#888"/>
                                            <TextBlock Name="TxtName"
                                                       Text="{Binding Name}"
                                                       Foreground="White"
                                                       FontSize="13"/>
                                        </StackPanel>

                                        <Border Name="SubMenu"
                                                Margin="20,4,0,6"
                                                Visibility="Collapsed"
                                                Background="#11151C"
                                                Padding="6">
                                            <StackPanel>
                                                <Button Name="BtnProps"
                                                        Content="Propri�t�s"
                                                        Background="#2A2F38"
                                                        Foreground="White"
                                                        BorderThickness="0"
                                                        Margin="0,0,0,6"
                                                        Height="28"
                                                        Cursor="Hand"/>
                                                <Button Name="BtnRefs"
                                                        Content="R�f�rences"
                                                        Background="#2A2F38"
                                                        Foreground="White"
                                                        BorderThickness="0"
                                                        Height="28"
                                                        Cursor="Hand"/>
                                            </StackPanel>
                                        </Border>
                                    </StackPanel>
                                </DataTemplate>
                            </ListBox.ItemTemplate>
                        </ListBox>
                    </StackPanel>
                </Border>
            </Grid>
        </Grid>
    </Border>
</Window>
'@

# --- Fen�tre RUN avec choix CMD / PS / EXE et nom+extension ---

$xamlRun = @"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        Title='Run Options'
        Width='400' Height='320'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'>

    <StackPanel Margin='10'>
        <TextBlock Text='Nom du fichier (avec extension) :' Foreground='White'/>
        <TextBox Name='TxtFileName' Margin='0,5,0,10'/>

        <StackPanel Orientation='Horizontal' Margin='0,10,0,0'>
            <Button Name='BtnRunCmd' Content='CMD' Width='80' Margin='0,0,10,0'/>
            <Button Name='BtnRunPS'  Content='PowerShell' Width='80' Margin='0,0,10,0'/>
            <Button Name='BtnRunExe' Content='EXE...' Width='80'/>
        </StackPanel>
    </StackPanel>

</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

$window.Add_Deactivated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#BA547A", "#212020")
})

$window.Add_Activated({
    [WindowStyler.WindowBorderHelper]::ApplyBorder($window, "#F01D6E", "#333333")
})


$TitleBar     = $window.FindName("TitleBar")
$BtnClose     = $window.FindName("BtnClose")
$BtnMin       = $window.FindName("BtnMin")
$BtnMax       = $window.FindName("BtnMax")

$WindowBorder = $window.FindName("WindowBorder")

$MainGrid     = $window.FindName("MainGrid")
$SolutionList = $window.FindName("SolutionList")
$TxtPath      = $window.FindName("TxtPath")
#$BtnSolution = $window.FindName("BtnSolution")

Write-Host "MainGrid =" $MainGrid
Write-Host "Columns  =" $($MainGrid.ColumnDefinitions.Count)
Write-Host "SolutionList =" $SolutionList
#Write-Host "BtnSolution =" $BtnSolution

# R�cup�ration des contr�les
$Tabs        = $window.FindName("Tabs")
$Toolbar     = $window.FindName("Toolbar")
$SearchResults = $window.FindName("SearchResults")
$StatusWords = $window.FindName("StatusWords")
$StatusPos   = $window.FindName("StatusPos")
$ProjectPane = $window.FindName("ProjectPane")
$ProjectList = $window.FindName("ProjectList")
$BtnRefresh  = $window.FindName("BtnRefresh")
$BtnBack     = $window.FindName("BtnBack")
$BtnForward  = $window.FindName("BtnForward")
$BtnAddRef   = $window.FindName("BtnAddRef")
$LblProject  = $window.FindName("LblProject")
$MenuHost = $window.FindName("MenuHost")
$BtnThemes   = $window.FindName("BtnThemes")
$ThemesPanel = $window.FindName("ThemesPanel")

$TabItemStyle = $window.Resources["TabItemStyle"]

# --- Logo affich� quand aucun onglet n'est ouvert ---
$NoTabsLogo = New-Object System.Windows.Controls.Image
$NoTabsLogo.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]"$Root\ICO\splashfile.png")
$NoTabsLogo.HorizontalAlignment = "Center"
$NoTabsLogo.VerticalAlignment   = "Center"
$NoTabsLogo.Width  = 180
$NoTabsLogo.Height = 180
$NoTabsLogo.Visibility = "Collapsed"

[System.Windows.Controls.Grid]::SetColumn($NoTabsLogo, 1)

$MainGrid.Children.Add($NoTabsLogo)

if ($themeValue -eq "1") {

    Write-Host "Custom bar mode"

    # Barre Windows d�sactiv�e
    $window.WindowStyle = "None"

    # Barre custom visible
    $TitleBar.Visibility = "Visible"

    $MenuHost.Visibility = "Collapsed"

    # DragMove actif
    $TitleBar.IsHitTestVisible = $true

} else {

    Write-Host "Windows bar mode"

    # Barre Windows activ�e
    $window.WindowStyle = "SingleBorderWindow"

    # Barre custom cach�e
    $TitleBar.Visibility = "Collapsed"

    $MenuHost.Visibility = "Visible"

    # DragMove d�sactiv�
    $TitleBar.IsHitTestVisible = $false

    # ----------------------------------
    # Menu host !
    # ----------------------------------

    # Cr�er la barre MenuStrip
    $menu = New-Object System.Windows.Forms.MenuStrip
    $menu.BackColor = [System.Drawing.Color]::FromArgb(43,43,43)
    $menu.ForeColor = [System.Drawing.Color]::White

    # Ajouter les menus
    $menu.Items.Add($DIALOG["FILE"])

    # Charger les th�mes depuis .\Themes\

    $themesMenu = New-Object System.Windows.Forms.ToolStripMenuItem
    $themesMenu.Text = "Themes"
    $menu.Items.Add($themesMenu)

    # Charger les th�mes
    $themeDir = Join-Path $Root "Themes"
    $icoDir   = Join-Path $Root "ICO"

    if (Test-Path $themeDir) {

        $files = Get-ChildItem $themeDir -File | Where-Object {
            $_.Extension -in ".bat", ".ps1", ".exe"
        }

        foreach ($file in $files) {

            $name = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
            $iconPath = Join-Path $icoDir "$name.png"

            $subItem = New-Object System.Windows.Forms.ToolStripMenuItem
            $subItem.Text = $file.Name

            # Ic�ne
            if (Test-Path $iconPath) {
                $subItem.Image = [System.Drawing.Image]::FromFile($iconPath)
            } else {
                $defaultIcon = Join-Path $icoDir "default.png"
                if (Test-Path $defaultIcon) {
                    $subItem.Image = [System.Drawing.Image]::FromFile($defaultIcon)
                }
            }

            # Stocker le chemin dans Tag
            $subItem.Tag = $file.FullName

            # Action : ex�cuter le bon fichier
            $subItem.Add_Click({
                param($sender, $event)

                $path = $sender.Tag
                if (Test-Path $path) {
                    Start-Process -FilePath $path -Wait
                    ApplySettings
                }
            })

            $themesMenu.DropDownItems.Add($subItem)
        }
    }

    $MenuHostControl = New-Object System.Windows.Forms.Integration.WindowsFormsHost
    $MenuHostControl.Child = $menu

    $MenuHost.Children.Clear()
    $MenuHost.Children.Add($MenuHostControl)
}

# D�placement de la fen�tre
$TitleBar.Add_MouseDown({
    if ($_.ChangedButton -eq "Left") {

        if ($window.WindowState -eq "Maximized") {

            # On calcule la position de la souris
            $mouse = [System.Windows.Forms.Cursor]::Position

            # On restaure la fen�tre
            $window.WindowState = "Normal"

            # On place la fen�tre sous la souris
            $window.Left = $mouse.X - ($window.Width / 2)
            $window.Top  = $mouse.Y - 10
        }

        $window.DragMove()
    }
})

# ---------------------------------------------

$fileMenu = $menu.Items[0]

$saveAllItem = New-Object System.Windows.Forms.ToolStripMenuItem
$saveAllItem.Text = $DIALOG["FILE_SAVEALL"]
$saveAllItem.Image = [System.Drawing.Image]::FromFile("$IconsDir\saveall.png")

$saveAllItem.Add_Click({

    foreach ($tab in $Tabs.Items) {

        $info = $tab.Tag
        if ($info -eq $null) { continue }

        $editor = $info.Editor
        $path   = $info.Path

        # Si pas de chemin ? ignorer
        if (-not $path) { continue }

        # Sauvegarder
        $editor.Text | Out-File $path -Encoding UTF8
    }
})

$fileMenu.DropDownItems.Add($saveAllItem)

# Sous-menu "Ouvrir r�cent"
$recentItem = New-Object System.Windows.Forms.ToolStripMenuItem
$recentItem.Text = $DIALOG["FILE_RECENT"]
$recentItem.Image = [System.Drawing.Image]::FromFile("$IconsDir\full.png")
$fileMenu.DropDownItems.Add($recentItem)

# Charger les fichiers r�cents
$recentFile = ".\save\save.txt"

if (Test-Path $recentFile) {
    Get-Content $recentFile | ForEach-Object {
        $f = $_.Trim()
        if ($f -ne "") {

            # Nom du fichier
            $fileName = [IO.Path]::GetFileName($f)

            # Cr�er l'item du menu
            $subItem = New-Object System.Windows.Forms.ToolStripMenuItem
            $subItem.Text = $fileName

            # Stocker le chemin dans Tag
            $subItem.Tag = $f

            # Action : ouvrir dans l'�diteur via New-Tab
            $subItem.Add_Click({
                param($sender, $event)

                $path = $sender.Tag
                if (Test-Path $path) {
                    New-Tab -FilePath $path
                    Update-Status
                }
            })

            $recentItem.DropDownItems.Add($subItem)
        }
    }
}

$themeDir = Join-Path $Root "Themes"

if (Test-Path $themeDir) {

    # R�cup�rer les fichiers .bat, .ps1, .exe
    $files = Get-ChildItem $themeDir -File | Where-Object {
        $_.Extension -in ".bat", ".ps1", ".exe"
    }

    foreach ($file in $files) {

        # Cr�er l'item du menu
        $subItem = New-Object System.Windows.Forms.ToolStripMenuItem
        $subItem.Text = $file.Name

        # Action : ex�cuter le fichier
        $subItem.Add_Click({
            Start-Process $file.FullName
        })

        # Ajouter au menu THEMES
        $themesMenu.DropDownItems.Add($subItem)
    }
}

# ---------------------------------------------

# Boutons
$BtnClose.Add_Click({ $window.Close() })
$BtnMin.Add_Click({ $window.WindowState = "Minimized" })
$BtnMax.Add_Click({
    if ($window.WindowState -eq "Normal") {
        $window.WindowState = "Maximized"
    } else {
        $window.WindowState = "Normal"
    }
})

# Couleur du contour selon focus
$window.Add_Activated({
    $WindowBorder.BorderBrush = "#7B3FFF"   # violet
})

$window.Add_Deactivated({
    $WindowBorder.BorderBrush = "#606060"   # gris
})

# --- Dossiers globaux ---
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = Split-Path -Parent $Root
$SaveDir = Join-Path $AppRoot "save"

function ApplyThemeToEditor {
    param([ICSharpCode.AvalonEdit.TextEditor]$editor)

    # Charger le th�me
    $ThemeFile = Join-Path $SaveDir "themes.txt"
    $theme = if (Test-Path $ThemeFile) { (Get-Content $ThemeFile).Trim() } else { "1" }

    if ($theme -eq "0") {
        # Th�me clair
        $editor.Background = "White"
        $editor.Foreground = "#1E1E1E"
    }
    else {
        # Th�me sombre
        $editor.Background = "#2A2A2A"
        $editor.Foreground = "White"
    }
}

# --- Construction de la ToolBar : boutons principaux + barre de recherche ---

function New-ToolbarButton {
    param(
        [string]$textKey,
        [string]$iconName,
        [scriptblock]$action
    )

    $btn = New-Object System.Windows.Controls.Button
    $btn.Margin = "5,0,0,0"
    $btn.Background = "#444444"
    $btn.Foreground = "White"
    $btn.Padding = "4"

    $stack = New-Object System.Windows.Controls.StackPanel
    $stack.Orientation = "Horizontal"

    $imgPath = Join-Path $IconsDir $iconName
    if (Test-Path $imgPath) {
        $img = New-Object System.Windows.Controls.Image
        $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$imgPath)
        $img.Width = 16
        $img.Height = 16
        $img.Margin = "0,0,5,0"
        $stack.Children.Add($img) | Out-Null
    }

    $txt = New-Object System.Windows.Controls.TextBlock
    $txt.Text = $DIALOG[$textKey]
    $txt.Foreground = "White"
    $stack.Children.Add($txt) | Out-Null

    $btn.Content = $stack
    if ($action) { $btn.Add_Click($action) }

    return $btn
}

# --- Boutons principaux ---
$btnOpen = New-ToolbarButton "BTN_OPEN" "open.png" {
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        New-Tab -FilePath $dlg.FileName
        Update-Status
    }
}

$btnSave = New-ToolbarButton "BTN_SAVE" "save.png" {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        [IO.File]::WriteAllText($dlg.FileName,$editor.Text)
        $Tabs.SelectedItem.Header = [IO.Path]::GetFileName($dlg.FileName)
    }
}

$btnNew = New-ToolbarButton "BTN_NEW" "new.png" {
    New-Tab
}

$btnRun = New-ToolbarButton "BTN_RUN" "run.png" {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $code = $editor.Text

    # Charger la fen�tre Run
    $readerRun = New-Object System.Xml.XmlNodeReader ([xml]$xamlRun)
    $runWin = [Windows.Markup.XamlReader]::Load($readerRun)

    if (-not $runWin) {
        [System.Windows.MessageBox]::Show("Erreur : impossible de charger la fen�tre Run.")
        return
    }

    # R�cup�ration des contr�les
    $txtFileName = $runWin.FindName("TxtFileName")
    $btnRunCmd   = $runWin.FindName("BtnRunCmd")
    $btnRunPS    = $runWin.FindName("BtnRunPS")
    $btnRunExe   = $runWin.FindName("BtnRunExe")

    if (-not $txtFileName -or -not $btnRunCmd -or -not $btnRunPS -or -not $btnRunExe) {
        [System.Windows.MessageBox]::Show("Erreur : un �l�ment de la fen�tre Run est introuvable.")
        return
    }

    # Nom par d�faut
    $defaultName = $Tabs.SelectedItem.Header
    if (-not $defaultName -or $defaultName -like "Untitled*") {
        $defaultName = "script.ps1"
    }
    $txtFileName.Text = $defaultName

    # Fonction utilitaire
    $getTempPath = {
        param($name)
        if (-not $name) { $name = "script.ps1" }
        return (Join-Path ([IO.Path]::GetTempPath()) $name)
    }

    # Bouton CMD
    $btnRunCmd.Add_Click({
        $fileName = $txtFileName.Text
        $path = & $getTempPath $fileName
        [IO.File]::WriteAllText($path,$code)
        Start-Process "cmd.exe" "/k `"$path`""
    })

    # Bouton PowerShell
    $btnRunPS.Add_Click({
        $fileName = $txtFileName.Text
        $path = & $getTempPath $fileName
        [IO.File]::WriteAllText($path,$code)
        Start-Process "powershell" "-ExecutionPolicy Bypass -File `"$path`""
    })

    # Bouton EXE manuel
    $btnRunExe.Add_Click({
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Exefile|*.exe"
        if ($dlg.ShowDialog() -eq "OK") {
            $fileName = $txtFileName.Text
            $path = & $getTempPath $fileName
            [IO.File]::WriteAllText($path,$code)
            Start-Process $dlg.FileName $path
        }
    })

    # -----------------------------
    #   ZONE EXILBATCH (CORRIG�E)
    # -----------------------------

    # Trouver le conteneur principal
    $root = $runWin.FindName("Root")
    if (-not $root) { $root = $runWin.Content }

    # S�parateur
    $sep = New-Object System.Windows.Controls.Border
    $sep.Height = 1
    $sep.Margin = "0,10,0,10"
    $sep.Background = "#444444"
    $root.Children.Add($sep)

    # ScrollViewer
    $scroll = New-Object System.Windows.Controls.ScrollViewer
    $scroll.VerticalScrollBarVisibility = "Auto"
    $scroll.Height = 150
    $scroll.Background = "#1E1E1E"
    $scroll.Margin = "0,0,0,10"

    # ?? IMPORTANT : un vrai Grid, pas un UniformGrid
    $ExilBatchGrid = New-Object System.Windows.Controls.Grid
    $scroll.Content = $ExilBatchGrid

    $root.Children.Add($scroll)

    # Dossier runtimes
    $RuntimeDir = Join-Path $PSScriptRoot ".\$~Envruntimes"
    $RuntimeDir = (Resolve-Path $RuntimeDir).Path

    # Charger les runtimes
    Load-ExilBatchRuntimes -Grid $ExilBatchGrid -RuntimeDir $RuntimeDir -Code $code -TxtFileName $txtFileName -DIALOG $DIALOG

    # Afficher la fen�tre
    $runWin.ShowDialog() | Out-Null
}

$btnDebug = New-ToolbarButton "BTN_DEBUG" "debug.png" {
    $bat = Join-Path $Root "debug.bat"
    if (Test-Path $bat) {
        Start-Process $bat
    }
}

$btnProject = New-ToolbarButton "BTN_PROJECT" "project.png" {
    if ($ProjectPane.Visibility -eq "Collapsed") {
        $ProjectPane.Visibility = "Visible"
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$true
    } else {
        $ProjectPane.Visibility = "Collapsed"
    }
}

# --- Bouton Settings ---
$btnSettings = New-Object System.Windows.Controls.Button
$btnSettings.Width = 32
$btnSettings.Height = 32
$btnSettings.Margin = "5,0,5,0"
$btnSettings.Background = "Transparent"
$btnSettings.BorderThickness = 0
$btnSettings.Cursor = "Hand"
$btnSettings.ToolTip = "Param�tres"

# Ic�ne settings
$settingsIcon = Join-Path $IconsDir "settings.png"
if (Test-Path $settingsIcon) {
    $img = New-Object System.Windows.Controls.Image
    $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
    $bmp.BeginInit()
    $bmp.UriSource = New-Object System.Uri($settingsIcon, [System.UriKind]::Absolute)
    $bmp.CacheOption = "OnLoad"
    $bmp.EndInit()
    $img.Source = $bmp
    $img.Width = 20
    $img.Height = 20
    $btnSettings.Content = $img
} else {
    $btnSettings.Content = "SET"
}

# Action : ouvrir la fen�tre settings
$btnSettings.Add_Click({
    $settingsScript = Join-Path $Root "windows\settings.ps1"
    if (Test-Path $settingsScript) {
        powershell -ExecutionPolicy Bypass -File $settingsScript
        ApplySettings   # ? S4 : appliquera les changements
    } else {
        [System.Windows.MessageBox]::Show("settings.ps1 introuvable.")
    }
})

# Ajouter � la toolbar
$Toolbar.Items.Add($btnSettings) | Out-Null

# --- Ajout des boutons dans la ToolBar ---
$Toolbar.Items.Add($btnOpen) | Out-Null
$Toolbar.Items.Add($btnSave) | Out-Null
$Toolbar.Items.Add($btnNew)  | Out-Null

$sep = New-Object System.Windows.Controls.Separator
$sep.Margin = "10,0,10,0"
$Toolbar.Items.Add($sep) | Out-Null

$Toolbar.Items.Add($btnRun)     | Out-Null
$Toolbar.Items.Add($btnDebug)   | Out-Null
$Toolbar.Items.Add($btnProject) | Out-Null

# --- Nouvelle barre de recherche dans la ToolBar ---
$SearchBox = New-Object System.Windows.Controls.TextBox
$SearchBox.Width = 200
$SearchBox.Height = 26
$SearchBox.Margin = "10,0,5,0"
$SearchBox.Background = "#1F1F1F"
$SearchBox.Foreground = "White"
$SearchBox.BorderBrush = "#555"

$BtnSearch = New-Object System.Windows.Controls.Button
$BtnSearch.Width = 26
$BtnSearch.Height = 26
$BtnSearch.Background = "Transparent"
$BtnSearch.BorderThickness = 0
$BtnSearch.Cursor = "Hand"

$searchIconPath = Join-Path $IconsDir "send.png"
if (Test-Path $searchIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$searchIconPath)
    $img.Width = 16
    $img.Height = 16
    $BtnSearch.Content = $img
}

$Toolbar.Items.Add($SearchBox) | Out-Null
$Toolbar.Items.Add($BtnSearch) | Out-Null

# --- Boutons de scroll horizontal ---
$btnLeft = New-Object System.Windows.Controls.Button
$btnLeft.Width = 20
$btnLeft.Height = 20
$btnLeft.Margin = "5,0,0,0"
$btnLeft.Background = "Transparent"
$btnLeft.BorderThickness = 0
$btnLeft.Foreground = "White"

$leftIconPath = Join-Path $IconsDir "left.png"
if (Test-Path $leftIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$leftIconPath)
    $img.Width = 16
    $img.Height = 16
    $btnLeft.Content = $img
} else {
    $btnLeft.Content = "<"
}

$btnRight = New-Object System.Windows.Controls.Button
$btnRight.Width = 20
$btnRight.Height = 20
$btnRight.Margin = "0,0,5,0"
$btnRight.Background = "Transparent"
$btnRight.BorderThickness = 0
$btnRight.Foreground = "White"

$rightIconPath = Join-Path $IconsDir "right.png"
if (Test-Path $rightIconPath) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$rightIconPath)
    $img.Width = 10
    $img.Height = 16
    $btnRight.Content = $img
} else {
    $btnRight.Content = ">"
}

$btnStripPanel = New-Object System.Windows.Controls.StackPanel
$btnStripPanel.Orientation = "Horizontal"

$scrollViewer = New-Object System.Windows.Controls.ScrollViewer
$scrollViewer.HorizontalScrollBarVisibility = "Hidden"
$scrollViewer.VerticalScrollBarVisibility = "Disabled"
$scrollViewer.Content = $btnStripPanel
$scrollViewer.Width = 250
$scrollViewer.Margin = "10,0,10,0"

$Toolbar.Items.Add($btnLeft)      | Out-Null
$Toolbar.Items.Add($scrollViewer) | Out-Null
$Toolbar.Items.Add($btnRight)     | Out-Null

$btnLeft.Add_Click({
    $scrollViewer.ScrollToHorizontalOffset([Math]::Max(0, $scrollViewer.HorizontalOffset - 50))
})
$btnRight.Add_Click({
    $scrollViewer.ScrollToHorizontalOffset($scrollViewer.HorizontalOffset + 50)
})

function Get-ActiveInfo {
    if (-not $Tabs.SelectedItem) { return $null }
    return $Tabs.SelectedItem.Tag
}

function Get-ActiveEditor {
    $info = Get-ActiveInfo
    if (-not $info) { return $null }
    return $info.Editor
}

# --- Mise � jour de la barre d��tat (ligne / colonne / mots) ---
function Update-Status {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $caretIndex = $editor.CaretOffset
    $text = $editor.Text

    if ($caretIndex -gt $text.Length) { $caretIndex = $text.Length }

    $before = $text.Substring(0, $caretIndex)
    $lines = $before -split "`r?`n"

    $line = $lines.Count
    $col  = $lines[-1].Length + 1

    $StatusPos.Text = "Ligne $line, Col $col"

    $words = ($text -split "\s+").Count
    $StatusWords.Text = "Mots : $words"
}

$Libs = Join-Path $PSScriptRoot "libs\net462"

# --- Cr�ation d�un nouvel onglet avec AvalonEdit ---
function New-Tab {
    param(
        [string]$FilePath = $null
    )

    $NoTabsLogo.Visibility = "Collapsed"

    $tabCount = $Tabs.Items.Count + 1

    # Cr�er l�onglet
    $tab = New-Object System.Windows.Controls.TabItem
    if ($FilePath) {
        $tab.Header = [IO.Path]::GetFileName($FilePath)
    } else {
        $tab.Header = "Untitled $tabCount"
    }
    if ($TabItemStyle) { $tab.Style = $TabItemStyle }

    # Conteneur principal
    $grid = New-Object System.Windows.Controls.Grid
    $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height="*" }))

    # --- AVALONEDIT ---
    $editor = New-Object ICSharpCode.AvalonEdit.TextEditor
    $editor.FontFamily = "Consolas"
    $editor.FontSize = 14
    $editor.ShowLineNumbers = $true
    $editor.Background = "#2A2A2A"
    $editor.Foreground = "White"
    $editor.HorizontalAlignment = "Stretch"
    $editor.VerticalAlignment = "Stretch"

    # --- SYNTAXE AUTOMATIQUE ---
    if ($FilePath) {
        $ext = [IO.Path]::GetExtension($FilePath).ToLower()

        switch ($ext) {
            ".ps1" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("PowerShell")
            }
            ".bat" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("Batch")
            }
            ".json" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("JavaScript")
            }
            ".xml" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("XML")
            }
            ".cs" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("C#")
            }
            ".java" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("JAVA")
            }
            ".html" { 
                $editor.SyntaxHighlighting = 
                    [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("HTML")
            }
            ".java" {
                # Chargement syntaxe ECB (si tu as un fichier ecb.xshd)
                try {
                    $reader = [System.Xml.XmlReader]::Create("libs\syntax\java.xshd")
                    $editor.SyntaxHighlighting = 
                        [ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader]::Load(
                            $reader,
                            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance
                        )
                } catch {
                    $editor.SyntaxHighlighting = $null
                }
            }
            ".ecb" {
                # Chargement syntaxe ECB (si tu as un fichier ecb.xshd)
                try {
                    $reader = [System.Xml.XmlReader]::Create("libs\syntax\ecb.xshd")
                    $editor.SyntaxHighlighting = 
                        [ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader]::Load(
                            $reader,
                            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance
                        )
                } catch {
                    $editor.SyntaxHighlighting = $null
                }
            }
            default {
                $editor.SyntaxHighlighting = $null
            }
        }
    } else {
        # Par d�faut si pas de fichier ? PowerShell (comme ton code original)
        $editor.SyntaxHighlighting = 
            [ICSharpCode.AvalonEdit.Highlighting.HighlightingManager]::Instance.GetDefinition("PowerShell")
    }

    # --- DRAG & DROP ---
    $editor.AllowDrop = $true
    $editor.Add_Drop({
        param($sender, $e)

        if ($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)) {
            $files = $e.Data.GetData([Windows.DataFormats]::FileDrop)

            if ($files.Count -gt 0) {
                $file = $files[0]

                if (Test-Path $file) {
                    $sender.Text = Get-Content $file -Raw

                    $tab = $Tabs.SelectedItem
                    if ($tab) {
                        $tab.Header = [IO.Path]::GetFileName($file)
                        $tab.Tag.Path = $file
                    }

                    $SolutionList.Items.Add([pscustomobject]@{
                        Name = [IO.Path]::GetFileName($file)
                        Path = $file
                        Tab  = $tab
                    })
                }
            }
        }
    })

    # Tag = Editor + Path
    $tab.Tag = [pscustomobject]@{
        Editor = $editor
        Path   = $FilePath
    }

    # Si on a un fichier, charger le contenu et l�ajouter dans SolutionList
    if ($FilePath -and (Test-Path $FilePath)) {
        $editor.Text = Get-Content $FilePath -Raw

        $SolutionList.Items.Add([pscustomobject]@{
            Name = [IO.Path]::GetFileName($FilePath)
            Path = $FilePath
            Tab  = $tab
        })
    }

    # Mise � jour de la barre d��tat
    $editor.Add_TextChanged({ Update-Status })
    $editor.Add_KeyDown({ Update-Status })
    $editor.Add_MouseDown({ Update-Status })

    [System.Windows.Controls.Grid]::SetRow($editor, 0)
    $grid.Children.Add($editor)

    ApplyThemeToEditor -editor $editor

    $tab.Content = $grid
    $Tabs.Items.Add($tab)
    $Tabs.SelectedItem = $tab

    # Bouton fermer
    $tab.ApplyTemplate()
    $closeBtn = $tab.Template.FindName("CloseBtn", $tab)

    $closeBtn.Add_Click({
        $parentTab = $this.TemplatedParent
        if ($parentTab) {
            $tabToRemove = $parentTab

            $toDelete = $null
            foreach ($item in $SolutionList.Items) {
                if ($item.Tab -eq $tabToRemove) {
                    $toDelete = $item
                    break
                }
            }
            if ($toDelete) {
                $SolutionList.Items.Remove($toDelete)
            }

            $Tabs.Items.Remove($parentTab)

            # --- Afficher le logo si plus aucun onglet ---
            if ($Tabs.Items.Count -eq 0) {
                $NoTabsLogo.Visibility = "Visible"
            }
        }
    })

    Update-Status
}

# --- Double-clic : ouvrir fichier ou dossier ---
$ProjectList.Add_MouseDoubleClick({
    $sel = $ProjectList.SelectedItem
    if (-not $sel) { return }

    if ($sel.IsFolder) {
        Refresh-ProjectExplorer -Path $sel.FullPath -AddHistory:$true
        return
    }

    if (-not (Test-Path $sel.FullPath)) { return }

    if ($sel.FullPath -match "\.(ps1|txt|json|xml|cfg|ini|cs)$") {
        New-Tab -FilePath $sel.FullPath
        return
    }

    Start-Process $sel.FullPath
})

# --- Ouverture via arguments ---
if ($args.Count -gt 0) {
    foreach ($file in $args) {
        if (Test-Path $file) {
            New-Tab -FilePath $file
        }
    }
}

function Search-GenerateResults {
    param($editor, $query)

    $SearchResults.Items.Clear()

    if ([string]::IsNullOrWhiteSpace($query)) {
        $SearchResults.Visibility = "Collapsed"
        return
    }

    $text = $editor.Text
    $lines = $text -split "`n"

    foreach ($i in 0..($lines.Count - 1)) {
        if ($lines[$i] -match [regex]::Escape($query)) {
            $SearchResults.Items.Add("Line $($i+1) : $($lines[$i].Trim())")
        }
    }

    if ($SearchResults.Items.Count -gt 0) {
        $SearchResults.Visibility = "Visible"
    } else {
        $SearchResults.Visibility = "Collapsed"
    }
}

# Double-clic sur un r�sultat ? aller � la ligne
$SearchResults.Add_MouseDoubleClick({
    $tab = $Tabs.SelectedItem
    if (-not $tab) { return }

    $editor = $tab.Tag.Editor
    if (-not $editor) { return }

    $selected = $SearchResults.SelectedItem
    if (-not $selected) { return }

    # Extraire le num�ro de ligne
    $m = [regex]::Match($selected, "Line (\d+)")
    if ($m.Success) {
        $line = [int]$m.Groups[1].Value

        $editor.ScrollToLine($line)
        $offset = $editor.Document.GetOffset($line, 0)
        $editor.Select($offset, 0)
        $editor.Focus()
    }
})

# Recherche en temps r�el
$SearchBox.Add_TextChanged({
    $tab = $Tabs.SelectedItem
    if ($tab -and $tab.Tag.Editor) {
        Search-GenerateResults $tab.Tag.Editor $SearchBox.Text
    }
})

# Bouton de recherche
$BtnSearch.Add_Click({
    $tab = $Tabs.SelectedItem
    if ($tab -and $tab.Tag.Editor) {
        Search-GenerateResults $tab.Tag.Editor $SearchBox.Text
    }
})

# --- Explorateur de projet ---

# --- Historique de navigation ---
function Push-History {
    param([string]$path)

    if ($script:NavIndex -lt $script:NavHistory.Count - 1) {
        $script:NavHistory.RemoveRange($script:NavIndex+1, $script:NavHistory.Count - ($script:NavIndex+1))
    }

    $script:NavHistory.Add($path)
    $script:NavIndex = $script:NavHistory.Count - 1
}

# --- Rafra�chir l�explorateur ---
function Refresh-ProjectExplorer {
    param(
        [string]$Path,
        [bool]$AddHistory = $false
    )

    if (-not $Path) { $Path = $ProjectRoot }
    if (-not (Test-Path $Path)) { return }

    $script:CurrentProjectDir = $Path
    if ($AddHistory) { Push-History $Path }

    $ProjectList.Items.Clear()

    $items = Get-ChildItem $Path | Sort-Object PSIsContainer, Name

    foreach ($it in $items) {

    $iconPath = if ($it.PSIsContainer) {
        Join-Path $IconsDir "folder.png"
    } else {
        Join-Path $IconsDir "file.png"
    }

    $iconImage = $null
    if (Test-Path $iconPath) {
        $iconImage = New-Object System.Windows.Media.Imaging.BitmapImage
        $iconImage.BeginInit()
        $iconImage.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
        $iconImage.CacheOption = "OnLoad"
        $iconImage.EndInit()
        $iconImage.Freeze()
    }

    $ProjectList.Items.Add([pscustomobject]@{
        Name     = $it.Name
        Type     = if ($it.PSIsContainer) { "Dossier" } else { "Fichier" }
        Date     = $it.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
        Icon     = $iconImage
        FullPath = $it.FullName
        IsFolder = $it.PSIsContainer
    }) | Out-Null
    }
}

function Set-ButtonIcon {
    param($button, $fileName)

    if ($null -eq $button) {
        Write-Host "Button is NULL"
        return
    }

    $iconPath = Join-Path $IconsDir $fileName

    if (-not (Test-Path $iconPath)) {
        Write-Host "Icon not found: $iconPath"
        return
    }

    $img = New-Object System.Windows.Controls.Image
    $bmp = New-Object System.Windows.Media.Imaging.BitmapImage

    $bmp.BeginInit()
    $bmp.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
    $bmp.CacheOption = "OnLoad"
    $bmp.EndInit()

    $img.Source = $bmp
    $img.Width = 16
    $img.Height = 16

    $button.Content = $img
}

Set-ButtonIcon $BtnBack    "back.png"
Set-ButtonIcon $BtnForward "forward.png"
Set-ButtonIcon $BtnRefresh "refresh.png"
Set-ButtonIcon $BtnAddRef  "addref.png"

# --- Clic droit : menu contextuel ---
$ctx = New-Object System.Windows.Controls.ContextMenu

# Ouvrir
$miOpen = New-Object System.Windows.Controls.MenuItem
$miOpen.Header = $DIALOG["BTN_OPEN"]
$miOpen.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel -and -not $sel.IsFolder) {
        New-Tab
        $editor = Get-ActiveEditor
        $editor.Text = (Get-Content $sel.FullPath -Raw)
        $Tabs.SelectedItem.Header = $sel.Name
        Update-Status
    }
})

# Supprimer
$miDelete = New-Object System.Windows.Controls.MenuItem
$miDelete.Header = $DIALOG["MSG_DELETE"]
$miDelete.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel) {
        if ([System.Windows.MessageBox]::Show($DIALOG["MSG_DELETE"], "Confirm", "YesNo","Warning") -eq "Yes") {
            Remove-Item $sel.FullPath -Recurse -Force
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Renommer
$miRename = New-Object System.Windows.Controls.MenuItem
$miRename.Header = $DIALOG["MSG_RENAME"]
$miRename.Add_Click({
    $ProjectList.Focus()
    $sel = $ProjectList.SelectedItem
    if ($sel) {
        $newName = [Microsoft.VisualBasic.Interaction]::InputBox($DIALOG["MSG_RENAME"], "Renommer", $sel.Name)
        if ($newName -and $newName -ne $sel.Name) {
            $dir = Split-Path $sel.FullPath -Parent
            $newPath = Join-Path $dir $newName
            Rename-Item -Path $sel.FullPath -NewName $newName -Force
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Nouveau fichier
$miNewFile = New-Object System.Windows.Controls.MenuItem
$miNewFile.Header = $DIALOG["MSG_NEWFILE"]
$miNewFile.Add_Click({
    $ProjectList.Focus()
    $path = Join-Path $script:CurrentProjectDir "nouveau.ps1"
    if (-not (Test-Path $path)) {
        "" | Out-File $path -Encoding UTF8
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
    }
})

# Nouveau dossier
$miNewFolder = New-Object System.Windows.Controls.MenuItem
$miNewFolder.Header = "Nouveau dossier"
$miNewFolder.Add_Click({
    $ProjectList.Focus()
    $name = [Microsoft.VisualBasic.Interaction]::InputBox("Nom du dossier :", "Nouveau dossier", "NouveauDossier")
    if ($name) {
        $path = Join-Path $script:CurrentProjectDir $name
        if (-not (Test-Path $path)) {
            New-Item -ItemType Directory -Path $path | Out-Null
            Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        }
    }
})

# Ajouter au menu
$ctx.Items.Add($miOpen)      | Out-Null
$ctx.Items.Add($miDelete)    | Out-Null
$ctx.Items.Add($miRename)    | Out-Null
$ctx.Items.Add($miNewFile)   | Out-Null
$ctx.Items.Add($miNewFolder) | Out-Null

# Attacher le menu
$ProjectList.ContextMenu = $ctx

# --- Double-clic : ouvrir fichier ou dossier ---
$ProjectList.Add_MouseDoubleClick({
    $sel = $ProjectList.SelectedItem
    if (-not $sel) { return }
    if ($sel.IsFolder) {
        Refresh-ProjectExplorer -Path $sel.FullPath -AddHistory:$true
        return
    }
    if (-not (Test-Path $sel.FullPath)) {
        return
    }
    if ($sel.FullPath -match "\.(ps1|txt|json|xml|cfg|ini)$") {
        New-Tab
        $editor = Get-ActiveEditor
        $editor.Text = (Get-Content $sel.FullPath -Raw)
        $Tabs.SelectedItem.Header = $sel.Name
        return
    }
    Start-Process $sel.FullPath
})


# --- Boutons navigation ---
$BtnRefresh.Add_Click({
    Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
})

$BtnBack.Add_Click({
    if ($script:NavIndex -gt 0) {
        $script:NavIndex--
        $path = $script:NavHistory[$script:NavIndex]
        Refresh-ProjectExplorer -Path $path -AddHistory:$false
    }
})

$BtnForward.Add_Click({
    if ($script:NavIndex -lt $script:NavHistory.Count - 1) {
        $script:NavIndex++
        $path = $script:NavHistory[$script:NavIndex]
        Refresh-ProjectExplorer -Path $path -AddHistory:$false
    }
})

$BtnAddRef.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    if ($dlg.ShowDialog() -eq "OK") {
        $dest = Join-Path $script:CurrentProjectDir ([IO.Path]::GetFileName($dlg.FileName))
        Copy-Item $dlg.FileName $dest -Force
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
    }
})

# --- Boutons dynamiques depuis le dossier btns ---

function Load-CustomButtons {
    param(
        [string]$BtnsDir,
        [string]$IconsDir
    )

    $buttons = @()

    if (-not (Test-Path $BtnsDir)) {
        return $buttons
    }

    $allowedExt = ".txt",".exe",".cmd",".cs",".bat",".ps1", ".html"

    Get-ChildItem $BtnsDir | Where-Object {
        -not $_.PSIsContainer -and $allowedExt -contains $_.Extension.ToLower()
    } | ForEach-Object {

        $file = $_
        $name = [IO.Path]::GetFileNameWithoutExtension($file.Name)

        $btn = New-Object System.Windows.Controls.Button
        $btn.Margin = "1,0,1,0"
        $btn.Padding = "4,2,4,2"
        $btn.Background = "#444444"
        $btn.Foreground = "White"
        $btn.BorderThickness = 0

        $stack = New-Object System.Windows.Controls.StackPanel
        $stack.Orientation = "Horizontal"

        $iconPath = Join-Path $IconsDir ($name + ".png")
        if (Test-Path $iconPath) {
            $img = New-Object System.Windows.Controls.Image
            $bmp = New-Object System.Windows.Media.Imaging.BitmapImage

            $bmp.BeginInit()
            $bmp.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
            $bmp.CacheOption = "OnLoad"
            $bmp.EndInit()

            $img.Source = $bmp
            $img.Width = 16
            $img.Height = 16
            $img.Margin = "0,0,5,0"

            $stack.Children.Add($img) | Out-Null
        }

        $txt = New-Object System.Windows.Controls.TextBlock
        $txt.Text = $name
        $txt.Foreground = "White"
        $stack.Children.Add($txt) | Out-Null

        $btn.Content = $stack

        # ? LA LIGNE QUI R�GLE TOUT
        $btn.Tag = $file.FullName

        $btn.Add_Click({
            Start-Process $this.Tag
        })

        $buttons += $btn
    }

    return $buttons
}

$buttons = Load-CustomButtons -BtnsDir $BtnsDir -IconsDir $IconsDir

$btnStripPanel.Children.Clear()
foreach ($b in $buttons) {
    $btnStripPanel.Children.Add($b) | Out-Null
}

# --- D�marrage ---
Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$true
New-Tab

function Load-ExilBatchRuntimes {
    param(
        $Grid,
        $RuntimeDir,
        $Code,
        $TxtFileName,
        $DIALOG
    )

    if (-not $Grid) { return }

    # Nettoyer le Grid
    $Grid.Children.Clear()
    $Grid.RowDefinitions.Clear()

    # Une seule ligne qui prend toute la place
    $row = New-Object System.Windows.Controls.RowDefinition
    $row.Height = "*"
    $Grid.RowDefinitions.Add($row)

    if (-not (Test-Path $RuntimeDir)) { return }

    # ScrollViewer interne
    $scroll = New-Object System.Windows.Controls.ScrollViewer
    $scroll.VerticalScrollBarVisibility = "Auto"
    $scroll.Margin = "5"
    $Grid.Children.Add($scroll)
    [System.Windows.Controls.Grid]::SetRow($scroll, 0)

    # Grille dynamique
    $panel = New-Object System.Windows.Controls.Grid
    $panel.Margin = "5"
    $scroll.Content = $panel

    # Charger les fichiers
    $files = Get-ChildItem $RuntimeDir -File | Where-Object {
        $_.Extension -in ".exe", ".bat"
    }

    # 3 colonnes
    $columns = 2
    for ($i = 0; $i -lt $columns; $i++) {
        $col = New-Object System.Windows.Controls.ColumnDefinition
        $col.Width = "Auto"
        $panel.ColumnDefinitions.Add($col)
    }

    # Ajouter les boutons
    $rowIndex = 0
    $colIndex = 0

    foreach ($file in $files) {

        if ($colIndex -eq 0) {
            $rowDef = New-Object System.Windows.Controls.RowDefinition
            $rowDef.Height = "Auto"
            $panel.RowDefinitions.Add($rowDef)
        }

        $btn = New-Object System.Windows.Controls.Button
        $btn.Width = 160
        $btn.Height = 45
        $btn.Margin = "5"
        $btn.Background = "#333"
        $btn.Foreground = "White"
        $btn.BorderThickness = 1
        $btn.Cursor = "Hand"
        $btn.Tag = $file.FullName

        $stack = New-Object System.Windows.Controls.StackPanel
        $stack.Orientation = "Horizontal"
        $stack.VerticalAlignment = "Center"

        $pngPath = Join-Path $RuntimeDir ($file.BaseName + ".png")
        if (Test-Path $pngPath) {
            $img = New-Object System.Windows.Controls.Image
            $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$pngPath)
            $img.Width = 20
            $img.Height = 20
            $img.Margin = "0,0,6,0"
            $stack.Children.Add($img)
        }

        $txt = New-Object System.Windows.Controls.TextBlock
        $txt.Text = $file.BaseName
        $txt.Foreground = "White"
        $txt.VerticalAlignment = "Center"
        $stack.Children.Add($txt)

        $btn.Content = $stack

        $btn.Add_Click({
            $runtime = $this.Tag
            if (-not $runtime) {
                [System.Windows.MessageBox]::Show("Erreur : runtime introuvable.")
                return
            }

            $fileName = $TxtFileName.Text
            $temp = Join-Path ([IO.Path]::GetTempPath()) $fileName
            [IO.File]::WriteAllText($temp,$Code)

            Start-Process $runtime "`"$temp`""
        })

        [System.Windows.Controls.Grid]::SetRow($btn, $rowIndex)
        [System.Windows.Controls.Grid]::SetColumn($btn, $colIndex)
        $panel.Children.Add($btn)

        $colIndex++
        if ($colIndex -ge $columns) {
            $colIndex = 0
            $rowIndex++
        }
    }
}

if ($args.Count -gt 0) {
    foreach ($file in $args) {
        if (Test-Path $file) {
            New-Tab
            $editor = Get-ActiveEditor
            $editor.Text = Get-Content $file -Raw
            $Tabs.SelectedItem.Header = [IO.Path]::GetFileName($file)
        }
    }
}

$TxtPath = $window.FindName("TxtPath")

$TxtPath.Text = $script:CurrentProjectDir

function Search-Or-NavigateProject {
    param([string]$query)

    if ([string]::IsNullOrWhiteSpace($query)) {
        Refresh-ProjectExplorer -Path $script:CurrentProjectDir -AddHistory:$false
        return
    }

    # Si c'est un chemin ? navigation
    if (Test-Path $query) {
        Refresh-ProjectExplorer -Path $query -AddHistory:$true
        return
    }

    # Sinon ? filtrage
    $ProjectList.Items.Clear()

    $items = Get-ChildItem $script:CurrentProjectDir | Sort-Object PSIsContainer, Name

    foreach ($it in $items) {
        if ($it.Name -notmatch [regex]::Escape($query)) { continue }

        $iconPath = if ($it.PSIsContainer) {
            Join-Path $IconsDir "folder.png"
        } else {
            Join-Path $IconsDir "file.png"
        }

        $iconImage = $null
        if (Test-Path $iconPath) {
            $iconImage = New-Object System.Windows.Media.Imaging.BitmapImage
            $iconImage.BeginInit()
            $iconImage.UriSource = New-Object System.Uri($iconPath, [System.UriKind]::Absolute)
            $iconImage.CacheOption = "OnLoad"
            $iconImage.EndInit()
        }

        $ProjectList.Items.Add([pscustomobject]@{
            Name     = $it.Name
            Type     = if ($it.PSIsContainer) { "Dossier" } else { "Fichier" }
            Date     = $it.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
            Icon     = $iconImage
            FullPath = $it.FullName
            IsFolder = $it.PSIsContainer
        })
    }
}

# R�cup�ration des contr�les
$SolutionList = $window.FindName("SolutionList")
#$BtnSolution  = $window.FindName("BtnSolution")
$MainGrid     = $window.FindName("MainGrid")
$TxtProjectSearch = $window.FindName("TxtProjectSearch")
$BtnProjectSearch = $window.FindName("BtnProjectSearch")

$BtnProjectSearch.Add_Click({
    Search-Or-NavigateProject $TxtProjectSearch.Text
})

$TxtProjectSearch.Add_KeyDown({
    if ($_.Key -eq "Enter") {
        Search-Or-NavigateProject $TxtProjectSearch.Text
    }
})

# ---------- PROPRI�T�S FICHIER ----------

function Show-FileProperties {
    param([string]$path)

    if ([string]::IsNullOrWhiteSpace($path)) { return }
    if (-not (Test-Path $path)) { return }

    $fi = Get-Item $path

    $xamlProps = @"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        Title='$($DIALOG["PROP_TITLE"])'
        Width='400' Height='250'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'>
    <StackPanel Margin='10'>
        <TextBlock Text='$($DIALOG["PROP_NAME"]) : $($fi.Name)' Foreground='White'/>
        <TextBlock Text='$($DIALOG["PROP_EXT"]) : $($fi.Extension)' Foreground='White'/>
        <TextBlock Text='$($DIALOG["PROP_SIZE"]) : $([Math]::Round($fi.Length/1024,2)) Ko' Foreground='White'/>
        <TextBlock Text='$($DIALOG["PROP_CREATED"]) : $($fi.CreationTime)' Foreground='White'/>
        <TextBlock Text='$($DIALOG["PROP_MODIFIED"]) : $($fi.LastWriteTime)' Foreground='White'/>
        <Button Content='$($DIALOG["BTN_OK"])' Width='80' Margin='0,20,0,0' HorizontalAlignment='Right'/>
    </StackPanel>
</Window>
"@

    $reader = New-Object System.Xml.XmlNodeReader ([xml]$xamlProps)
    $win = [Windows.Markup.XamlReader]::Load($reader)
    $win.ShowDialog() | Out-Null
}

# ---------- R�F�RENCES (AVALONEDIT) ----------
function Show-FileReferences {
    param([string]$path)

    if ([string]::IsNullOrWhiteSpace($path)) { return }

    $ext = [IO.Path]::GetExtension($path).TrimStart(".").ToLower()
    if (-not $ext) { return }

    $runtimeRoot = Join-Path $PSScriptRoot ".\$~Envruntimes"
    $runtimeDir  = Join-Path $runtimeRoot $ext

    if (-not (Test-Path $runtimeDir)) {
        [System.Windows.MessageBox]::Show("Aucune r�f�rence trouv�e pour .$ext")
        return
    }

    $config = Get-ChildItem $runtimeDir -Filter "*.config" -File | Select-Object -First 1
    $libsDir = Join-Path $runtimeDir "libs"

    $xaml = @"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
        xmlns:avalon='http://icsharpcode.net/sharpdevelop/avalonedit'
        Title='R�f�rences .$ext'
        Width='650' Height='500'
        Background='#1E1E1E'
        WindowStartupLocation='CenterScreen'>

    <DockPanel Margin='10'>

    <StackPanel DockPanel.Dock='Top' Orientation='Horizontal' Margin='0,0,0,10'>
        <Button Name='BtnSave' Width='40' Margin='0,0,10,0'/>
        <Button Name='BtnOpenLibs' Width='40'/>
    </StackPanel>

        <avalon:TextEditor Name='TxtConfig'
                           ShowLineNumbers='True'
                           FontFamily='Consolas'
                           FontSize='14'
                           Background='#2A2A2A'
                           Foreground='White'
                           BorderBrush='#555'
                           VerticalScrollBarVisibility='Auto'/>
    </DockPanel>

</Window>
"@

    $reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
    $win = [Windows.Markup.XamlReader]::Load($reader)

    $TxtConfig   = $win.FindName("TxtConfig")
    $BtnSave     = $win.FindName("BtnSave")
    $BtnOpenLibs = $win.FindName("BtnOpenLibs")

    function Set-ButtonIcon {
        param($button, $file)

        if ($button -and (Test-Path $file)) {

            $img = New-Object System.Windows.Controls.Image
            $img.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri]$file)
            $img.Width  = 20
            $img.Height = 20
            $img.Stretch = "Uniform"

            $button.Content = $img
        }
    }

    Set-ButtonIcon $BtnSave     "$PSScriptRoot\ICO\save.png"
    Set-ButtonIcon $BtnOpenLibs "$PSScriptRoot\ICO\folder.png"

    if ($config) {
        $TxtConfig.Text = Get-Content $config.FullName -Raw
    } else {
        $TxtConfig.Text = "// Aucun fichier .config trouv� pour .$ext"
        $BtnSave.IsEnabled = $false
    }

    $BtnSave.Add_Click({
        if ($config) {
            [IO.File]::WriteAllText($config.FullName, $TxtConfig.Text)
        }
    })

    if (Test-Path $libsDir) {
        $BtnOpenLibs.Add_Click({ Start-Process $libsDir })
    } else {
        $BtnOpenLibs.IsEnabled = $false
    }

    $win.ShowDialog() | Out-Null
}

# ---------- UTILITAIRE : RECHERCHE D�ENFANT ----------
function Find-Child {
    param(
        [System.Windows.DependencyObject]$parent,
        [string]$name
    )

    if ($parent -eq $null) { return $null }

    for ($i = 0; $i -lt [System.Windows.Media.VisualTreeHelper]::GetChildrenCount($parent); $i++) {
        $child = [System.Windows.Media.VisualTreeHelper]::GetChild($parent, $i)

        if ($child -is [System.Windows.FrameworkElement] -and $child.Name -eq $name) {
            return $child
        }

        $result = Find-Child -parent $child -name $name
        if ($result) { return $result }
    }

    return $null
}

# ---------- TOGGLE > / v ----------
$SolutionList.Add_PreviewMouseLeftButtonDown({
    param($sender, $e)

    $item = [System.Windows.Controls.ItemsControl]::ContainerFromElement($SolutionList, $e.OriginalSource)
    if (-not $item) { return }

    $arrow   = Find-Child -parent $item -name "Arrow"
    $label   = Find-Child -parent $item -name "TxtName"
    $submenu = Find-Child -parent $item -name "SubMenu"

    if (-not $arrow -or -not $label -or -not $submenu) { return }

    if ($e.OriginalSource -eq $arrow -or $e.OriginalSource -eq $label) {
        if ($submenu.Visibility -eq "Collapsed") {
            $submenu.Visibility = "Visible"
            $arrow.Text = "v"
        } else {
            $submenu.Visibility = "Collapsed"
            $arrow.Text = ">"
        }
    }
})

# ---------- CLIC SUR PROPRI�T�S / R�F�RENCES ----------
$SolutionList.AddHandler(
    [System.Windows.Controls.Button]::ClickEvent,
    [System.Windows.RoutedEventHandler]{
        param($sender, $e)

        $btn = $e.OriginalSource
        if (-not ($btn -is [System.Windows.Controls.Button])) { return }

        $item = [System.Windows.Controls.ItemsControl]::ContainerFromElement($SolutionList, $btn)
        if (-not $item) { return }

        $data = $item.DataContext
        if (-not $data) { return }
        if (-not ($data.PSObject.Properties.Name -contains 'Path')) { return }

        switch ($btn.Name) {
            'BtnProps' { Show-FileProperties $data.Path }
            'BtnRefs'  { Show-FileReferences  $data.Path }
        }

        $e.Handled = $true
    },
    $true
)

# --- Dossiers de sauvegarde ---
$SaveDir  = Join-Path $Root "save"
if (-not (Test-Path $SaveDir)) { New-Item -ItemType Directory -Path $SaveDir | Out-Null }

$SizeFile = Join-Path $SaveDir "statsolutionsize.txt"
$ShowFile = Join-Path $SaveDir "solutionshow.txt"

$defaultWidth = 260

# --- Lecture de la largeur sauvegard�e ---
if (Test-Path $SizeFile) {
    $w = (Get-Content $SizeFile | Select-Object -First 1).Trim()
    if ($w -match "^\d+$") {
        $MainGrid.ColumnDefinitions[2].Width = [double]$w
    } else {
        $MainGrid.ColumnDefinitions[2].Width = $defaultWidth
    }
} else {
    $MainGrid.ColumnDefinitions[2].Width = $defaultWidth
}

# --- Lecture de l'�tat (0 = cach�, 1 = visible) ---
if (Test-Path $ShowFile) {
    $show = (Get-Content $ShowFile | Select-Object -First 1).Trim()
    if ($show -eq "0") {
        $MainGrid.ColumnDefinitions[2].Width = 0
    }
} else {
    "0" | Out-File $ShowFile -Encoding UTF8
    $MainGrid.ColumnDefinitions[2].Width = 0
}

# --- Sauvegarde automatique de la largeur ---
$window.Add_SizeChanged({
    $width = $MainGrid.ColumnDefinitions[2].ActualWidth

    if ($width -gt 0) {
        $width.ToString() | Out-File $SizeFile -Encoding UTF8
        "1" | Out-File $ShowFile -Encoding UTF8
    } else {
        "0" | Out-File $ShowFile -Encoding UTF8
    }
})

# --- Fichier th�me ---
$ThemeFile = Join-Path $SaveDir "themes.txt"

# Valeur par d�faut si absent
if (-not (Test-Path $ThemeFile)) {
    "0" | Out-File $ThemeFile -Encoding UTF8   # 0 = sombre
}

# Lecture du th�me au d�marrage
$script:Theme = (Get-Content $ThemeFile | Select-Object -First 1).Trim()
if ($script:Theme -notmatch "^[01]$") { $script:Theme = "0" }

function ApplySettings {

    # Recharger les contr�les de la fen�tre principale
    $SolutionPanel   = $window.FindName("SolutionPanel")
    $PropertiesPanel = $window.FindName("PropertiesPanel")
    $ProjectPane     = $window.FindName("ProjectPane")
    $Toolbar         = $window.FindName("Toolbar")
    $Tabs            = $window.FindName("Tabs")
    $MainGrid        = $window.FindName("MainGrid")

    # --- Fichiers ---
    $ThemeFile        = Join-Path $SaveDir "themes.txt"
    $ThemeBarFile     = Join-Path $SaveDir "themesbar.txt"
    $SolutionSizeFile = Join-Path $SaveDir "solutionsize.txt"
    $SolutionShowFile = Join-Path $SaveDir "solutionshow.txt"

    # --- Lecture des param�tres ---
    $theme = if (Test-Path $ThemeFile) { (Get-Content $ThemeFile).Trim() } else { "1" }
    $barColor = if (Test-Path $ThemeBarFile) { (Get-Content $ThemeBarFile).Trim() } else { "#2A2A2A" }
    $explorerSize = if (Test-Path $SolutionSizeFile) { (Get-Content $SolutionSizeFile).Trim() } else { "260" }
    $explorerShow = if (Test-Path $SolutionShowFile) { (Get-Content $SolutionShowFile).Trim() } else { "1" }

    # ============================
    #   APPLIQUER LE TH�ME
    # ============================

    if ($theme -eq "0") {
        $window.Background = "#F3F3F3"
        $Toolbar.Background = "#E5E5E5"

        $ProjectPane.Background = "#ECECEC"
        $SolutionPanel.Background = "#F5F5F5"
        $PropertiesPanel.Background = "#ECECEC"

        foreach ($tab in $Tabs.Items) {
            if ($tab.Tag -and $tab.Tag.Editor) {
                $editor = $tab.Tag.Editor
                $editor.Background = "White"
                $editor.Foreground = "#1E1E1E"
            }
        }
    }
    else {
        $window.Background = "#1E1E1E"
        $Toolbar.Background = "#2A2A2A"

        $ProjectPane.Background = "#321152"
        $SolutionPanel.Background = "#24242E"
        $PropertiesPanel.Background = "#252525"

        foreach ($tab in $Tabs.Items) {
            if ($tab.Tag -and $tab.Tag.Editor) {
                $editor = $tab.Tag.Editor
                $editor.Background = "#2A2A2A"
                $editor.Foreground = "White"
            }
        }
    }

    # ============================
    #   COULEUR BARRE CUSTOM
    # ============================

    if ($barColor -match "^#([0-9A-Fa-f]{6})$") {
        try {
            $Toolbar.Background = $barColor
        } catch {}
    }

    # ============================
    #   TAILLE EXPLORATEUR
    # ============================

    if ($explorerShow -eq "1") {
        $MainGrid.ColumnDefinitions[2].Width = [double]$explorerSize
    } else {
        $MainGrid.ColumnDefinitions[2].Width = 0
    }

    #Update-SolutionButtonIcon
}

function Update-ToolbarIcons {
    param([string]$Theme)

    # Dossier selon le th�me
    $iconFolder = if ($Theme -eq "Light") {
        ".\ICO\white"
    } else {
        ".\ICO\"
    }

    # Liste des boutons de ta barre d�outils
    $buttons = @(
        $BtnOpen,
        $BtnSave,
        $BtnNew,
        $BtnRun,
        $BtnDebug,
        $BtnProject
    )

    foreach ($btn in $buttons) {
        if ($btn -and $btn.Tag) {

            # Tag contient le nom du fichier ic�ne
            $iconName = $btn.Tag

            $path = Join-Path $iconFolder $iconName

            if (Test-Path $path) {
                $img = New-Object System.Windows.Media.Imaging.BitmapImage
                $img.BeginInit()
                $img.UriSource = $path
                $img.EndInit()

                $btn.Content = New-Object System.Windows.Controls.Image -Property @{
                    Source = $img
                    Width  = 18
                    Height = 18
                }
            }
        }
    }
}

if ($ThemeSelector.SelectedItem -eq "Light") {
    Update-ToolbarIcons -Theme "Light"
} else {
    Update-ToolbarIcons -Theme "Dark"
}

ApplySettings

Update-ToolbarIcons -Theme $CurrentTheme

$window.ShowDialog() | Out-Null