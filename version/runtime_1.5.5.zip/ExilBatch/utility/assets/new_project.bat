@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
set "name=project"
set "hide=hidden"
if exist %hide%.txt goto execut
echo >> %hide%.txt
cmd /c start /min new_project.bat
exit
:execut
del %hide%.txt
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul