@echo off
start Projects\
exit > nul