@echo off
cd ..
cd packager
echo enter packages directory!
set /p arg=">>"
start packages.bat %arg%
exit