Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# =========================
#   Langue (par d�faut FR, mais tu peux la changer via argument plus tard)
# =========================

$Lang = (Get-Culture).TwoLetterISOLanguageName.ToUpper()

$Translations = @{
    "FR" = @{
        "TITLE"      = "Nouveau projet"
        "SEARCH_PH"  = "Rechercher un template..."
        "BTN_CREATE" = "Cr�er"
        "MSG_SELECT" = "S�lectionne un template."
        "MSG_BAT_MISSING" = "gen_project.bat est introuvable."
    }
    "EN" = @{
        "TITLE"      = "New project"
        "SEARCH_PH"  = "Search template..."
        "BTN_CREATE" = "Create"
        "MSG_SELECT" = "Select a template."
        "MSG_BAT_MISSING" = "gen_project.bat not found."
    }
    "ES" = @{
        "TITLE"      = "Nuevo proyecto"
        "SEARCH_PH"  = "Buscar plantilla..."
        "BTN_CREATE" = "Crear"
        "MSG_SELECT" = "Selecciona una plantilla."
        "MSG_BAT_MISSING" = "gen_project.bat no se encuentra."
    }
    "DE" = @{
        "TITLE"      = "Neues Projekt"
        "SEARCH_PH"  = "Vorlage suchen..."
        "BTN_CREATE" = "Erstellen"
        "MSG_SELECT" = "W�hle eine Vorlage aus."
        "MSG_BAT_MISSING" = "gen_project.bat wurde nicht gefunden."
    }
}

function Get-T {
    param($key)
    return $Translations[$Lang][$key]
}

# =========================
#   Dossiers
# =========================
$toolsPath = Join-Path $PSScriptRoot "Tools\templates"
$icoPath   = Join-Path $PSScriptRoot "ICO"
$zipIconPath = Join-Path $icoPath "zip.ico"

# =========================
#   Fen�tre principale
# =========================
$form = New-Object System.Windows.Forms.Form
$form.Text = Get-T "TITLE"
$form.Size = New-Object System.Drawing.Size(520, 420)
$form.StartPosition = "CenterScreen"
$form.BackColor = "#1E1E1E"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false

# =========================
#   Barre de recherche
# =========================
$lblSearch = New-Object System.Windows.Forms.Label
$lblSearch.Text = Get-T "SEARCH_PH"
$lblSearch.ForeColor = "White"
$lblSearch.Left = 10
$lblSearch.Top  = 10
$lblSearch.AutoSize = $true
$form.Controls.Add($lblSearch)

$txtSearch = New-Object System.Windows.Forms.TextBox
$txtSearch.Left = 10
$txtSearch.Top  = 30
$txtSearch.Width = 480
$txtSearch.BackColor = "#2A2A2A"
$txtSearch.ForeColor = "White"
$txtSearch.BorderStyle = "FixedSingle"
$form.Controls.Add($txtSearch)

# =========================
#   ListView des templates
# =========================
$list = New-Object System.Windows.Forms.ListView
$list.View = "Details"
$list.FullRowSelect = $true
$list.Left = 10
$list.Top  = 60
$list.Width = 480
$list.Height = 260
$list.BackColor = "#252526"
$list.ForeColor = "White"
$list.BorderStyle = "None"
$list.HideSelection = $false

$list.Columns.Add("Template", 320) | Out-Null
$list.Columns.Add("Size", 80)      | Out-Null
$list.Columns.Add("Modified", 80)  | Out-Null

# ImageList pour ic�nes
$imgList = New-Object System.Windows.Forms.ImageList
$imgList.ImageSize = New-Object System.Drawing.Size(16,16)

if (Test-Path $zipIconPath) {
    $zipIcon = [System.Drawing.Icon]::ExtractAssociatedIcon($zipIconPath)
    [void]$imgList.Images.Add("zip", $zipIcon)
}

$list.SmallImageList = $imgList

$form.Controls.Add($list)

# =========================
#   Chargement des templates
# =========================
$allTemplates = @()

if (Test-Path $toolsPath) {
    $allTemplates = Get-ChildItem $toolsPath -Filter *.zip -File | Sort-Object Name
}

function Refresh-List {
    $list.BeginUpdate()
    $list.Items.Clear()

    $filter = $txtSearch.Text.ToLower()

    foreach ($file in $allTemplates) {
        if (-not ($file.Name.ToLower() -like "*$filter*")) { continue }

        $item = New-Object System.Windows.Forms.ListViewItem($file.Name)
        $item.SubItems.Add("{0:N1} MB" -f ($file.Length / 1MB)) | Out-Null
        $item.SubItems.Add($file.LastWriteTime.ToString("dd/MM/yy")) | Out-Null
        if ($imgList.Images.ContainsKey("zip")) {
            $item.ImageKey = "zip"
        }
        $item.Tag = $file.FullName
        [void]$list.Items.Add($item)
    }

    $list.EndUpdate()
}

$txtSearch.Add_TextChanged({ Refresh-List })
Refresh-List

# =========================
#   Bouton Create
# =========================
$btnCreate = New-Object System.Windows.Forms.Button
$btnCreate.Text = Get-T "BTN_CREATE"
$btnCreate.Width = 120
$btnCreate.Height = 35
$btnCreate.Left = 190
$btnCreate.Top  = 330
$btnCreate.BackColor = "#8A2BE2"
$btnCreate.ForeColor = "White"
$btnCreate.FlatStyle = "Flat"
$btnCreate.FlatAppearance.BorderSize = 0

$btnCreate.Add_Click({
    if ($list.SelectedItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show((Get-T "MSG_SELECT"))
        return
    }

    $zipPath = $list.SelectedItems[0].Tag
    $bat = Join-Path $PSScriptRoot "gen_project.bat"

    if (-not (Test-Path $bat)) {
        [System.Windows.Forms.MessageBox]::Show((Get-T "MSG_BAT_MISSING"))
        return
    }

    # Lancer le batch avec le chemin du zip en argument
    Start-Process $bat "`"$zipPath`""

    $form.Close()
})

$form.Controls.Add($btnCreate)

$btnLang.Add_Click({
    $menu = New-Object System.Windows.Forms.Form
    $menu.Text = "Language"
    $menu.Size = New-Object System.Drawing.Size(200, 200)
    $menu.StartPosition = "CenterParent"
    $menu.FormBorderStyle = "FixedDialog"
    $menu.BackColor = "#1E1E1E"

    $listLang = New-Object System.Windows.Forms.ListBox
    $listLang.Dock = "Fill"
    $listLang.BackColor = "#1E1E1E"
    $listLang.ForeColor = "White"
    $listLang.Items.AddRange(@("FR","EN","ES","DE"))
    $menu.Controls.Add($listLang)

    $listLang.Add_DoubleClick({
        if ($listLang.SelectedItem) {
            $script:Lang = $listLang.SelectedItem

            # R�appliquer les textes
            $form.Text      = Get-T "TITLE"
            $lblSearch.Text = Get-T "SEARCH_PH"
            $btnCreate.Text = Get-T "BTN_CREATE"

            $menu.Close()
        }
    })

    $menu.ShowDialog($form)
})

# =========================
#   Lancement
# =========================
$form.ShowDialog()