@echo off
cd ../..
cls
echo =---------Ecrion Compiler---------=
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "use.ps1" %*
echo =------------------------------------=
exit