@echo off
cd report
start reporter.bat
exit