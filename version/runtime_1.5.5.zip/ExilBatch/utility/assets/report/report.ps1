Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ============================
# CONFIG
# ============================
$webhook = "https://discord.com/api/webhooks/1495751959540531202/AGH5VK2URqvgLSVdBd1-52cJiOBNJIaI3VShHLwu_t2bOoMxNIkrUzIOeRt9mtfCLxGq"

# ============================
# FONCTION : ENVOI FIABLE (LONG MESSAGES OK)
# ============================
function Send-DiscordMessage {
    param(
        [string]$Webhook,
        [string]$Content
    )

    $max = 1900  # marge de s�curit� Discord

    try {
        while ($Content.Length -gt $max) {
            $part = $Content.Substring(0, $max)
            $Content = $Content.Substring($max)

            $payload = @{ content = $part } | ConvertTo-Json
            Invoke-RestMethod -Uri $Webhook -Method POST -Body $payload -ContentType "application/json"
        }

        if ($Content.Length -gt 0) {
            $payload = @{ content = $Content } | ConvertTo-Json
            Invoke-RestMethod -Uri $Webhook -Method POST -Body $payload -ContentType "application/json"
        }

        return $true
    }
    catch {
        return $false
    }
}

# ============================
# FEN�TRE
# ============================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Ecrion Report"
$form.Size = New-Object System.Drawing.Size(450,350)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)

$violet = [System.Drawing.Color]::FromArgb(180,80,255)

# Sujet
$lblSujet = New-Object System.Windows.Forms.Label
$lblSujet.Text = "Objet :"
$lblSujet.Location = "10,20"
$lblSujet.ForeColor = $violet
$lblSujet.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblSujet)

$txtSujet = New-Object System.Windows.Forms.TextBox
$txtSujet.Location = "120,18"
$txtSujet.Size = "300,20"
$txtSujet.BackColor = [System.Drawing.Color]::FromArgb(50,50,50)
$txtSujet.ForeColor = "White"
$form.Controls.Add($txtSujet)

# Message
$lblMsg = New-Object System.Windows.Forms.Label
$lblMsg.Text = "Message :"
$lblMsg.Location = "10,56"
$lblMsg.ForeColor = $violet
$lblMsg.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblMsg)

$txtMsg = New-Object System.Windows.Forms.TextBox
$txtMsg.Location = "10,80"
$txtMsg.Size = "410,180"
$txtMsg.Multiline = $true
$txtMsg.ScrollBars = "Vertical"
$txtMsg.BackColor = [System.Drawing.Color]::FromArgb(50,50,50)
$txtMsg.ForeColor = "White"
$form.Controls.Add($txtMsg)

# Bouton envoyer
$btnSend = New-Object System.Windows.Forms.Button
$btnSend.Text = "Submit"
$btnSend.Location = "330,270"
$btnSend.Size = "90,30"
$btnSend.BackColor = $violet
$btnSend.ForeColor = "White"
$btnSend.FlatStyle = "Flat"
$btnSend.FlatAppearance.BorderSize = 0
$form.Controls.Add($btnSend)

# Bouton arrondi
$btnSend.Add_Paint({
    param($sender, $e)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddEllipse(0,-10,200,90)
    $sender.Region = New-Object System.Drawing.Region($path)
})

# ============================
# ACTION DU BOUTON
# ============================
$btnSend.Add_Click({
    $sujet = $txtSujet.Text.Trim()
    $message = $txtMsg.Text.Trim()

    if ($sujet -eq "" -or $message -eq "") {
        [System.Windows.Forms.MessageBox]::Show("Veuillez remplir tous les champs.")
        return
    }

    $fullMessage = "**Nouveau message utilisateur :**`n`n**Objet :** $sujet`n`n**Message :**`n$message"

    $result = Send-DiscordMessage -Webhook $webhook -Content $fullMessage

    if ($result -eq $true) {
        [System.Windows.Forms.MessageBox]::Show("Message envoy� avec succ�s !")
        $form.Close()
    }
    else {
        [System.Windows.Forms.MessageBox]::Show("(X)Message non envoy�. V�rifiez votre connexion internet.")
    }
})

$form.ShowDialog()