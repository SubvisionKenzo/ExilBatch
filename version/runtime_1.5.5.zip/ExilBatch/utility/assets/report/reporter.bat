@echo off
:: Varriable !
set "name=report"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min reporter.bat
exit
:execut
del %hide%.txt
:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait

set ERR=%ERRORLEVEL%

:: V�rifier si PowerShell a plant�
if %ERR% NEQ 0 (
    start editor.vbs
    exit /b
)

exit > nul