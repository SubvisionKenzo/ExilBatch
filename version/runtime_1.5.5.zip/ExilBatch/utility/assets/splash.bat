@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
cd splash
cmd /c start /min readydel.bat
start splash.hta /splashtool.vbs
exit > nul