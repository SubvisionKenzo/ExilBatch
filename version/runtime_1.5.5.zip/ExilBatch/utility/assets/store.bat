@echo off
cd /d "%~dp0"
cd ..
cd store
start store.bat
exit