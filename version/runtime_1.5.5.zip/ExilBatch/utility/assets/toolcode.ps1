Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Chemin du script
if ($PSScriptRoot) {
    $scriptDir = $PSScriptRoot
} else {
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
}

# Remonter d�un dossier (assets - utility)
$parentDir = Split-Path -Parent $scriptDir

# Chemin vers functions.json
$FunctionFile = Join-Path $parentDir "function.json"

Write-Host "ScriptDir  : $scriptDir"
Write-Host "ParentDir  : $parentDir"
Write-Host "Functions  : $FunctionFile"

$functions = Get-Content $FunctionFile -Raw | ConvertFrom-Json

# === Charger le JSON ===

# Extraire toutes les cl�s commen�ant par $
$allKeys = @()

foreach ($section in $functions.PSObject.Properties.Name) {
    $keys = $functions.$section.PSObject.Properties.Name
    foreach ($k in $keys) {
        if ($k.StartsWith('$')) {
            $allKeys += $k
        }
    }
}

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class ShellIcons {
    [StructLayout(LayoutKind.Sequential)]
    public struct SHFILEINFO {
        public IntPtr hIcon;
        public int iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    }

    public const uint SHGFI_ICON = 0x100;
    public const uint SHGFI_LARGEICON = 0x0;      // 32x32
    public const uint SHGFI_USEFILEATTRIBUTES = 0x10;

    public const uint FILE_ATTRIBUTE_FILE = 0x80;
    public const uint FILE_ATTRIBUTE_DIRECTORY = 0x10;

    [DllImport("shell32.dll")]
    public static extern IntPtr SHGetFileInfo(
        string pszPath,
        uint dwFileAttributes,
        ref SHFILEINFO psfi,
        uint cbFileInfo,
        uint uFlags
    );
}
"@

function Get-FileIcon32 {
    param($path, [bool]$isFolder)

    $info = New-Object ShellIcons+SHFILEINFO

    if ($isFolder) {
        $attr = [ShellIcons]::FILE_ATTRIBUTE_DIRECTORY
    } else {
        $attr = [ShellIcons]::FILE_ATTRIBUTE_FILE
    }

    $flags = [ShellIcons]::SHGFI_ICON -bor [ShellIcons]::SHGFI_LARGEICON -bor [ShellIcons]::SHGFI_USEFILEATTRIBUTES

    [ShellIcons]::SHGetFileInfo($path, $attr, [ref]$info, [System.Runtime.InteropServices.Marshal]::SizeOf($info), $flags) | Out-Null

    if ($info.hIcon -ne [IntPtr]::Zero) {
        return [System.Drawing.Icon]::FromHandle($info.hIcon)
    }

    return $null
}

# === Fen�tre principale ===
$form = New-Object System.Windows.Forms.Form
$form.Text = "ExilBatch ToolCode"
$form.Size = New-Object System.Drawing.Size(400,300)
$form.StartPosition = "CenterScreen"
$form.BackColor = "#1E1E1E"
$form.TopMost = $true

# === RichTextBox (au lieu de TextBox) ===
$box = New-Object System.Windows.Forms.RichTextBox
$box.Multiline = $true
$box.ScrollBars = "Vertical"
$box.Font = New-Object System.Drawing.Font("Consolas",12)
$box.Dock = "Fill"
$box.BackColor = "#1E1E1E"
$box.ForeColor = "White"
$box.BorderStyle = "None"
$box.WordWrap = $false

# === Liste d'autocompl�tion ===
$list = New-Object System.Windows.Forms.ListBox
$list.Visible = $false
$list.Font = New-Object System.Drawing.Font("Consolas",12)
$list.Height = 150
$list.Width = 350
$list.BackColor = "#252526"
$list.ForeColor = "White"
$list.BorderStyle = "FixedSingle"
$list.IntegralHeight = $false

$form.Controls.Add($box)
$form.Controls.Add($list)

# === Fonction : afficher les suggestions ===
function Show-Suggestions {
    param($word)

    $matches = $allKeys | Where-Object { $_ -like "$word*" }

    if ($matches.Count -gt 0) {
        $list.Items.Clear()
        $matches | ForEach-Object { $list.Items.Add($_) }

        # Positionner la liste en haut � gauche (simple)
        $list.Location = New-Object System.Drawing.Point(10, 30)
        $list.Visible = $true
        $list.BringToFront()
    }
    else {
        $list.Visible = $false
    }
}

# === Coloration syntaxique ===
function Apply-SyntaxHighlight {
    $selectionStart  = $box.SelectionStart
    $selectionLength = $box.SelectionLength

    $box.SuspendLayout()

    # Tout en blanc au d�part
    $box.SelectionStart = 0
    $box.SelectionLength = $box.Text.Length
    $box.SelectionColor = [System.Drawing.Color]::White

    $text = $box.Text

    # () [] {} "" en jaune
    $patternYellow = '[\(\)\[\]\{\]""]'
    foreach ($m in [System.Text.RegularExpressions.Regex]::Matches($text, $patternYellow)) {
        $box.Select($m.Index, $m.Length)
        $box.SelectionColor = [System.Drawing.Color]::Yellow
    }

    # = . + - en bleu
    $patternBlue = '[=\.\+\-]'
    foreach ($m in [System.Text.RegularExpressions.Regex]::Matches($text, $patternBlue)) {
        $box.Select($m.Index, $m.Length)
        $box.SelectionColor = [System.Drawing.Color]::DodgerBlue
    }

    # $ en orange
    $patternOrange = '[$]'
    foreach ($m in [System.Text.RegularExpressions.Regex]::Matches($text, $patternOrange)) {
        $box.Select($m.Index, $m.Length)
        $box.SelectionColor = [System.Drawing.Color]::Orange
    }

    # Mots-cl�s en rouge
    $patternRed = '\b(POWERSHELL|BAT|VBS|HTML|HTA|JAVA|JS)\b'
    foreach ($m in [System.Text.RegularExpressions.Regex]::Matches($text, $patternRed, "IgnoreCase")) {
        $box.Select($m.Index, $m.Length)
        $box.SelectionColor = [System.Drawing.Color]::Red
    }

    # Nombres de 1 � 10 en vert
    $patternGreen = '\b([1-9]|10)\b'
    foreach ($m in [System.Text.RegularExpressions.Regex]::Matches($text, $patternGreen)) {
        $box.Select($m.Index, $m.Length)
        $box.SelectionColor = [System.Drawing.Color]::LimeGreen
    }

    # Restaurer la s�lection
    $box.Select($selectionStart, $selectionLength)
    $box.ResumeLayout()
}

# === D�tection de la frappe dans la textbox ===
$box.Add_KeyUp({
    param($sender, $event)

    $text = $box.Text
    $cursor = $box.SelectionStart

    if ($cursor -le 0) { 
        $list.Visible = $false
        return 
    }

    # R�cup�rer le mot en cours
    $before = $text.Substring(0, $cursor)
    $word = ($before -split "[\s`n`r]")[-1]

    if ($word.StartsWith('$')) {
        Show-Suggestions $word
    }
    else {
        $list.Visible = $false
    }

    Apply-SyntaxHighlight
})

# === Ins�rer la suggestion quand l'utilisateur appuie sur Entr�e ===
$list.Add_KeyDown({
    param($sender, $event)

    if ($event.KeyCode -eq "Enter") {
        $selected = $list.SelectedItem
        if ($selected) {
            $box.SelectedText = $selected
            $list.Visible = $false
            $box.Focus()
        }
    }
})

# === Double clic sur un �l�ment ===
$list.Add_MouseDoubleClick({
    $selected = $list.SelectedItem
    if ($selected) {
        $box.SelectedText = $selected
        $list.Visible = $false
        $box.Focus()
    }
})

$form.ShowDialog()