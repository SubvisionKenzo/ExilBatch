@echo off
cd /d "%~dp0"
cd ..
cd config\uninstall
start uninstallconfirm.bat
exit > nul