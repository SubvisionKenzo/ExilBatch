@echo off
cd /d "%~dp0"
cd ..
cd update
start stat.bat
exit > nul