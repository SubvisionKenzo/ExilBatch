Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase

# --- Dossiers ---
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = Split-Path -Parent $Root
$SaveDir = Join-Path $AppRoot "save"
$IconsDir = Join-Path $AppRoot "ICO"

# --- Fichiers de configuration ---
$ThemeFile        = Join-Path $SaveDir "themes.txt"
$ThemeBarFile     = Join-Path $SaveDir "themesbar.txt"
$SolutionSizeFile = Join-Path $SaveDir "solutionsize.txt"
$SolutionShowFile = Join-Path $SaveDir "solutionshow.txt"
$DialogFile       = Join-Path $AppRoot "editor.dialog.txt"
$xamlPath = Join-Path $AppRoot "xaml\settings.xaml"
$xaml = Get-Content $xamlPath -Raw
$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$CustomBar      = $window.FindName("CustomBar")
$BarIcon        = $window.FindName("BarIcon")
$BtnClose       = $window.FindName("BtnClose")
$ThemeSelector  = $window.FindName("ThemeSelector")
$ExplorerSize   = $window.FindName("ExplorerSize")
$BtnSizeUp      = $window.FindName("BtnSizeUp")
$BtnSizeDown    = $window.FindName("BtnSizeDown")
$ChkExplorerShow = $window.FindName("ChkExplorerShow")
$BarColor       = $window.FindName("BarColor")
$BtnSave        = $window.FindName("BtnSave")
$Translations = @{}

if (Test-Path $DialogFile) {
    foreach ($line in Get-Content $DialogFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $key = $matches[1].Trim()
            $val = $matches[2].Trim()
            $Translations[$key] = $val
        }
    }
}
function Set-TranslatedText {
    param(
        [System.Windows.Controls.Control]$Control,
        [string]$Key
    )

    if ($Translations.ContainsKey($Key)) {
        if ($Control -is [System.Windows.Controls.TextBlock]) {
            $Control.Text = $Translations[$Key]
        }
        elseif ($Control -is [System.Windows.Controls.Button]) {
            $Control.Content = $Translations[$Key]
        }
        elseif ($Control -is [System.Windows.Controls.ComboBoxItem]) {
            $Control.Content = $Translations[$Key]
        }
    }
}
$BarIcon.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri](Join-Path $IconsDir "store.png"))
$BtnClose.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri](Join-Path $IconsDir "close.png"))

# Hover close button
$BtnClose.Add_MouseEnter({
    $BtnClose.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri](Join-Path $IconsDir "close_after.png"))
})
$BtnClose.Add_MouseLeave({
    $BtnClose.Source = New-Object System.Windows.Media.Imaging.BitmapImage([Uri](Join-Path $IconsDir "close.png"))
})
$CustomBar.Add_MouseLeftButtonDown({
    $window.DragMove()
})
if ($Translations.ContainsKey("TITLE")) {
    $window.Title = $Translations["TITLE"]
}

# Traduction des labels
Set-TranslatedText -Control ($ThemeSelector.Parent.Children[0]) -Key "LBL_THEME"
Set-TranslatedText -Control ($ExplorerSize.Parent.Parent.Children[0]) -Key "LBL_EXPLORER_SIZE"
Set-TranslatedText -Control ($ChkExplorerShow.Parent.Children[0]) -Key "LBL_EXPLORER_SHOW"
Set-TranslatedText -Control ($BarColor.Parent.Children[0]) -Key "LBL_BAR_COLOR"

# Traduction du bouton Sauvegarder
Set-TranslatedText -Control $BtnSave -Key "BTN_OK"

# Traduction des ComboBoxItem
foreach ($item in $ThemeSelector.Items) {
    if ($item.Tag -eq "0") { Set-TranslatedText -Control $item -Key "THEME_LIGHT" }
    if ($item.Tag -eq "1") { Set-TranslatedText -Control $item -Key "THEME_DARK" }
}
if (Test-Path $ThemeFile) {
    $ThemeSelector.SelectedIndex = [int](Get-Content $ThemeFile)
}

if (Test-Path $SolutionSizeFile) {
    $ExplorerSize.Text = (Get-Content $SolutionSizeFile)
}

if (Test-Path $SolutionShowFile) {
    $ChkExplorerShow.IsChecked = ((Get-Content $SolutionShowFile) -eq "1")
}

if (Test-Path $ThemeBarFile) {
    $BarColor.Text = (Get-Content $ThemeBarFile)
}
$BtnSizeUp.Add_Click({
    $val = [int]$ExplorerSize.Text
    $ExplorerSize.Text = ($val + 10)
})

$BtnSizeDown.Add_Click({
    $val = [int]$ExplorerSize.Text
    if ($val -gt 100) {
        $ExplorerSize.Text = ($val - 10)
    }
})
$BtnSave.Add_Click({

    Set-Content $ThemeFile $ThemeSelector.SelectedIndex
    Set-Content $SolutionSizeFile $ExplorerSize.Text

    if ($ChkExplorerShow.IsChecked) {
        Set-Content $SolutionShowFile "1"
    } else {
        Set-Content $SolutionShowFile "0"
    }

    Set-Content $ThemeBarFile $BarColor.Text

    $window.Close()
})
$BtnClose.Add_MouseLeftButtonDown({
    $window.Close()
})
$window.ShowDialog() | Out-Null