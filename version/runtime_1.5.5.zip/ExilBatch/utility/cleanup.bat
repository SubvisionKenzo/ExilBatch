@echo off
cd /d "%~dp0"
for /d %%a in ("*.ecb") do (
    rmdir /s /q "%%a" >nul 2>&1
)
for /d %%b in ("*.ecb.zip") do (
    rmdir /s /q "%%b" >nul 2>&1
)
del /f /q "fils\*" /F >nul 2>&1
exit
