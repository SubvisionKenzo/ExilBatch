param(
    [Parameter(Mandatory=$true)]
    [string]$ShortcutFolder,

    [Parameter(Mandatory=$true)]
    [string]$TargetPath,

    [Parameter(Mandatory=$false)]
    [string]$IconPath
)

# Vérifie si le dossier existe
if (-not (Test-Path $ShortcutFolder)) {
    Write-Host "Le dossier n'existe pas, création..."
    New-Item -ItemType Directory -Path $ShortcutFolder | Out-Null
}

# Nom du raccourci = nom du fichier cible
$ShortcutName = [System.IO.Path]::GetFileNameWithoutExtension($TargetPath) + ".lnk"
$ShortcutFullPath = Join-Path $ShortcutFolder $ShortcutName

# Objet COM pour créer le raccourci
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutFullPath)

$Shortcut.TargetPath = $TargetPath

# Ajout de l’icône si fournie
if ($IconPath) {
    $Shortcut.IconLocation = $IconPath
}

$Shortcut.Save()

Write-Host "Output : $ShortcutFullPath"