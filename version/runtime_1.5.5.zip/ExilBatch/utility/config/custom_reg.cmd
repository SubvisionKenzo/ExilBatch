@echo off
set "INSTALL_DIR=%1"
(
echo Windows Registry Editor Version 5.00
echo.
echo [HKEY_CLASSES_ROOT\.ecb]
echo @="ExilBatch.File"
echo "Content Type"="application/exilbatch"
echo [HKEY_CLASSES_ROOT\ExilBatch.File]
echo @="Raw executable compressor"
echo [HKEY_CLASSES_ROOT\ExilBatch.File\DefaultIcon]
echo @="\"%INSTALL_DIR%\\utility\\icon\\32x32.ico\",0"
echo [HKEY_CLASSES_ROOT\ExilBatch.File\shell\open\command]
echo @="\"%INSTALL_DIR%\\utility\\consol.cmd\" \"%1\""
) > custom_reg.reg
exit