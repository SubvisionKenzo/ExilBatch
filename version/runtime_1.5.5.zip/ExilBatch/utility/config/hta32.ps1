# Vérifier l'association actuelle de .hta
$htaAssoc = Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.hta\UserChoice" -ErrorAction SilentlyContinue

if ($htaAssoc) {
    Write-Host "Stat : $($htaAssoc.ProgId)"
} else {
    Write-Host "false"
}

# ProgID attendu pour les fichiers HTA
$expectedProgId = "htafile"

# Si l'association n'est pas correcte, on la répare
if ($htaAssoc.ProgId -ne $expectedProgId) {
    Write-Host "Debuging..."

    # Supprimer l'association incorrecte
    Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.hta\UserChoice" -Force -ErrorAction SilentlyContinue

    # Créer la bonne association
    New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.hta\UserChoice" -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.hta\UserChoice" -Name "ProgId" -Value $expectedProgId

    Write-Host "true"
} else {
    Write-Host "error"
}