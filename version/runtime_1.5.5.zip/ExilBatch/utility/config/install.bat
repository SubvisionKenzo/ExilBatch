@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

:: Corrections Utility system !
PowerShell -ExecutionPolicy Bypass -File "hta32.ps1"

if "%~1"=="2" goto deployenv
if "%~1"=="" (
    set "SOURCE=C:\ECB"
) else (
    set "SOURCE=%1"
)
goto runinstallation
:deployenv
set "SOURCE=%2"
:runinstallation
set "INSTALL_DIR=%SOURCE%"
echo %INSTALL_DIR%

:: V�rifie si un argument est fourni
if "%SOURCE%"=="C:\ECB" (
    regedit /s config.reg
    goto pass1
)
start custom_reg.cmd %INSTALL_DIR%
echo hello world
timeout 1 >nul
regedit /s custom_reg.reg
del custom_reg.reg

:pass1
PowerShell -ExecutionPolicy Bypass -File "shortcut.ps1" %SOURCE%\utility\assets\LaucherRun.bat %SOURCE%\utility\icon\editor.ico
pushd C:\
mkdir "%SOURCE%"
popd
cd ..\..
set "tempdir=%SOURCE%\utility"
echo %SOURCE%\utility
if "%~1"=="2" goto deployclose
if exist "%tempdir%" rd /s /q "%tempdir%"
mkdir "%tempdir%"
echo "%tempdir%"

if not exist "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ExilBatch" mkdir "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ExilBatch"
pushd C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ExilBatch
echo %SOURCE%\utility\assets\$~Envruntimes > dir.txt
popd

xcopy "%cd%\utility\*" "%tempdir%\" /E /I /Y >nul
for %%f in ("%tempdir%\*") do (
    set "firstfile=%%~nxf"
    goto found
)
exit
:found
cd ..\..
cd %SOURCE%\utility\config
start lang.bat
cd ..
cd update
if not exist export.bat goto skipexport
start export.bat %SOURCE%\utility
:skipexport
cd %SOURCE%\utility\config
set tempfile=0
if exist 7z.dll set /a tempfile=tempfile+1
if exist 7z.exe set /a tempfile=tempfile+1
if exist curl.exe set /a tempfile=tempfile+1
if exist bar.ps1 set /a tempfile=tempfile+1
if "%tempfile%"=="4" goto deltempfile
echo %tempfile%
echo succes
exit

:deltempfile
:: Cleaning up installation file !
echo hello world
del 7z.exe
del 7z.dll
del curl.exe
del bar.ps1
del download.bat
del localinstall.zip
del runtime_version.xml
del update.ps1
del bin.zip
del cleanup.bat
exit
:deployclose