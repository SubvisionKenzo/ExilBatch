@echo off
cd /d "%~dp0"
cd ..
PowerShell -ExecutionPolicy Bypass -File "lang.ps1" /wait
exit