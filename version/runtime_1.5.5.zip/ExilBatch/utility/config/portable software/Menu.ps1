Add-Type -AssemblyName PresentationFramework

# --- Se placer dans le dossier du script ---
Set-Location -Path $PSScriptRoot

# --- Lecture du fichier mainmenu.txt ---
$menuFile = Join-Path $PSScriptRoot "mainmenu.txt"
$entries = @{}

if (Test-Path $menuFile) {
    foreach ($line in Get-Content $menuFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()

            # Nettoyage des guillemets
            $value = $value.Trim('"')

            # Si le chemin est relatif ? on le convertit en absolu
            if (-not ([System.IO.Path]::IsPathRooted($value))) {
                $value = Join-Path $PSScriptRoot $value
            }

            $entries[$key] = $value
        }
    }
} else {
    [System.Windows.MessageBox]::Show("mainmenu.txt introuvable.")
    exit
}

# --- Cr�ation de la fen�tre ---
$window = New-Object System.Windows.Window
$window.Title = "ExilBatch Menu"
$window.Width = 300
$window.Height = 380
$window.WindowStartupLocation = "CenterScreen"
$window.Background = "#1e1e1e"
$window.Foreground = "White"
$window.ResizeMode = "NoResize"
$window.Topmost = $true

# --- Liste ---
$list = New-Object System.Windows.Controls.ListBox
$list.Background = "#2b2b2b"
$list.Foreground = "White"
$list.BorderBrush = "#444"
$list.Margin = "10"
$list.FontSize = 14

foreach ($key in $entries.Keys) {
    $list.Items.Add($key)
}

# --- Fonction pour lancer ---
function Launch-Selected {
    $selected = $list.SelectedItem

    if (-not $selected) {
        return
    }

    $path = $entries[$selected]

    if (-not (Test-Path $path)) {
        [System.Windows.MessageBox]::Show("Le fichier n'existe pas : `n$path")
        return
    }

    Start-Process $path
}

# --- Double-clic ---
$list.Add_MouseDoubleClick({
    Launch-Selected
})

# --- Touche Entr�e ---
$list.Add_KeyDown({
    if ($_.Key -eq "Enter") {
        Launch-Selected
    }
})

$window.Content = $list

# --- Affichage ---
$window.ShowDialog() | Out-Null