@echo off
cd /d "%~dp0"
cd ..\..\..
cd assets
start LaucherRun.bat
exit