@echo off
cd /d "%~dp0"
cd ..\..
cd uninstall
:: dell all ExilBatch environnement !
reg delete "HKCR\.ecb" /f
reg delete "HKCR\ExilBatch.File" /f
reg delete "HKCU\Software\Classes\.ecb" /f
reg delete "HKCU\Software\Classes\ExilBatch.File" /f
reg delete "HKLM\Software\Classes\.ecb" /f
reg delete "HKLM\Software\Classes\ExilBatch.File" /f
del "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Ecrion Editor.lnk"
del "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Ecrion dev.lnk"�
if exist "C:\Users\%username%AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\autoclean.bat" cd "C:\Users\%username%AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\autoclean.bat"
del autoclean.bat
exit