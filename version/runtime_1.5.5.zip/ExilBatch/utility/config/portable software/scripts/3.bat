@echo off
cd /d "%~dp0"
set "currentpath=%cd%"
cd ..\..\..\..
set "env=%cd%"
cd %currentpath%
cd ..\..
start install.bat 2 ExilBatch\%env%
exit