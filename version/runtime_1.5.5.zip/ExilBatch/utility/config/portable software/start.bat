@echo off
cd /d "%~dp0"
set "name=Menu"
set "hide=hidden"
if exist %hide%.txt goto execut
echo >> %hide%.txt
cmd /c start /min start.bat
exit
:execut
del %hide%.txt
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul