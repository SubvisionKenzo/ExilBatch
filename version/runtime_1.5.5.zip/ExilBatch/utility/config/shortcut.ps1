param(
    [string]$arg1,   # Chemin du .bat
    [string]$arg2    # Chemin de l'ic�ne
)

# Valeurs par d�faut
$target = "C:\ECB\utility\assets\LaucherRun.bat"
$iconPath = "C:\ECB\utility\icon\editor.ico"

# Si un argument est fourni, on remplace
if ($arg1) { $target = $arg1 }
if ($arg2) { $iconPath = $arg2 }

$startup = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Ecrion Editor.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($startup)
$Shortcut.TargetPath = $target
$Shortcut.WorkingDirectory = Split-Path $target
$Shortcut.IconLocation = $iconPath
$Shortcut.Save()