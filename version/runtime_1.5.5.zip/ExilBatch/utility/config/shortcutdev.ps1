$target = "C:\ECB\utility\Terrminal\Terminal.bat"
$startup = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Ecrion dev.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($startup)
$Shortcut.TargetPath = $target
$Shortcut.WorkingDirectory = Split-Path $target
$Shortcut.IconLocation = "C:\ECB\utility\icon\devtools.ico"
$Shortcut.Save()
