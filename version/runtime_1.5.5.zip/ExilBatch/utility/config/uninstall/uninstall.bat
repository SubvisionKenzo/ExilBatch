@echo off
cd /d "%~dp0"
del "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Ecrion Editor.lnk"
del "C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Ecrion dev.lnk"
cd ..\..
set "tempdir=%cd%"
set "pathToRemove=%cd%"
cd "config\uninstall"
del /F /Q "C:\%tempdir%\*"
rmdir /S /Q "%tempdir%"
:: Reg delet !
reg delete "HKCR\.ecb" /f
reg delete "HKCR\ExilBatch.File" /f
reg delete "HKCU\Software\Classes\.ecb" /f
reg delete "HKCU\Software\Classes\ExilBatch.File" /f
reg delete "HKLM\Software\Classes\.ecb" /f
reg delete "HKLM\Software\Classes\ExilBatch.File" /f

echo %PATH% | findstr /I "%pathToAdd%" >nul
if %errorlevel%==0 (
    exit
) else (
    powershell -NoLogo -NoProfile -Command ^
    "$old = [Environment]::GetEnvironmentVariable('PATH','User');" ^
    "$parts = $old -split ';';" ^
    "$new = ($parts | Where-Object { $_ -ne '%pathToRemove%' -and $_ -ne '' }) -join ';';" ^
    "[Environment]::SetEnvironmentVariable('PATH',$new,'User');"
)

ie4uinit.exe -ClearIconCache >nul 2>&1
taskkill /IM explorer.exe /F >nul 2>&1
start explorer.exe
exit