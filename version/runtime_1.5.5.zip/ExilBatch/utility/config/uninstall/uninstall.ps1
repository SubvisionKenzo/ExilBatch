Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# === Cr�ation de la fen�tre ===
$form = New-Object System.Windows.Forms.Form
$form.Text = "D�sinstalleur ExilBatch"
$form.Size = New-Object System.Drawing.Size(500,300)
$form.StartPosition = "CenterScreen"
$form.TopMost = $true

# === Texte d'information ===
$label = New-Object System.Windows.Forms.Label
$label.Text = "Ce programme vous aide � d�sinstaller ExilBatch en toute s�curit�.`n`n�tapes recommand�es :`n- Supprimer les cl�s de registre cr��es par Config.reg`n- Supprimer le dossier d'installation C:\ECB"
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20,20)
$form.Controls.Add($label)

# === Bouton : Voir les cl�s de registre ===
$btnReg = New-Object System.Windows.Forms.Button
$btnReg.Text = "Afficher les cl�s � supprimer"
$btnReg.Size = New-Object System.Drawing.Size(200,30)
$btnReg.Location = New-Object System.Drawing.Point(20,120)
$btnReg.Add_Click({
    [System.Windows.Forms.MessageBox]::Show(
        "Supprimer manuellement les cl�s suivantes :`n`nHKEY_CLASSES_ROOT\.ecb`nHKEY_CLASSES_ROOT\ExilBatch.File",
        "Cl�s de registre ExilBatch",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
})
$form.Controls.Add($btnReg)

# === Bouton : Ouvrir le dossier C:\ECB ===
$btnFolder = New-Object System.Windows.Forms.Button
$btnFolder.Text = "Ouvrir le dossier C:\ECB"
$btnFolder.Size = New-Object System.Drawing.Size(200,30)
$btnFolder.Location = New-Object System.Drawing.Point(20,160)
$btnFolder.Add_Click({
    Start-Process "explorer.exe" "C:\ECB"
})
$form.Controls.Add($btnFolder)

# === Bouton : Quitter ===
$btnQuit = New-Object System.Windows.Forms.Button
$btnQuit.Text = "Fermer"
$btnQuit.Size = New-Object System.Drawing.Size(100,30)
$btnQuit.Location = New-Object System.Drawing.Point(350,200)
$btnQuit.Add_Click({ $form.Close() })
$form.Controls.Add($btnQuit)

# === Affichage de la fen�tre ===
$form.ShowDialog()
