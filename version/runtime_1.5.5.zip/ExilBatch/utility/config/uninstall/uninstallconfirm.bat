@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
:: Varriable !
set "name=uninstallconfirm"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min uninstallconfirm.bat
exit
:execut
del %hide%.txt

cd ..
cd ..

rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === D�tection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.

cd config\uninstall

cd assets
del Editore.Dialog.txt
echo TITLE=%TITLE% >> Editore.Dialog.txt
echo MSG=%MSG% >>Editore.Dialog.txt

:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul