# === D�terminer le dossier du script, m�me si $PSScriptRoot est vide ===
if (-not $PSScriptRoot -or $PSScriptRoot -eq "") {
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
} else {
    $scriptDir = $PSScriptRoot
}

# === Charger la lib pour les fen�tres WPF ===
Add-Type -AssemblyName PresentationFramework

# === Charger le fichier de langue dans le m�me dossier ===
$langFile = Join-Path $scriptDir "Editore.Dialog.txt"

if (!(Test-Path $langFile)) {
    [System.Windows.MessageBox]::Show("File ressource : Editore.Dialog.txt not found", "Erreur", "OK", "Error")
    exit
}

# Lire les valeurs du fichier
$lang = @{}
Get-Content $langFile | ForEach-Object {
    if ($_ -match "=") {
        $k, $v = $_ -split "=", 2
        $lang[$k.Trim()] = $v.Trim()
    }
}

$title   = $lang["TITLE"]
$message = $lang["MSG"]

# === Fen�tre moderne Yes/No ===
$result = [System.Windows.MessageBox]::Show(
    $message,
    $title,
    "YesNo",
    "Information"
)

# === Si l'utilisateur clique sur Oui ===
if ($result -eq "Yes") {

    $uninstallPath = Join-Path $scriptDir "uninstall.bat"

    if (Test-Path $uninstallPath) {
        Start-Process -FilePath $uninstallPath -Verb RunAs
    } else {
        [System.Windows.MessageBox]::Show("File uninstall.bat not found", "Erreur", "OK", "Error")
    }
}