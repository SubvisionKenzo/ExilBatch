@echo off
cd /d "%~dp0"
start cleanup.bat
set "arg=%1"
for %%l in (%*) do (
	set "arg=%%l"
)
set "arg2=%2"
if /i %arg% EQU 1 goto clean
if /i %arg% EQU 2 goto packages
if /i %arg% EQU 3 goto update
title %arg%
start shell.bat %arg%
exit
:clean
start shell.bat 1
exit > nul
:packages
cd packager
start packages.bat %3
exit > nul
:update
cd update
start update.bat
exit > nul