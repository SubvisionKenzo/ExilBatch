param(
    [string]$AppName,
    [string]$Extension
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Dossier du script ---
$base = Split-Path -Parent $MyInvocation.MyCommand.Path

# --- Charger le texte traduit depuis showdialog.txt ---
$dialogFile = Join-Path $base "showdialog.txt"
$translations = @{}

if (Test-Path $dialogFile) {
    foreach ($line in Get-Content $dialogFile) {
        if ($line -match "^(.*?)=(.*)$") {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()
            $translations[$key] = $value
        }
    }
} else {
    # Valeurs par défaut si le fichier n'existe pas
    $translations["ERROR_TEXT"]  = "Fichier showdialog.txt introuvable."
    $translations["ERROR_TEXT2"] = "Fichier showdialog.txt introuvable."
    $translations["ERROR_TEXT3"] = "Fichier showdialog.txt introuvable."
}

# --- Identifiants ---
$identifier1 = "ERROR_TEXT"
$identifier2 = "ERROR_TEXT2"
$identifier3 = "ERROR_TEXT3"

# --- Récupération sécurisée ---
$translatedText  = $translations[$identifier1]
$translatedText2 = $translations[$identifier2]
$translatedText3 = $translations[$identifier3]

# --- Construire le texte final ---
$message = @"

$translatedText $AppName $translatedText2 ($Extension) $translatedText3

"@

# --- Fenêtre moderne ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "Error - $AppName ($Extension)"
$form.Size = New-Object System.Drawing.Size(600,420)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(32,32,32)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

# --- Icône PNG dans la fenêtre ---
$iconImgPath = Join-Path $base "assets\ICO\error64x64.png"
if (Test-Path $iconImgPath) {
    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.Image = [System.Drawing.Image]::FromFile($iconImgPath)
    $pic.SizeMode = "StretchImage"
    $pic.Location = New-Object System.Drawing.Point(20,20)
    $pic.Size = New-Object System.Drawing.Size(64,64)
    $form.Controls.Add($pic)
}

# --- Zone de texte moderne (TextBox readonly) ---
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Multiline = $true
$textBox.ReadOnly = $true
$textBox.ScrollBars = "Vertical"
$textBox.BackColor = [System.Drawing.Color]::FromArgb(45,45,45)
$textBox.ForeColor = [System.Drawing.Color]::White
$textBox.BorderStyle = "FixedSingle"
$textBox.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$textBox.Location = New-Object System.Drawing.Point(100,20)
$textBox.Size = New-Object System.Drawing.Size(470,180)
$textBox.Text = $message
$form.Controls.Add($textBox)

# --- Lien cliquable bleu ---
$link = New-Object System.Windows.Forms.LinkLabel
$link.Text = "ECB Store"
$link.LinkColor = [System.Drawing.Color]::FromArgb(0,120,215)
$link.ActiveLinkColor = [System.Drawing.Color]::FromArgb(0,150,255)
$link.Location = New-Object System.Drawing.Point(100,210)
$link.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$link.AutoSize = $true

$link.Add_Click({
    Start-Process (Join-Path $base "store\store.bat")
})

$form.Controls.Add($link)

# --- Section Logs ---
$logFile = Join-Path $base "error.log"

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = "Logs ----------------------"
$logLabel.Location = New-Object System.Drawing.Point(20,260)
$logLabel.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$logLabel.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($logLabel)

# --- Zone logs (si fichier détecté) ---
if (Test-Path $logFile) {
    $logBox = New-Object System.Windows.Forms.TextBox
    $logBox.Multiline = $true
    $logBox.ReadOnly = $true
    $logBox.ScrollBars = "Vertical"
    $logBox.BackColor = [System.Drawing.Color]::FromArgb(45,45,45)
    $logBox.ForeColor = [System.Drawing.Color]::White
    $logBox.BorderStyle = "FixedSingle"
    $logBox.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $logBox.Location = New-Object System.Drawing.Point(20,290)
    $logBox.Size = New-Object System.Drawing.Size(550,100)
    $logBox.Text = (Get-Content $logFile -Raw)
    $form.Controls.Add($logBox)
}

# --- Afficher la fenêtre ---
$form.ShowDialog()