@echo off
setlocal enabledelayedexpansion

:: ============================
:: GUI.BAT � Lanceur JSON -> GUI
:: ============================

:: V�rifier qu�un argument est fourni
if "%~1"=="" (
    echo.
    echo Usage : gui.bat fichier.json
    echo.
    pause
    exit /b
)

set "json=%~1"

:: V�rifier que le fichier JSON existe
if not exist "%json%" (
    echo.
    echo.
    pause
    exit /b
)

:: D�terminer le dossier du script
set "base=%~dp0"

:: V�rifier que wingui.ps1 existe
if not exist "%base%wingui.ps1" (
    echo.
    echo %base%
    echo.
    pause
    exit /b
)

:: V�rifier que lib.txt existe
if not exist "%base%lib.txt" (
    echo.
    echo %base%
    echo.
    pause
    exit /b
)
:: Lancer le moteur PowerShell
powershell -NoLogo -ExecutionPolicy Bypass -File "%base%wingui.ps1" "%json%"

exit /b