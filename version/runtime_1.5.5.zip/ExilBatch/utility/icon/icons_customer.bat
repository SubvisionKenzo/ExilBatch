@echo off
:: Varriable !
set "name=icons_customer"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min icons_customer.bat
exit
:execut
del %hide%.txt
:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait

exit > nul