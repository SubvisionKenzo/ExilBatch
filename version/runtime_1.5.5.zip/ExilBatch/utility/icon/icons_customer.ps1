Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================
# PATHS
# ============================
$BasePath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$OtherDir = Join-Path $BasePath "other"
$MapFile  = Join-Path $BasePath "icons_map.txt"
$LangDir  = Join-Path $BasePath "lang"
$ActiveIcon = Join-Path $BasePath "32x32.ico"

# ============================
# DETECTION LANGUE
# ============================
$sys = (Get-Culture).TwoLetterISOLanguageName
switch ($sys) {
    "fr" { $L = "FR" }
    "es" { $L = "ES" }
    default { $L = "EN" }
}

# ============================
# CHARGEMENT LANGUE
# ============================
function Load-Lang {
    $file = Join-Path $LangDir "$L.lang"
    if (-not (Test-Path $file)) { $file = Join-Path $LangDir "EN.lang" }

    $Global:TXT = @{}
    foreach ($line in Get-Content $file) {
        if ($line -match "^\s*$") { continue }
        $p = $line -split "=", 2
        if ($p.Count -eq 2) { $Global:TXT[$p[0]] = $p[1] }
    }
}
Load-Lang

function T($k) { return $Global:TXT[$k] }

# ============================
# FENETRE
# ============================
$form = New-Object System.Windows.Forms.Form
$form.Text = T "TITLE"
$form.Size = "700,400"
$form.StartPosition = "CenterScreen"
$form.BackColor = [Drawing.Color]::FromArgb(30,30,30)

# ============================
# LISTE ICONES
# ============================
$list = New-Object System.Windows.Forms.ListBox
$list.Location = "10,10"
$list.Size = "250,300"
$list.BackColor = [Drawing.Color]::FromArgb(40,40,40)
$list.ForeColor = "White"
$form.Controls.Add($list)

# MENU CONTEXTUEL (clic droit)
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$deleteItem = $menu.Items.Add((T "DELETE"))
$deleteItem.Add_Click({
    if ($list.SelectedItem -eq $null) { return }
    $file = Join-Path $OtherDir $list.SelectedItem
    if ([System.Windows.Forms.MessageBox]::Show((T "CONFIRM_DELETE"),"",4) -eq "Yes") {
        Remove-Item $file -Force
        Load-Icons
    }
})
$list.ContextMenuStrip = $menu

# ============================
# APERCU
# ============================
$preview = New-Object System.Windows.Forms.PictureBox
$preview.Location = "280,20"
$preview.Size = "128,128"
$preview.BackColor = [Drawing.Color]::FromArgb(50,50,50)
$preview.SizeMode = 'CenterImage'
$form.Controls.Add($preview)

# ============================
# BOUTONS
# ============================
$btnApply = New-Object System.Windows.Forms.Button
$btnApply.Text = T "BTN_APPLY"
$btnApply.BackColor  = [System.Drawing.ColorTranslator]::FromHtml("#7B3FFF")
$btnApply.ForeColor  = "White"
$btnApply.Location = "280,220"
$btnApply.Size = "90,30"
$form.Controls.Add($btnApply)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = T "BTN_ADD"
$btnAdd.BackColor    = [System.Drawing.ColorTranslator]::FromHtml("#7B3FFF")
$btnAdd.ForeColor    = "White"
$btnAdd.Location = "380,220"
$btnAdd.Size = "90,30"
$form.Controls.Add($btnAdd)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = T "BTN_REFRESH"
$btnRefresh.BackColor = [System.Drawing.ColorTranslator]::FromHtml("#7B3FFF")
$btnRefresh.ForeColor = "White"
$btnRefresh.Location = "480,220"
$btnRefresh.Size = "90,30"
$form.Controls.Add($btnRefresh)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = T "BTN_CLOSE"
$btnClose.BackColor  = [System.Drawing.ColorTranslator]::FromHtml("#7B3FFF")
$btnClose.ForeColor  = "White"
$btnClose.Location = "580,220"
$btnClose.Size = "90,30"
$form.Controls.Add($btnClose)

# ============================
# CHARGEMENT ICONES
# ============================
function Load-Icons {
    $list.Items.Clear()
    Get-ChildItem $OtherDir -Filter *.ico | ForEach-Object {
        $list.Items.Add($_.Name)
    }
}
Load-Icons

$list.Add_SelectedIndexChanged({
    if ($list.SelectedItem) {
        $path = Join-Path $OtherDir $list.SelectedItem
        $preview.Image = [Drawing.Image]::FromFile($path)
    }
})

# ============================
# APPLY
# ============================
$btnApply.Add_Click({
    if ($list.SelectedItem -eq $null) { return }
    Copy-Item (Join-Path $OtherDir $list.SelectedItem) $ActiveIcon -Force
    [System.Windows.Forms.MessageBox]::Show("Icon applied.")
})

# ============================
# ADD (ouvre le dossier)
# ============================
$btnAdd.Add_Click({
    Start-Process explorer.exe $OtherDir
})

# ============================
# REFRESH
# ============================
$btnRefresh.Add_Click({ Load-Icons })

# ============================
# CLOSE
# ============================
$btnClose.Add_Click({ $form.Close() })

[System.Windows.Forms.Application]::Run($form)