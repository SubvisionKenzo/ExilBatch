Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Dossier des langues
$LangFolder = Join-Path $PSScriptRoot "lang"
$OtherFolder = Join-Path $LangFolder "other"

if (-not (Test-Path $LangFolder)) {
    [System.Windows.Forms.MessageBox]::Show("Le dossier 'lang' est introuvable.","Erreur")
    exit
}

if (-not (Test-Path $OtherFolder)) {
    New-Item -ItemType Directory -Path $OtherFolder | Out-Null
}

# R�cup�re les fichiers de langue (ex: FR-FR.txt, EN-EN.txt)
$langFiles = Get-ChildItem -Path $LangFolder -File -Filter "*.txt"

if ($langFiles.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("ERROR features : 'lang'.","Info")
    exit
}

# Cr�ation de la fen�tre
$form = New-Object System.Windows.Forms.Form
$form.Text = "Config lang"
$form.Size = New-Object System.Drawing.Size(420,220)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(15,23,42) # fond sombre
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false

# Label
$label = New-Object System.Windows.Forms.Label
$label.Text = "Select language :"
$label.ForeColor = [System.Drawing.Color]::FromArgb(248,250,252)
$label.Font = New-Object System.Drawing.Font("Segoe UI",12,[System.Drawing.FontStyle]::Bold)
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20,20)
$form.Controls.Add($label)

# ComboBox
$combo = New-Object System.Windows.Forms.ComboBox
$combo.DropDownStyle = "DropDownList"
$combo.Width = 360
$combo.Location = New-Object System.Drawing.Point(20,60)
$combo.BackColor = [System.Drawing.Color]::FromArgb(15,23,42)
$combo.ForeColor = [System.Drawing.Color]::FromArgb(248,250,252)
$combo.Font = New-Object System.Drawing.Font("Segoe UI",10)

# Ajout des fichiers dans la liste
foreach ($file in $langFiles) {
    $combo.Items.Add($file.Name)
}
$combo.SelectedIndex = 0
$form.Controls.Add($combo)

# Bouton Valider
$btnOk = New-Object System.Windows.Forms.Button
$btnOk.Text = "Ok"
$btnOk.Width = 120
$btnOk.Height = 32
$btnOk.Location = New-Object System.Drawing.Point(80,120)
$btnOk.BackColor = [System.Drawing.Color]::FromArgb(34,197,94) # vert n�on
$btnOk.ForeColor = [System.Drawing.Color]::White
$btnOk.FlatStyle = "Flat"
$btnOk.Add_Click({
    $form.Tag = "OK"
    $form.Close()
})
$form.Controls.Add($btnOk)

# Bouton Annuler
$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = "Cancel"
$btnCancel.Width = 120
$btnCancel.Height = 32
$btnCancel.Location = New-Object System.Drawing.Point(220,120)
$btnCancel.BackColor = [System.Drawing.Color]::FromArgb(148,163,184)
$btnCancel.ForeColor = [System.Drawing.Color]::White
$btnCancel.FlatStyle = "Flat"
$btnCancel.Add_Click({
    $form.Tag = "CANCEL"
    $form.Close()
})
$form.Controls.Add($btnCancel)

# Affiche la fen�tre
[void]$form.ShowDialog()

if ($form.Tag -ne "OK") {
    exit
}

$selectedFileName = $combo.SelectedItem
$selectedFile = $langFiles | Where-Object { $_.Name -eq $selectedFileName }

if (-not $selectedFile) {
    [System.Windows.Forms.MessageBox]::Show("ERROR - file not found","Error")
    exit
}

# D�place tous les autres fichiers dans 'other'
foreach ($file in $langFiles) {
    if ($file.FullName -ne $selectedFile.FullName) {
        $dest = Join-Path $OtherFolder $file.Name
        Move-Item -Path $file.FullName -Destination $dest -Force
    }
}

[System.Windows.Forms.MessageBox]::Show("Lang set to : $($selectedFile.Name)`nOther lang  moved to 'other'.","Config")