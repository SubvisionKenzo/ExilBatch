@echo off
echo Add-Type -AssemblyName System.Windows.Forms > bin.ps1
echo Add-Type -AssemblyName System.Drawing >> bin.ps1
echo $notif = New-Object System.Windows.Forms.NotifyIcon >> bin.ps1
echo $notif.Icon = [System.Drawing.SystemIcons]::Information >> bin.ps1
echo $notif.BalloonTipTitle = "%1" >> bin.ps1
echo $notif.BalloonTipText = "%2 %3 %4" >> bin.ps1
echo $notif.Visible = $true >> bin.ps1
echo $notif.ShowBalloonTip(3000) >> bin.ps1
echo Start-Sleep -Seconds 5 >> bin.ps1
PowerShell -ExecutionPolicy Bypass -File "bin.ps1" /wait
exit