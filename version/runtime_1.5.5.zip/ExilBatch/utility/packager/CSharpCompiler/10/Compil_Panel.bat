@echo off
cd /d "%~dp0"
:: Varriable !
set "name=Compilepanel_menu"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min Compil_Panel.bat
exit
:execut
del %hide%.txt
:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul