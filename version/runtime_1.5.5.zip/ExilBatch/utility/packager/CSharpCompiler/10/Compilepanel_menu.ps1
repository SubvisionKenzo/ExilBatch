Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================
# FENÊTRE PRINCIPALE
# ============================

$form = New-Object System.Windows.Forms.Form
$form.Text = "ECB Compiler GUI Windows 10"
$form.Size = New-Object Drawing.Size(700, 350)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(25,25,25)   # Mode sombre

# ============================
# BANDE LATÉRALE VIOLETTE
# ============================

$side = New-Object System.Windows.Forms.Panel
$side.Width = 160
$side.Dock = "Left"
$side.BackColor = [Drawing.Color]::FromArgb(120,0,200)   # Violet moderne
$form.Controls.Add($side)

$lblSide = New-Object System.Windows.Forms.Label
$lblSide.Text = "ECB Compiler"
$lblSide.ForeColor = "White"
$lblSide.Font = New-Object Drawing.Font("Segoe UI", 14, [Drawing.FontStyle]::Bold)
$lblSide.AutoSize = $true
$lblSide.Location = "20,20"
$side.Controls.Add($lblSide)

# ============================
# CHAMP : CHEMIN DU SCRIPT
# ============================

$lblScript = New-Object System.Windows.Forms.Label
$lblScript.Text = "Script (.ps1 / .bat) :"
$lblScript.ForeColor = "White"
$lblScript.Font = New-Object Drawing.Font("Segoe UI", 10)
$lblScript.Location = "180,30"
$lblScript.AutoSize = $true
$form.Controls.Add($lblScript)

$txtScript = New-Object System.Windows.Forms.TextBox
$txtScript.Size = "350,25"
$txtScript.Location = "180,55"
$txtScript.BackColor = [Drawing.Color]::FromArgb(40,40,40)
$txtScript.ForeColor = "White"
$txtScript.BorderStyle = "FixedSingle"
$form.Controls.Add($txtScript)

$btnBrowseScript = New-Object System.Windows.Forms.Button
$btnBrowseScript.Text = "Parcourir"
$btnBrowseScript.Size = "90,25"
$btnBrowseScript.Location = "540,55"
$btnBrowseScript.BackColor = [Drawing.Color]::FromArgb(60,60,60)
$btnBrowseScript.ForeColor = "White"
$form.Controls.Add($btnBrowseScript)

$btnBrowseScript.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Scripts (*.ps1;*.bat)|*.ps1;*.bat"
    if ($dialog.ShowDialog() -eq "OK") {
        $txtScript.Text = $dialog.FileName
    }
})

# ============================
# CHAMP : NOM DE L’EXE
# ============================

$lblOutput = New-Object System.Windows.Forms.Label
$lblOutput.Text = "File EXE :"
$lblOutput.ForeColor = "White"
$lblOutput.Font = New-Object Drawing.Font("Segoe UI", 10)
$lblOutput.Location = "180,110"
$lblOutput.AutoSize = $true
$form.Controls.Add($lblOutput)

$txtOutput = New-Object System.Windows.Forms.TextBox
$txtOutput.Size = "350,25"
$txtOutput.Location = "180,135"
$txtOutput.BackColor = [Drawing.Color]::FromArgb(40,40,40)
$txtOutput.ForeColor = "White"
$txtOutput.BorderStyle = "FixedSingle"
$form.Controls.Add($txtOutput)

# ============================
# BOUTON COMPILER
# ============================

$btnCompile = New-Object System.Windows.Forms.Button
$btnCompile.Text = "Compiler"
$btnCompile.Size = "120,35"
$btnCompile.Location = "180,200"
$btnCompile.BackColor = [Drawing.Color]::FromArgb(120,0,200)
$btnCompile.ForeColor = "White"
$btnCompile.Font = New-Object Drawing.Font("Segoe UI", 11, [Drawing.FontStyle]::Bold)
$form.Controls.Add($btnCompile)

# ============================
# ACTION : COMPILER
# ============================

$btnCompile.Add_Click({

    $script = $txtScript.Text
    $output = $txtOutput.Text

    if ($script -eq "" -or $output -eq "") {
        [System.Windows.Forms.MessageBox]::Show("","Error")
        return
    }

    # Ajout automatique de .exe
    if ($output -notmatch "\.exe$") {
        $output = "$output.exe"
    }

    if (-not (Test-Path $script)) {
        [System.Windows.Forms.MessageBox]::Show("","Error")
        return
    }

    # Lancement du compilateur
    Start-Process -FilePath "compiler.bat" -ArgumentList "`"$output`" `"$script`""

    [System.Windows.Forms.MessageBox]::Show("Stat 100 %","ECB Compiler")
})

# ============================
# LANCEMENT
# ============================

$form.ShowDialog()
