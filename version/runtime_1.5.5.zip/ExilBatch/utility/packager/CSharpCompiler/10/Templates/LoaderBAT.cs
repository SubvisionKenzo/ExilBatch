using System;
using System.Diagnostics;
using System.IO;

class Program
{
    static void Main()
    {
        string script = "__SCRIPT_CONTENT__";

        string tempFile = Path.Combine(Path.GetTempPath(),
                                       Guid.NewGuid().ToString() + ".bat");

        File.WriteAllText(tempFile, script);

        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = "cmd.exe";
        psi.Arguments = "/c \"" + tempFile + "\"";
        psi.UseShellExecute = false;

        Process.Start(psi);
    }
}
