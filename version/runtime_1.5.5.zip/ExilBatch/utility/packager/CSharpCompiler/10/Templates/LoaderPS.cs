using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        string script = "__SCRIPT_CONTENT__";

        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = "powershell.exe";
        psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -Command \""
                        + script.Replace("\"", "`\"") + "\"";
        psi.UseShellExecute = false;

        Process.Start(psi);
    }
}
