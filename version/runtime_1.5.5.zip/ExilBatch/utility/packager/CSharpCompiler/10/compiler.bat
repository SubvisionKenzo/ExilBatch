@echo off
title Compiling...
set "extnamefile=.ps1 ou .bat"

cd /d "%~dp0"

if "%~1"=="" (
    echo Use :
    powershell "Write-Host 'compiler.bat "Output\file.exe" "script.ps1"' -ForegroundColor Red"
    pause
    exit /b
)

if "%~2"=="" (
    powershell "Write-Host 'Error : (%extnamefile%)' -ForegroundColor Red"
    pause
    exit /b
)

set "OUTPUT=%~1"
set "SOURCE=%~2"

if not exist "%SOURCE%" (
    echo The target file : "%SOURCE%" not exist.
    pause
    exit /b
)

echo Lecture du fichier source...
setlocal enabledelayedexpansion
set "SCRIPT_CONTENT="

for /f "usebackq delims=" %%A in ("%SOURCE%") do (
    set "LINE=%%A"
    set "LINE=%%A"
    set "LINE=!LINE:"=\"!"
    set "SCRIPT_CONTENT=!SCRIPT_CONTENT!!LINE!`n"

)

echo OK.

echo Detection du template...
set "EXT=%SOURCE:~-4%"

:: Template ici !
if /i "%EXT%"==".ps1" set "TEMPLATE=Templates\LoaderPS.cs"
if /i "%EXT%"==".bat" set "TEMPLATE=Templates\LoaderBAT.cs"

if not exist "%TEMPLATE%" (
    echo Template no found : %TEMPLATE%
    pause
    exit /b
)

echo Injection du script dans le template...
set "FINAL_CS=%TEMP%\loader_temp.cs"

(
    for /f "usebackq delims=" %%A in ("%TEMPLATE%") do (
        set "LINE=%%A"
        set "LINE=!LINE:__SCRIPT_CONTENT__=%SCRIPT_CONTENT%!"
        echo !LINE!
    )
) > "%FINAL_CS%"

echo Compilation...
Tools\csc.exe /target:exe /out:"%OUTPUT%" "%FINAL_CS%"

if %errorlevel%==0 (
    echo Compilation successful !
) else (
    echo Compilation error.
)
start CSharpCompiler
exit > nul
