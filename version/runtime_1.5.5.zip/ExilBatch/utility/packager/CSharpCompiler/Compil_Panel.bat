@echo off

rem --- R�cup�ration du nom et du build ---
for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v ProductName') do set OSNAME=%%b
for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuild') do set BUILD=%%b

echo OS d�tect� : %OSNAME%
echo Build : %BUILD%

rem --- Windows 8.1 ---
echo %OSNAME% | findstr /i "8.1" >nul && goto WIN81

rem --- Windows 11 (build >= 22000) ---
if %BUILD% GEQ 22000 goto WIN11

rem --- Windows 10 (build < 22000) ---
echo %OSNAME% | findstr /i "10" >nul && goto WIN10
goto END

:WIN81
cd 8.1
exit
:: La version comport trop de bug !
start Compil_Panel.bat
goto END

:WIN10
cd 10
start Compil_Panel.bat
goto END

:WIN11
cd 11
start Compil_Panel.bat
goto END

:END
exit
