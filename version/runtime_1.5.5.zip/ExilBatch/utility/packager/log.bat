@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "log.ps1" > nul
exit > nul