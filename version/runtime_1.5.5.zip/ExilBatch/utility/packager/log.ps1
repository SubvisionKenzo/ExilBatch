$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $ScriptDir "preview.log"
if (-not (Test-Path $LogFile)) {
    [System.Media.SystemSounds]::Hand.Play()
    [System.Windows.Forms.MessageBox]::Show(
        "fil : preview.log not found :`n$ScriptDir",
        "Error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
    exit
}
# Charge les biblioth�ques Windows Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$LogContent = Get-Content $LogFile -Raw
[System.Media.SystemSounds]::Hand.Play()
$form = New-Object System.Windows.Forms.Form
$form.Text = "Logs consol"
$form.Size = New-Object System.Drawing.Size(600,400)
$form.StartPosition = "CenterScreen"
$form.TopMost = $true
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Multiline = $true
$textBox.ReadOnly = $true
$textBox.ScrollBars = "Vertical"
$textBox.Dock = "Fill"
$textBox.Font = New-Object System.Drawing.Font("Consolas", 10)
$textBox.Text = $LogContent
$form.Controls.Add($textBox)
$okButton = New-Object System.Windows.Forms.Button
$okButton.Text = "OK"
$okButton.Width = 80
$okButton.Height = 30
$okButton.Top = $form.ClientSize.Height - 40
$okButton.Left = ($form.ClientSize.Width - $okButton.Width) / 2
$okButton.Anchor = "Bottom"
$okButton.Add_Click({ $form.Close() })
$form.Controls.Add($okButton)
$form.ShowDialog()
