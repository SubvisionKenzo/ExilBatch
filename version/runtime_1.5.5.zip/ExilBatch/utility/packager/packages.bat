@echo off
cd /d "%~dp0"
set "ext=.ecb"
setlocal enabledelayedexpansion

cd ..

rem === Dossier des fichiers de langue ===
set "langFolder=lang"

rem === D�tection automatique du fichier de langue ===
for %%F in ("%langFolder%\*.txt" "%langFolder%\*.lang" "%langFolder%\*.config" "%langFolder%\*.cfg") do (
    set "langFile=%%F"
    goto :found
)
exit /b

:found
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%langFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem rien
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /b "# ;" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
cd packager

for %%l in (%*) do (
	set "arg=%%l"
)
set "project=%arg%"
if "%project%"=="" (
    echo %time% - %Error% "%arg%" >> preview.log
    start log.bat
    exit /b
)
if not exist "%project%" (
    echo %time% - %Notfound% : "%arg%" >> preview.log
    start log.bat
    exit /b
)
REM === Cr�ation du dossier temp ===
set "tempdir=%~dp0temp"
if exist "%tempdir%" rd /s /q "%tempdir%"
mkdir "%tempdir%"

REM === Copie du projet dans temp ===
xcopy "%project%\*" "%tempdir%\" /E /I /Y >nul
for %%f in ("%tempdir%\*") do (
    set "firstfile=%%~nxf"
    goto found
)
:found
cd ..
REM === V�rification de 7zip ===
if not exist "7z.exe" (
    exit /b
)
REM === Cr�ation du fichier ECB (zip) ===
"7z.exe" a -tzip "%firstfile%%ext%" "%tempdir%\*"
move %firstfile%%ext% %arg%
cd packager
echo.
echo ============================================
echo   Fils created : %output%
echo ============================================
echo.
REM === Nettoyage ===
rd /s /q "%tempdir%"
exit