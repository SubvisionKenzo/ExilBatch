param(
    [Parameter(Mandatory=$true)]
    [string]$DIR,

    [Parameter(Mandatory=$true)]
    [string]$TARGET
)

Write-Host "DIR = $DIR"
Write-Host "TARGET = $TARGET"

# V�rifier dossier
if (-not (Test-Path $DIR)) {
    Write-Host "[ERREUR] Le dossier '$DIR' n'existe pas."
    exit 1
}

# Aller dans le dossier
Set-Location $DIR

# V�rifier fichier
if (-not (Test-Path $TARGET)) {
    Write-Host "[ERREUR] Le fichier '$TARGET' n'existe pas dans '$DIR'."
    exit 1
}

# D�tecter extension
$ext = [System.IO.Path]::GetExtension($TARGET).ToLower()

switch ($ext) {
    ".bat" {
        Write-Host "Execution du fichier batch : $TARGET"
        Start-Process "cmd.exe" "/c `"$TARGET`""
    }

    ".ps1" {
        Write-Host "Execution du script PowerShell : $TARGET"
        Start-Process "powershell.exe" "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$TARGET`""
    }

    default {
        Write-Host "[ERROR] Ext : $ext"
        Write-Host "Extensions accept�es : .bat et .ps1"
        exit 1
    }
}