@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
for %%l in (%*) do (
	set "arg=%%l"
)

if /i %arg% EQU 1 goto cleanrep

set "SettingFolder=Panel"
set "directoryauto=%~dp0"

:: =-----------------------------------=
:: Language name : Ecrion
:: =-----------------------------------=

rem === Détection automatique du fichier settings ===
for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found
)
exit /b

:found
echo loading : %settingsFile%
echo.
rem === Lecture du fichier et création des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%settingsFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem skip
    ) else (

        rem --- Ignore commentaires commençant par # ou ; ---
        echo !ligne! | findstr /r "^[#;]" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)
echo.
if exist log.xllst goto run_runtime
echo > log.xllst
cmd /c start /min shell.bat %1
exit
:run_runtime

del log.xllst
set "rep=%~dp0"
if exist rep\*.json goto rescheck
set "ext=.txt"
:: Random ID
set "charset=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
set "key="
:: Générer 32 caractères
for /L %%i in (1,1,32) do (
    set /a index=!random! %% 62
    for %%j in (!index!) do set "char=!charset:~%%j,1!"
    set "key=!key!!char!"
)
:: Insérer des tirets tous les 5 caractères (ex: XXXXX-XXXXX-...)
set "formatted="
set /a count=0
for %%i in (0 5 10 15 20 25 30) do (
    set "part=!key:~%%i,5!"
    if "!formatted!"=="" (
        set "formatted=!part!"
    ) else (
        set "formatted=!formatted!-!part!"
    )
)
:: End random ID
xcopy %1 "%rep%\fils" /Y /Q
dir /b /a:-d "%cd%\fils\" >> !formatted!%ext%
for /f "delims=" %%a in (%cd%\!formatted!%ext%) do set lib=%%a
del !formatted!%ext%
if /i "%~x1"==".ecb" (
    echo Run Ecrion code !
    goto runecb
) else (
    echo normal script
)
set "exarg=%lib%"
for /f "delims=" %%z in (fils\%exarg%) do (
	set /a "exarg=%%z"
    %%z
)
del fils\%lib%
:return0
exit > nul

:runecb
cd fils
REN %lib% %lib%.zip
cd ..
if exist %lib% rmdir /s /q %lib%
7z.exe x "fils\%lib%.zip" -o"%lib%"
del fils\%lib%.zip
dir /b /a:-d "%cd%\%lib%\" >> !formatted!%ext%
for /f "delims=" %%z in (%cd%\!formatted!%ext%) do set name=%%z
del !formatted!%ext%
cd %lib%

:: -----------------------------------------------------------------------------------------

if "%PortableRuntimes%"=="0" goto skipenvruntime

:: ---------------------------------------------------------
:: Trouver le premier fichier du dossier
:: ---------------------------------------------------------

set "SOURCE_DIR=%cd%"
set "FILE="
set "EXT="

for %%F in ("%SOURCE_DIR%\*.*") do (
    set "FILE=%%~nxF"
    set "EXT=%%~xF"
    goto :FOUND_FILE
)

echo not files found.
call "%directoryauto%\cleanup.bat"
goto END

:FOUND_FILE
:: Enlever le point de l’extension
set "EXT=%EXT:~1%"

echo %FILE%
echo %EXT%

:: ---------------------------------------------------------
:: Blacklist
:: ---------------------------------------------------------

set "BLACKLIST_FILE=%directoryauto%\blacklist.txt"

if not exist "%BLACKLIST_FILE%" (
    echo blacklist.txt introuvable -> skip
    goto skipextenvruntime
)

set "FOUND=1"

for /f "usebackq tokens=*" %%A in ("%BLACKLIST_FILE%") do (
    if /i "%%A"=="%EXT%" (
        set "FOUND=0"
    )
)

:: Si extension NON présente dans la blacklist → skip
if "%FOUND%"=="0" (
    goto skipextenvruntime
)

echo.

:: ---------------------------------------------------------
:: Vérifier si un runtime existe
:: ---------------------------------------------------------

set "RUNTIME_DIR=%SOURCE_DIR%\..\assets\$~Envruntimes"

if exist "%RUNTIME_DIR%\%EXT%" (
    echo Runtime found : %EXT%
    call "%RUNTIME_DIR%\%EXT%.bat" "%FILE%"
    goto END
)

:: ---------------------------------------------------------
:: Aucun runtime -> lancer exterror.ps1
:: ---------------------------------------------------------

powershell -ExecutionPolicy Bypass -File "%directoryauto%\exterror.ps1" "%FILE%" "%EXT%"
exit /b

:: ---------------------------------------------------------
:: Skip runtime (extension non blacklistée)
:: ---------------------------------------------------------
:skipextenvruntime
goto END
exit /b
:END
:skipenvruntime

:: -----------------------------------------------------------------------------------------

:: ============================
:: Détection automatique JSON
:: ============================

:: Chemin complet du fichier extrait
set "filepath=%cd%\%name%"

:: Récupérer l’extension en minuscule
set "ext=%name:~-5%"
set "ext2=%name:~-4%"

:: Vérifier si c’est un JSON
if /i "%ext%"==".json" goto launchJSON
if /i "%ext2%"==".json" goto launchJSON

goto continueNormal
exit /b
:launchJSON
echo.
echo [ECB] - JSON : %name%
echo.

cd ..
call gui.bat "%filepath%"
goto return0

:continueNormal

set "cert="
for /r "%~dp0" %%F in (*.pfx) do (
    set "cert=%%F"
    goto foundcert
)

:foundcert
if defined cert (
    echo found : !cert!
    goto uacyes
)

goto uaccheck
:uacyes
if "%admin%"=="1" goto runasadmin

:: New mode
set "search=set_ecb.runtime"
set "found=0"

for /f "usebackq delims=" %%B in ("%name%") do (
    set "line=%%B"
    echo !line! ^| findstr /i /c:"%search%" >nul
    if not errorlevel 1 (
        set "found=1"
        set "cd_var=%cd%"
        goto found_it
    )
)

:found_it
if "%found%"=="1" (
    goto use_runtime
) else (
    goto run_normalMode
)

:run_normalMode
:: End new mode
start %name%
timeout 1 > nul
cd C:\Users\%username%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
if exist autocleanup.bat goto return1
echo pushd %directoryauto% >> autocleanup.bat
echo start cleanup.bat >> autocleanup.bat
echo popd >> autocleanup.bat
echo del autocleanup.bat >> autocleanup.bat
echo exit >> autocleanup.bat
:return1
exit > nul

goto return0
:cleanrep
start cleanup.bat
exit

:uacyesno
cd ..
pushd UAC
start UAC.bat
start uacdialogclear.bat %~dp0\%lib% UAC-Ecrion
timeout 1 > nul
PowerShell -ExecutionPolicy Bypass -File "uac.ps1" /wait
timeout 1 > nul
start uacdialogclear.bat
if exist x.txt goto prepcleanrep
cd ..
cd %lib%
goto uacyes
exit

:uaccheck
if "%uac%"=="1" goto uacyesno
goto uacyes
exit /b

:prepcleanrep
cd ..
goto cleanrep
exit /b

:runasadmin
powershell -Command "Start-Process '%name%' -Verb RunAs"
goto return1

:rescheck
exit /b

:use_runtime
for /f "delims=" %%r in (%cd_var%\%name%) do (
	set /a "exarg=%%r"
    %%r
)
exit /b