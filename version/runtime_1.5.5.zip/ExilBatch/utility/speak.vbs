' speak.vbs
' Module de voix
Option Explicit

Dim fso, base, langFolder, langFile, key, line, parts, voice

Set fso = CreateObject("Scripting.FileSystemObject")

' Argument = clé à lire
If WScript.Arguments.Count = 0 Then WScript.Quit
key = UCase(WScript.Arguments(0))

' Dossier du script
base = fso.GetParentFolderName(WScript.ScriptFullName)

' Dossier lang
langFolder = fso.BuildPath(base, "lang")

If Not fso.FolderExists(langFolder) Then
    WScript.Echo "Lang folder missing"
    WScript.Quit
End If

' Prendre le premier fichier .txt dans lang/
Dim file
For Each file In fso.GetFolder(langFolder).Files
    If LCase(fso.GetExtensionName(file.Name)) = "txt" Then
        langFile = file.Path
        Exit For
    End If
Next

If langFile = "" Then
    WScript.Echo "No language file found"
    WScript.Quit
End If

' Lire le fichier
Dim ts
Set ts = fso.OpenTextFile(langFile, 1)

Dim textToSpeak
textToSpeak = ""

Do Until ts.AtEndOfStream
    line = Trim(ts.ReadLine)
    If InStr(line, "=") > 0 Then
        parts = Split(line, "=")
        If UCase(parts(0)) = key Then
            textToSpeak = parts(1)
            Exit Do
        End If
    End If
Loop

ts.Close

If textToSpeak = "" Then
    WScript.Echo "Key not found: " & key
    WScript.Quit
End If

' Lire à voix haute
Set voice = CreateObject("SAPI.SpVoice")
voice.Speak textToSpeak
