@echo off
setlocal enabledelayedexpansion

REM === Aller dans T�l�chargements ===
cd "%USERPROFILE%\Downloads"

REM === Attendre 2 secondes ===
timeout /t 2 >nul

REM === V�rifier s'il y a un fichier temporaire de navigateur ===
set TEMP_FOUND=0
for %%T in (*.crdownload *.part *.tmp *.download) do (
    set TEMP_FOUND=1
)

REM === V�rifier s'il y a un fichier .ecb ===
set ECB_FOUND=0
for %%F in (*.ecb) do (
    set ECB_FOUND=1
    set ECBFILE=%%F
)

REM === Si aucun fichier temporaire ET aucun .ecb -> fermer ===
if %TEMP_FOUND%==0 if %ECB_FOUND%==0 (
    echo (ERROR)
    exit /b
)

REM === Si fichier temporaire -> attendre le .ecb ===
if %TEMP_FOUND%==1 (
    echo (GOOD)
)

:WAIT_ECB
for %%F in (*.ecb) do (
    set ECBFILE=%%F
    goto FOUND
)
timeout /t 1 >nul
goto WAIT_ECB

:FOUND
echo file found : %ECBFILE%

REM === 2. R�cup�rer le nom sans extension ===
set "ARG=%ECBFILE:.ecb=%"

REM === 3. Trouver le dossier d'origine du script ===
set "ORIGIN=%~dp0"
echo path : %ORIGIN%

REM === 4. Copier le fichier dans le dossier ext ===
if not exist "%ORIGIN%ext" mkdir "%ORIGIN%ext"
copy "%ECBFILE%" "%ORIGIN%ext" >nul

REM === 5. D�placer le fichier dans ext ===
move "%ECBFILE%" "%ORIGIN%ext" >nul

REM === 6. Aller dans ext et lancer le fichier ===
cd "%ORIGIN%ext"
echo Lancement du fichier %ECBFILE%...
start "" "%ECBFILE%"

REM === 7. Attendre que le fichier ne soit plus utilis� ===
:WAIT_UNLOCK
2>nul (
    >>"%ECBFILE%" echo test
) || (
    timeout /t 1 >nul
    goto WAIT_UNLOCK
)

REM === 8. Supprimer le fichier ===
del "%ECBFILE%"

REM === 9. Remonter de deux dossiers ===
cd "%ORIGIN%"
cd ..

REM === 10. Lire le NOTIF_TITLE dans le premier fichier du dossier lang ===
set "LANGDIR=lang"
for %%L in ("%LANGDIR%\*.txt") do (
    set LANGFILE=%%L
    goto GOT_LANG
)

:GOT_LANG
for /f "usebackq tokens=1,2 delims==" %%A in ("%LANGFILE%") do (
    if "%%A"=="NOTIF_TITLE" set NOTIF_TITLE=%%B
)

echo Notification : %NOTIF_TITLE%

REM === 11. Lancer notif.bat avec les arguments ===
notif.bat EcrionStore %ARG% %NOTIF_TITLE%