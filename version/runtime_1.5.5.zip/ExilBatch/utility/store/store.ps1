###############################################
# MISE A JOUR DU STORE (GitHub)
###############################################

$BasePath = Split-Path -Parent $MyInvocation.MyCommand.Definition

$remoteVersionUrl = "https://raw.githubusercontent.com/SubvisionKenzo/ExilBatch/main/store/version.json"
$remoteIndexUrl   = "https://raw.githubusercontent.com/SubvisionKenzo/ExilBatch/main/store/index.json"

$localVersionFile = Join-Path $BasePath "version.json"
$localIndexFile   = Join-Path $BasePath "index.json"

try {
    $remoteVersion = Invoke-WebRequest -Uri $remoteVersionUrl -UseBasicParsing -ErrorAction Stop
    $remoteVersionJson = $remoteVersion.Content | ConvertFrom-Json
}
catch {
    Write-Host "Impossible de vérifier les mises à jour GitHub."
}

if (Test-Path $localVersionFile) {
    try {
        $localVersionJson = Get-Content $localVersionFile -Raw | ConvertFrom-Json
    } catch {
        $localVersionJson = @{ version = "0.0.0" }
    }
} else {
    $localVersionJson = @{ version = "0.0.0" }
}

$mustDownload = $false

if (-not (Test-Path $localIndexFile)) { $mustDownload = $true }
else {
    try {
        $testJson = Get-Content $localIndexFile -Raw | ConvertFrom-Json
        if ($testJson -eq $null) { $mustDownload = $true }
    } catch {
        $mustDownload = $true
    }
}

if ($remoteVersionJson.version -ne $localVersionJson.version) { $mustDownload = $true }

if ($mustDownload) {
    Invoke-WebRequest -Uri $remoteIndexUrl -OutFile $localIndexFile -UseBasicParsing -ErrorAction Stop
    $remoteVersion.Content | Out-File $localVersionFile -Encoding utf8
}

###############################################
# LOADER
###############################################

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$loader = New-Object Windows.Forms.Form
$loader.Text = ""
$loader.Size = "300,300"
$loader.StartPosition = "CenterScreen"
$loader.FormBorderStyle = "None"
$loader.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)

$pathLoader = New-Object System.Drawing.Drawing2D.GraphicsPath
$pathLoader.AddArc(0,0,30,30,180,90)
$pathLoader.AddArc($loader.Width-30,0,30,30,270,90)
$pathLoader.AddArc($loader.Width-30,$loader.Height-30,30,30,0,90)
$pathLoader.AddArc(0,$loader.Height-30,30,30,90,90)
$pathLoader.CloseFigure()
$loader.Region = New-Object System.Drawing.Region($pathLoader)

$storeImg = Join-Path $BasePath "store.png"
if (Test-Path $storeImg) {
    $pic = New-Object Windows.Forms.PictureBox
    $pic.Image = [System.Drawing.Image]::FromFile($storeImg)
    $pic.SizeMode = "Zoom"
    $pic.Dock = "Fill"
    $loader.Controls.Add($pic)
}

$loader.Show()
$loader.Refresh()
Start-Sleep -Seconds 2

###############################################
# LECTURE JSON
###############################################

$json = Get-Content $localIndexFile -Raw | ConvertFrom-Json
$sections = $json.sections
$global:CurrentSectionKey = "apps"

###############################################
# FENÊTRE PRINCIPALE
###############################################

$form = New-Object Windows.Forms.Form
$form.Text = "ECB Store"
$form.Size = "1000,700"
$form.StartPosition = "CenterScreen"
$form.BackColor = "#1a1a1a"
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

###############################################
# BARRE DE RECHERCHE (EN HAUT À DROITE, LÉGÈREMENT PLUS À GAUCHE)
###############################################

$searchPanel = New-Object Windows.Forms.Panel
$searchPanel.Size = "350,40"
$searchPanel.Location = "600,20"
$searchPanel.BackColor = "White"
$form.Controls.Add($searchPanel)

$pathSearch = New-Object System.Drawing.Drawing2D.GraphicsPath
$pathSearch.AddArc(0,0,20,20,180,90)
$pathSearch.AddArc(330,0,20,20,270,90)
$pathSearch.AddArc(330,20,20,20,0,90)
$pathSearch.AddArc(0,20,20,20,90,90)
$pathSearch.CloseFigure()
$searchPanel.Region = New-Object System.Drawing.Region($pathSearch)

$searchIconPath = Join-Path $BasePath "loupe.png"
if (Test-Path $searchIconPath) {
    $searchIcon = New-Object Windows.Forms.PictureBox
    $searchIcon.Image = [System.Drawing.Image]::FromFile($searchIconPath)
    $searchIcon.SizeMode = "Zoom"
    $searchIcon.Size = "24,24"
    $searchIcon.Location = "10,8"
    $searchPanel.Controls.Add($searchIcon)
}

$searchBox = New-Object Windows.Forms.TextBox
$searchBox.Font = New-Object System.Drawing.Font("Segoe UI", 12)
$searchBox.ForeColor = "Black"
$searchBox.BackColor = "White"
$searchBox.BorderStyle = "None"
$searchBox.Size = "280,30"
$searchBox.Location = "45,8"
$searchPanel.Controls.Add($searchBox)

###############################################
# TABS APPS / ISOS
###############################################

function New-FluentTab {
    param($Text,$X,$Y)

    $tabPanel = New-Object Windows.Forms.Panel
    $tabPanel.Size = "160,36"
    $tabPanel.Location = "$X,$Y"
    $tabPanel.BackColor = "#2d2d2d"

    $pathTab = New-Object System.Drawing.Drawing2D.GraphicsPath
    $pathTab.AddArc(0,0,20,20,180,90)
    $pathTab.AddArc(140,0,20,20,270,90)
    $pathTab.AddArc(140,16,20,20,0,90)
    $pathTab.AddArc(0,16,20,20,90,90)
    $pathTab.CloseFigure()
    $tabPanel.Region = New-Object System.Drawing.Region($pathTab)

    $btn = New-Object Windows.Forms.Button
    $btn.Text = $Text
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btn.FlatStyle = "Flat"
    $btn.FlatAppearance.BorderSize = 0
    $btn.BackColor = "Transparent"
    $btn.ForeColor = "LightGray"
    $btn.Size = "160,36"

    $tabPanel.Controls.Add($btn)
    return @{ Panel=$tabPanel; Button=$btn }
}

$tabAppsObj = New-FluentTab "Apps + Extensions" 600 70
$tabIsosObj = New-FluentTab "ISOs (OS + WIM)" 780 70

$form.Controls.Add($tabAppsObj.Panel)
$form.Controls.Add($tabIsosObj.Panel)

$SelectedColor   = "#8a2be2"
$UnselectedColor = "#2d2d2d"

###############################################
# COLONNE GAUCHE (PLUS CENTRÉE ET PLUS HAUTE)
###############################################

$appZone = New-Object Windows.Forms.Panel
$appZone.Location = "80,110"
$appZone.Size = "400,500"
$appZone.BackColor = "#111111"
$form.Controls.Add($appZone)

$pathZone = New-Object System.Drawing.Drawing2D.GraphicsPath
$pathZone.AddArc(0,0,20,20,180,90)
$pathZone.AddArc($appZone.Width-20,0,20,20,270,90)
$pathZone.AddArc($appZone.Width-20,$appZone.Height-20,20,20,0,90)
$pathZone.AddArc(0,$appZone.Height-20,20,20,90,90)
$pathZone.CloseFigure()
$appZone.Region = New-Object System.Drawing.Region($pathZone)

$appZone.Paint.Add({
    param($sender,$e)
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(180,120,255),2)
    $e.Graphics.DrawRectangle($pen,0,0,$appZone.Width-2,$appZone.Height-2)
})

$panel = New-Object Windows.Forms.FlowLayoutPanel
$panel.Dock = "Fill"
$panel.AutoScroll = $true
$panel.WrapContents = $false
$panel.FlowDirection = "TopDown"
$panel.BackColor = "#111111"
$appZone.Controls.Add($panel)

###############################################
# CHARGEMENT DES SECTIONS
###############################################

$global:AppBoxes = @()

function Load-Section {
    param($sectionKey)

    $panel.Controls.Clear()
    $global:AppBoxes = @()

    $section = $sections.$sectionKey
    if (-not $section) { return }

    foreach ($appKey in $section.items.PSObject.Properties.Name) {

        $app = $section.items.$appKey

        $box = New-Object Windows.Forms.Panel
        $box.Size = "360,110"
        $box.BackColor = "#2d2d2d"
        $box.Margin = "10,10,10,10"
        $box.Tag = $app.Name

        $pathBox = New-Object System.Drawing.Drawing2D.GraphicsPath
        $pathBox.AddArc(0,0,20,20,180,90)
        $pathBox.AddArc($box.Width-20,0,20,20,270,90)
        $pathBox.AddArc($box.Width-20,$box.Height-20,20,20,0,90)
        $pathBox.AddArc(0,$box.Height-20,20,20,90,90)
        $pathBox.CloseFigure()
        $box.Region = New-Object System.Drawing.Region($pathBox)

        if ($sectionKey -eq "apps") {
            $iconPath = Join-Path $BasePath "file.png"
        } else {
            $iconPath = Join-Path $BasePath "iso.png"
        }

        if (Test-Path $iconPath) {
            $iconPic = New-Object Windows.Forms.PictureBox
            $iconPic.Image = [System.Drawing.Image]::FromFile($iconPath)
            $iconPic.SizeMode = "Zoom"
            $iconPic.Location = "10,10"
            $iconPic.Size = "64,64"
            $box.Controls.Add($iconPic)
        }

        $titleLbl = New-Object Windows.Forms.Label
        $titleLbl.Text = $app.Name
        $titleLbl.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
        $titleLbl.ForeColor = "White"
        $titleLbl.Location = "85,10"
        $titleLbl.AutoSize = $true
        $box.Controls.Add($titleLbl)

        $desc = New-Object Windows.Forms.Label
        $desc.Text = $app.Desc
        $desc.Font = New-Object System.Drawing.Font("Segoe UI", 10)
        $desc.ForeColor = "LightGray"
        $desc.Location = "85,35"
        $desc.AutoSize = $true
        $box.Controls.Add($desc)

        $btn = New-Object Windows.Forms.Button
        $btn.Text = $app.Button.Title
        $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
        $btn.BackColor = "#8a2be2"
        $btn.ForeColor = "White"
        $btn.FlatStyle = "Flat"
        $btn.Size = "100,30"
        $btn.Location = "240,65"
        $btn.Tag = $app.Button.Action

        if ([string]::IsNullOrWhiteSpace($btn.Tag)) {
            $btn.Enabled = $false
            $btn.BackColor = "#444444"
            $btn.Text = "Indisponible"
        }

        $btn.Add_Click({
            $action = $this.Tag
            if ([string]::IsNullOrWhiteSpace($action)) {
                [System.Windows.Forms.MessageBox]::Show("Aucun lien disponible.","Erreur")
                return
            }
            Start-Process $action
        })

        $box.Controls.Add($btn)
        $panel.Controls.Add($box)
        $global:AppBoxes += $box
    }
}

Load-Section "apps"

###############################################
# TABS ACTIONS
###############################################

$tabAppsObj.Panel.BackColor = $SelectedColor
$tabAppsObj.Button.ForeColor = "White"

$tabAppsObj.Button.Add_Click({
    $global:CurrentSectionKey = "apps"
    $tabAppsObj.Panel.BackColor = $SelectedColor
    $tabAppsObj.Button.ForeColor = "White"
    $tabIsosObj.Panel.BackColor = $UnselectedColor
    $tabIsosObj.Button.ForeColor = "LightGray"
    Load-Section "apps"
})

$tabIsosObj.Button.Add_Click({
    $global:CurrentSectionKey = "isos"
    $tabIsosObj.Panel.BackColor = $SelectedColor
    $tabIsosObj.Button.ForeColor = "White"
    $tabAppsObj.Panel.BackColor = $UnselectedColor
    $tabAppsObj.Button.ForeColor = "LightGray"
    Load-Section "isos"
})

###############################################
# RECHERCHE
###############################################

$searchBox.Add_TextChanged({
    $query = $searchBox.Text.ToLower()
    foreach ($b in $global:AppBoxes) {
        $b.Visible = $b.Tag.ToLower().Contains($query)
    }
})

###############################################
# FILIGRANE
###############################################

$watermark = New-Object Windows.Forms.Label
$watermark.Text = "ExilBatch Store Build 1.5.3.26preview"
$watermark.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$watermark.ForeColor = [System.Drawing.Color]::FromArgb(120,120,120)
$watermark.AutoSize = $true
$watermark.Location = New-Object System.Drawing.Point(10,$form.ClientSize.Height-25)
$form.Controls.Add($watermark)

$form.Add_Resize({
    $appZone.Height = $form.Height - 160
    $watermark.Location = New-Object System.Drawing.Point(10,$form.ClientSize.Height-25)
})

###############################################
# LANCEMENT
###############################################

$loader.Close()
$form.ShowDialog()