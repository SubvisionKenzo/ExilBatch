@echo off
cd /d "%~dp0"
del online_version.txt
cd ..\..
set "output=%cd%"
cd "%output%\utility\update"
set "onlineversion=online_version"
set "localversion=runtime_version"
set "name=update"
set "urldir=https://raw.githubusercontent.com/SubvisionKenzo/ExilBatch/main/version/"
setlocal enabledelayedexpansion

cd ..
set "SettingFolder=Panel"

rem === D�tection automatique du fichier settings ===
for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found
)
exit /b

:found
echo set %settingsFile%
echo.

rem === Lecture du fichier et cr�ation des variables ===
for /f "usebackq tokens=* delims=" %%A in ("%settingsFile%") do (
    set "ligne=%%A"

    rem --- Ignore lignes vides ---
    if "!ligne!"=="" (
        rem skip
    ) else (

        rem --- Ignore commentaires commen�ant par # ou ; ---
        echo !ligne! | findstr /r "^[#;]" >nul
        if errorlevel 1 (

            rem --- Extraction nom=valeur ---
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)

echo.
cd update

if "%update%"=="0" (
    exit
)

goto bypass
ping -n 1 google.com >nul 2>&1
if errorlevel 1 (
    exit
)
:bypass

for /f "tokens=2 delims=<>" %%A in ('findstr /i "<Version>" %localversion%.xml') do (
    set localVersion=%%A
)
curl --version >nul 2>&1
if %errorlevel%==0 (
    curl.exe -L -s %urldir%version.txt -o %onlineversion%.txt
) else (
    powershell -Command "Invoke-WebRequest '%urldir%version.txt' -OutFile '%onlineversion%.txt'"
)
exit