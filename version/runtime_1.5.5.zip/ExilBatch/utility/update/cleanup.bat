@echo off
exit
rmdir /s /q "%~dp0bin"
del /q %~dp0bin.zip
if exist setupinstalcomplet
move /q 7z.dll
move /q 7z.exe
move /q bar.ps1
move /q cleanup.bat
move /q curl.exe
move /q download.bat
move /q localinstall.zip
move /q runtime_version.xml
move /q update.ps1
exit > nul