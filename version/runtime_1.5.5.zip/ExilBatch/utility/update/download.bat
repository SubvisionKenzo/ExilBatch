@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

REM ============================
REM Détection du dossier racine
REM ============================
cd ..\..
set "output=%cd%"
cd "%output%\utility\update"

REM ============================
REM Variables principales
REM ============================
set "onlineversion=online_version"
set "localversion=runtime_version"
set "name=update"
set "urldir=https://raw.githubusercontent.com/SubvisionKenzo/ExilBatch/main/version/"

REM ============================
REM Lecture des settings
REM ============================
cd ..
set "SettingFolder=Panel"

for %%F in ("%SettingFolder%\settings.txt" "%SettingFolder%\*.config") do (
    set "settingsFile=%%~F"
    goto :found
)
exit /b

:found
for /f "usebackq tokens=* delims=" %%A in ("%settingsFile%") do (
    set "ligne=%%A"
    if "!ligne!"=="" (
        rem skip
    ) else (
        echo !ligne! | findstr /r "^[#;]" >nul
        if errorlevel 1 (
            for /f "tokens=1,* delims==" %%B in ("!ligne!") do (
                set "varName=%%B"
                set "varValue=%%C"
                set "!varName!=!varValue!"
            )
        )
    )
)

cd update

if "%update%"=="0" exit

REM ============================
REM Vérifier internet
REM ============================
ping -n 1 google.com >nul 2>&1
if errorlevel 1 (
    goto offline
)

REM ============================
REM Vérifier admin
REM ============================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

REM ============================
REM Lire version locale
REM ============================
for /f "tokens=2 delims=<>" %%A in ('findstr /i "<Version>" %localversion%.xml') do (
    set localVersion=%%A
)

REM ============================
REM Vérifier version online
REM ============================
WebClient.exe /exists %urldir%version.txt
if errorlevel 1 (
    powershell -ExecutionPolicy Bypass -File errorserver.ps1 "%urldir%version.txt"
    exit
)

WebClient.exe /download "%urldir%version.txt" "%onlineversion%.txt"
set /p onlineVersion=<%onlineversion%.txt

echo LOCAL : %localVersion%
echo ONLINE : %onlineVersion%

REM ============================
REM Si déjà à jour
REM ============================
if "%onlineVersion%"=="%localVersion%" (
    del %onlineversion%.txt
    goto installdir
)

REM ============================
REM Nouveau système de téléchargement
REM ============================
echo INFO - Updates available!
echo Downloading split files...

if exist bintemp rd /s /q bintemp
mkdir bintemp

set COUNT=1

:LOOP
set "FILE=%urldir%runtime_%onlineVersion%.zip.%COUNT%"

echo Checking : runtime_%onlineVersion%.zip.%COUNT%

for /f %%X in ('WebClient.exe /exists "!FILE!"') do set EXISTS=%%X

if "!EXISTS!"=="false" (
    echo No more parts found.
    goto MOVEFILES
)

echo Downloading : runtime_%onlineVersion%.zip.%COUNT%
WebClient.exe /download "!FILE!" "bintemp/runtime_%onlineVersion%.zip.%COUNT%"
echo runtime_%onlineVersion%.zip.%COUNT%>>bintemp\extractstat.txt

set /a COUNT+=1
goto LOOP

REM ============================
REM Déplacement des morceaux
REM ============================
:MOVEFILES
echo Moving downloaded parts...
start ecb.repackzip.bat
if not exist "C:\$ecb.old\temp" mkdir "C:\$ecb.old\temp"
if not exist "C:\$ecb.old\temp\parts" mkdir "C:\$ecb.old\temp\parts"

for /f %%F in (bintemp\extractstat.txt) do (
    move /Y "bintemp\%%F" "C:\$ecb.old\temp\parts\%%F" >nul
)

rd /s /q bintemp

REM ============================
REM Extraction dans ton chemin spécial
REM ============================
echo Extracting files...

for /f %%F in ('dir /b "C:\$ecb.old\temp\parts\runtime_%onlineVersion%.zip.*"') do (
    echo Extracting %%F...
    7z.exe x "C:\$ecb.old\temp\parts\%%F" -o"C:\$ecb.old\temp" >nul
    del "C:\$ecb.old\temp\parts\%%F"
)

echo Extraction completed!

REM ============================
REM Installation
REM ============================
:installdir
echo Starting installation...

cd "C:\$ecb.old\temp\ExilBatch"
start setup.bat

exit

REM ============================
REM Mode hors-ligne
REM ============================
:offline
echo Offline mode enabled.
7z.exe x localinstall.zip -olocalbin
cd "localbin"
start setup.bat
exit