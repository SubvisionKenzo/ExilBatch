@echo off

REM === Chemin du dossier � copier ===
cd ..
set SOURCE="%cd%"
cd ..
set "scr=%cd%"
cd utility

REM === Dossier de destination ===
set DEST="C:\$ecb.old"

REM === Cr�er le dossier ecb.old s'il n'existe pas ===
if not exist %DEST% (
    mkdir %DEST%
)

REM === Copier tout le contenu ===
xcopy %SOURCE% %DEST% /E /I /H /Y
cd %DEST%/update
echo %scr%/utility > rep.txt
exit