param(
    [string]$Url
)

# Détection de la langue Windows
$lang = (Get-Culture).TwoLetterISOLanguageName

# Messages multilingues
switch ($lang) {
    "fr" {
        $msgTitle = "Erreur"
        $msgBody  = "Impossible de vérifier ou de contacter le lien : `"$Url`"`nServeur : "
    }
    "en" {
        $msgTitle = "Error"
        $msgBody  = "Unable to verify or contact the link: `"$Url`"`nServer: "
    }
    "es" {
        $msgTitle = "Error"
        $msgBody  = "No se puede verificar o contactar el enlace: `"$Url`"`nServidor: "
    }
    "de" {
        $msgTitle = "Fehler"
        $msgBody  = "Der Link kann nicht überprüft oder kontaktiert werden: `"$Url`"`nServer: "
    }
    default {
        $msgTitle = "Error"
        $msgBody  = "Unable to verify or contact the link: `"$Url`"`nServer: "
    }
}

# Test du lien
try {
    $response = Invoke-WebRequest -Uri $Url -Method GET -ErrorAction Stop
    Write-Host "Le lien existe, code serveur : $($response.StatusCode)"
    exit 0
}
catch {
    $serverMsg = $_.Exception.Message

    # Affichage du message d’erreur
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($msgBody + $serverMsg, $msgTitle, "OK", "Error")

    # Lancer le batch d’erreur
    Start-Process "infoerrorserv.bat"

    exit 1
}