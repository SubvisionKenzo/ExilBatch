@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
set "rep=%1"
if exist "C:\$ecb.old" goto export
exit
:export
:: Expore data !
set "dir=C:\$ecb.old"
set "argcopy=/Y /E /I"
xcopy "%dir%\Panel" "%rep%\Panel" %argcopy%
xcopy "%dir%\$apps" "%rep%\$apps" %argcopy%
xcopy "%dir%\lang" "%rep%\lang" %argcopy%
xcopy "%dir%\assets\Tools" "%rep%\assets\Tools" %argcopy%
xcopy "%dir%\assets\save" "%rep%\assets\save" %argcopy%
xcopy "%dir%\assets\projet" "%rep%\assets\projet" %argcopy%
xcopy "%dir%\assets\Projects" "%rep%\assets\Projects" %argcopy%
xcopy "%dir%\assets\$~Envruntimes" "%rep%\assets\$~Envruntimes" %argcopy%
exit /b