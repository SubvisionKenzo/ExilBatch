@echo off

REM === Chemin du dossier � copier ===
set DEST="C:\$ecb.old"
set SOURCE="%cd%"
cd %DEST%

REM === Cr�er le dossier ecb.old s'il n'existe pas ===
if not exist %1 (
    mkdir %1
)

REM === Copier tout le contenu ===
xcopy %DEST% %1 /E /I /H /Y
exit