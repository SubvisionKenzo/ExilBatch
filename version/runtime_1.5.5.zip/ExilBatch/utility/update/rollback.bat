@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
cd ..\..
set "output=%cd%"
cd utility