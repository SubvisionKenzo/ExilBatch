@echo off
cd /d "%~dp0"
start window_update.bat
exit