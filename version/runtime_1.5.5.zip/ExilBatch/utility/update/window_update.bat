@echo off
cd /d "%~dp0"
:: Varriable !
set "name=window_update"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min window_update.bat
exit
:execut
del %hide%.txt
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul