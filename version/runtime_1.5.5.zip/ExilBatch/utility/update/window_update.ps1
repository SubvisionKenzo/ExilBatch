Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# --- Chemins de base ---
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$AssetsDir   = Join-Path $ScriptDir 'assets'
$OnlineFile  = Join-Path $ScriptDir 'online_version.txt'
$RuntimeFile = Join-Path $ScriptDir 'runtime_version.xml'
$UpdateCheck = Join-Path $ScriptDir 'Update_check.bat'
$UpdateStart = Join-Path $ScriptDir 'download.bat'  # � adapter si besoin

# --- 1. Lancer Update_check.bat et attendre ---
if (Test-Path $UpdateCheck) {
    Start-Process -FilePath $UpdateCheck -WorkingDirectory $ScriptDir -Wait
}

# --- 2. Lecture des versions ---
function Get-Versions {
    $online = $null
    $runtime = $null

    if (Test-Path $OnlineFile) {
        $online = (Get-Content $OnlineFile -ErrorAction SilentlyContinue | Select-Object -First 1).Trim()
        if ([string]::IsNullOrWhiteSpace($online)) { $online = $null }
    }

    if (Test-Path $RuntimeFile) {
        try {
            [xml]$xml = Get-Content $RuntimeFile -ErrorAction Stop
            $runtime = $xml.Runtime.Version.Trim()
            if ([string]::IsNullOrWhiteSpace($runtime)) { $runtime = $null }
        } catch {
            $runtime = $null
        }
    }

    [PSCustomObject]@{
        OnlineVersion  = $online
        RuntimeVersion = $runtime
    }
}

function Get-UpdateStatus {
    param(
        [string]$Online,
        [string]$Runtime
    )

    if (-not $Online -or -not $Runtime) {
        return 'Unknown'
    }

    if ($Online -eq $Runtime) {
        return 'UpToDate'
    } else {
        return 'UpdateAvailable'
    }
}

$versions = Get-Versions
$status   = Get-UpdateStatus -Online $versions.OnlineVersion -Runtime $versions.RuntimeVersion

$Lang = (Get-Culture).TwoLetterISOLanguageName

# --- Traductions ---
$Translations = @{
    fr = @{
        Title_UpToDate = "Vous �tes � jour"
        Title_Update   = "Une mise � jour est disponible"
        Title_Unknown  = "�tat de mise � jour inconnu"

        Status_UpToDate = "Version install�e : {0}"
        Status_Update   = "Install�e : {0}  �  En ligne : {1}"
        Status_Unknown  = "Impossible de lire les versions."

        Button_Update = "Installer la mise � jour"
        Update_Finished = "Mise � jour termin�e"
        BTN_GOBACK = "Revenir a l'encienne version"
    }

    en = @{
        Title_UpToDate = "You're up to date"
        Title_Update   = "An update is available"
        Title_Unknown  = "Update status unknown"

        Status_UpToDate = "Installed version: {0}"
        Status_Update   = "Installed: {0}  �  Online: {1}"
        Status_Unknown  = "Unable to read version files."

        Button_Update = "Install update"
        Update_Finished = "Update completed"
        BTN_GOBACK = "Go Back"
    }

    es = @{
        Title_UpToDate = "Est�s actualizado"
        Title_Update   = "Hay una actualizaci�n disponible"
        Title_Unknown  = "Estado de actualizaci�n desconocido"

        Status_UpToDate = "Versi�n instalada: {0}"
        Status_Update   = "Instalada: {0}  �  En l�nea: {1}"
        Status_Unknown  = "No se pueden leer los archivos."

        Button_Update = "Instalar actualizaci�n"
        Update_Finished = "Actualizaci�n completada"
        BTN_GOBACK = ""
    }

    de = @{
        Title_UpToDate = "Sie sind auf dem neuesten Stand"
        Title_Update   = "Ein Update ist verf�gbar"
        Title_Unknown  = "Update-Status unbekannt"

        Status_UpToDate = "Installierte Version: {0}"
        Status_Update   = "Installiert: {0}  �  Online: {1}"
        Status_Unknown  = "Versionsdateien k�nnen nicht gelesen werden."

        Button_Update = "Update installieren"
        Update_Finished = "Update abgeschlossen"
        BTN_GOBACK = ""
    }

    ru = @{
        Title_UpToDate = "? ??? ????????? ??????"
        Title_Update   = "???????? ??????????"
        Title_Unknown  = "?????? ?????????? ??????????"

        Status_UpToDate = "????????????? ??????: {0}"
        Status_Update   = "???????????: {0}  �  ??????: {1}"
        Status_Unknown  = "?? ??????? ????????? ????? ??????."

        Button_Update = "?????????? ??????????"
        Update_Finished = "?????????? ?????????"
        BTN_GOBACK = "<-"
    }
}

# S�lection automatique de la langue
$Lang = (Get-Culture).TwoLetterISOLanguageName
if (-not $Translations.ContainsKey($Lang)) { $Lang = "en" }
$T = $Translations[$Lang]

# --- 3. XAML de la fen�tre style Windows 11 ---
# Bouton arrondi, bordure violette, logo en haut, barre de progression ind�termin�e
$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Mises � jour"
        Width="520" Height="320"
        WindowStartupLocation="CenterScreen"
        Background="#1E1E1E" Foreground="White"
        ResizeMode="NoResize">

    <Grid Margin="20">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Bandeau haut -->
        <Border Grid.Row="0" Background="#262626" CornerRadius="12" Padding="12" Margin="0,0,0,12">
            <DockPanel>
                <Image x:Name="LogoImage" Width="48" Height="48" Margin="0,0,12,0"/>
                <StackPanel>
                    <TextBlock x:Name="TitleText" FontSize="18" FontWeight="Bold"/>
                    <TextBlock x:Name="StatusText" FontSize="13" Opacity="0.8"/>
                </StackPanel>
            </DockPanel>
        </Border>

        <!-- Zone centrale -->
        <StackPanel Grid.Row="1" VerticalAlignment="Center">
            <TextBlock Text="�tat de la mise � jour" FontSize="14" Margin="0,0,0,6"/>
            <ProgressBar x:Name="UpdateProgress"
                         Height="8"
                         Visibility="Collapsed"
                         IsIndeterminate="False"
                         Foreground="#C77DFF"
                         Background="#333333"/>
        </StackPanel>

        <!-- Bouton -->
        <StackPanel Grid.Row="2" HorizontalAlignment="Right">
            <Button x:Name="UpdateButton"
                    Content="Installer la mise � jour"
                    Padding="18,6"
                    Margin="0,16,0,0"
                    FontSize="14">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border"
                                CornerRadius="10"
                                BorderBrush="#C77DFF"
                                BorderThickness="2"
                                Background="#3A3A3A"
                                Padding="10,4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="border" Property="Opacity" Value="0.4"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#4A4A4A"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#5A3A7F"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Button.Template>
            </Button>
        </StackPanel>

        <!-- Overlay -->
        <Grid x:Name="Overlay"
              Background="#80000000"
              Visibility="Collapsed">
            <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">
                <Image x:Name="OverlayLogo" Width="72" Height="72" Margin="0,0,0,8"/>
                <TextBlock Text="Mise � jour termin�e" FontSize="16" FontWeight="Bold"/>
            </StackPanel>
        </Grid>

    </Grid>
</Window>
"@

# --- 4. Cr�ation de la fen�tre ---
$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

$LogoImage    = $window.FindName('LogoImage')
$TitleText    = $window.FindName('TitleText')
$StatusText   = $window.FindName('StatusText')
$UpdateButton = $window.FindName('UpdateButton')
$UpdateProg   = $window.FindName('UpdateProgress')
$Overlay      = $window.FindName('Overlay')
$OverlayLogo  = $window.FindName('OverlayLogo')
$RestoreButton  = $window.FindName('BTN_GOBACK')

# --- 5. Choix des logos selon l'�tat ---
function Set-ImageSource {
    param(
        [System.Windows.Controls.Image]$ImageControl,
        [string]$Path
    )
    if (Test-Path $Path) {
        $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit()
        $bmp.UriSource = New-Object System.Uri($Path)
        $bmp.CacheOption = 'OnLoad'
        $bmp.EndInit()
        $ImageControl.Source = $bmp
    }
}

switch ($status) {
    'UpToDate' {
        Set-ImageSource -ImageControl $LogoImage -Path (Join-Path $AssetsDir 'ok.png')
        $TitleText.Text  = $T.Title_UpToDate
        $StatusText.Text = [string]::Format($T.Status_UpToDate, $versions.RuntimeVersion)
        $UpdateButton.IsEnabled = $false
    }
    'UpdateAvailable' {
        Set-ImageSource -ImageControl $LogoImage -Path (Join-Path $AssetsDir 'update.png')
        $TitleText.Text  = $T.Title_Update
        $StatusText.Text = [string]::Format($T.Status_Update, $versions.RuntimeVersion, $versions.OnlineVersion)
        $UpdateButton.IsEnabled = $true
    }
    default {
        Set-ImageSource -ImageControl $LogoImage -Path (Join-Path $AssetsDir 'unknown.png')
        $TitleText.Text  = $T.Title_Unknown
        $StatusText.Text = $T.Status_Unknown
        $UpdateButton.IsEnabled = $true
    }
}

$UpdateButton.Content = $T.Button_Update
$OverlayLogo.ToolTip = $T.Update_Finished

# Logo overlay = logo update
Set-ImageSource -ImageControl $OverlayLogo -Path (Join-Path $AssetsDir 'update.png')

# --- 6. Animation simple de fin (overlay + fermeture apr�s 1,5 s) ---
function Show-EndAnimation {
    $Overlay.Visibility = 'Visible'

    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromSeconds(1.5)
    $timer.Add_Tick({
        $timer.Stop()
        $window.Close()
    })
    $timer.Start()
}

# --- 7. Clic sur le bouton de mise � jour ---
$UpdateButton.Add_Click({
    if (-not (Test-Path $UpdateStart)) {
        [System.Windows.MessageBox]::Show("Le fichier $UpdateStart est introuvable.","Erreur", 'OK', 'Error') | Out-Null
        return
    }

    # Barre de progression style Windows 11 (ind�termin�e)
    $UpdateProg.Visibility      = 'Visible'
    $UpdateProg.IsIndeterminate = $true
    $UpdateButton.IsEnabled     = $false

    # Lancer le script d'update et attendre
    $ps = [System.Diagnostics.ProcessStartInfo]::new()
    $ps.FileName         = $UpdateStart
    $ps.WorkingDirectory = $ScriptDir
    $ps.UseShellExecute  = $true

    $proc = [System.Diagnostics.Process]::Start($ps)
    $jobTimer = New-Object System.Windows.Threading.DispatcherTimer
    $jobTimer.Interval = [TimeSpan]::FromMilliseconds(500)
    $jobTimer.Add_Tick({
        if ($proc.HasExited) {
            $jobTimer.Stop()
            $UpdateProg.IsIndeterminate = $false
            $UpdateProg.Visibility      = 'Collapsed'
            Show-EndAnimation
        }
    })
    $jobTimer.Start()
})

# --- CONFIG RESTORE ---
$RestoreFolder = "C:\$ecb.old"
$RepFile       = "C:\$ecb.old\update\rep.txt"
$GoBackBat     = Join-Path $ScriptDir "goback.bat"
$OriginalPath  = Get-Location

# --- AJOUT DU BOUTON RESTAURATION ---
$RestoreButton = New-Object System.Windows.Controls.Button
$RestoreButton.Content = "GOBACK"
$RestoreButton.Padding = "18,6"
$RestoreButton.Margin  = "0,10,0,0"
$RestoreButton.FontSize = 14

# Style identique au bouton Update
$RestoreButton.Template = $UpdateButton.Template

# Ajouter le bouton sous le bouton Update
($UpdateButton.Parent).Children.Add($RestoreButton)

# --- V�rification du dossier ---
if (Test-Path $RestoreFolder) {
    $RestoreButton.IsEnabled = $true
} else {
    $RestoreButton.IsEnabled = $false
}

# --- Action du bouton Restaurer ---
$RestoreButton.Add_Click({
    try {
        if (-not (Test-Path $RepFile)) {
            [System.Windows.MessageBox]::Show("Error del rep.txt.","Error",'OK','Error') | Out-Null
            return
        }

        # Lire l'argument
        $Argument = (Get-Content $RepFile | Select-Object -First 1).Trim()

        # Supprimer rep.txt
        Remove-Item $RepFile -Force

        # Revenir au dossier d'origine
        Set-Location $OriginalPath

        # Lancer goback.bat avec l'argument
        Start-Process $GoBackBat -ArgumentList $Argument

        # Fermer la fen�tre
        $window.Close()
    }
    catch {
        [System.Windows.MessageBox]::Show("Erreur : $($_.Exception.Message)","Erreur",'OK','Error') | Out-Null
    }
})

# --- 8. Afficher la fen�tre ---
$window.ShowDialog() | Out-Null