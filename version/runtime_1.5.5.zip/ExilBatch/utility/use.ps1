# R�cup�rer tous les arguments bruts
$raw = $args

# Dictionnaire final
$map = @{
    LIB  = ""
    FUNC = ""
    ARG  = ""
    OUT  = ""
    MOV  = ""
}

# Reconstruction automatique
$currentKey = ""
foreach ($item in $raw) {

    if ($item -match "=") {
        # Nouvelle cl�
        $parts = $item.Split("=", 2)
        $currentKey = $parts[0]
        $map[$currentKey] = $parts[1]
    }
    else {
        if ($currentKey -eq "ARG") {
            $map["ARG"] += " $item"
        }
    }
}

# Charger JSON
$jsonPath = Join-Path $PSScriptRoot "function.json"
$json = Get-Content $jsonPath -Raw | ConvertFrom-Json

# R�cup�rer la librairie et la fonction
$LIB  = $map["LIB"]
$FUNC = $map["FUNC"]
$ARG  = $map["ARG"]
$OUT  = $map["OUT"]
$MOV  = $map["MOV"]

if (-not $json.$LIB) {
    Write-Host "LIB --> '$LIB' not found" -ForegroundColor Red
    exit
}

$template = $json.$LIB.$FUNC
if (-not $template) {
    Write-Host "FUNC --> '$FUNC' not found in '$LIB'" -ForegroundColor Red
    exit
}

# D�couper les arguments
$argsList = $ARG.Trim().Split(" ")

# Remplacer _1_, _2_, _3_...
for ($i = 0; $i -lt $argsList.Count; $i++) {
    $template = $template.Replace("_$($i+1)_", $argsList[$i])
}

# �crire ou ajouter le fichier
if (Test-Path $OUT) {
    Add-Content -Path $OUT -Value $template -Encoding UTF8
}
else {
    Out-File -FilePath $OUT -InputObject $template -Encoding UTF8
}

Write-Host "OUTPUT FILE : $OUT" -ForegroundColor Green

# D�placement
if ($MOV -ne "") {

    $destFile = Join-Path $MOV (Split-Path $OUT -Leaf)

    # Si le fichier existe d�j� -> on ajoute
    if (Test-Path $destFile) {
        Add-Content -Path $destFile -Value $template -Encoding UTF8
        Write-Host "APPENDED TO : $destFile" -ForegroundColor Yellow
    }
    else {
        # Sinon -> on cr�e le fichier
        Out-File -FilePath $destFile -InputObject $template -Encoding UTF8
        Write-Host "CREATED : $destFile" -ForegroundColor Yellow
    }

    # On supprime le fichier temporaire OUT
    Remove-Item $OUT -Force

    exit
}