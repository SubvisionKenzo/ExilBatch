# ================================
# wingui.ps1
# Moteur JSON -> GUI (avec lib.txt)
# ================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

public class RoundButton : Button
{
    public int Radius = 20;

    protected override void OnPaint(PaintEventArgs e)
    {
        GraphicsPath path = new GraphicsPath();
        path.AddArc(0, 0, Radius, Radius, 180, 90);
        path.AddArc(Width - Radius, 0, Radius, Radius, 270, 90);
        path.AddArc(Width - Radius, Height - Radius, Radius, Radius, 0, 90);
        path.AddArc(0, Height - Radius, Radius, Radius, 90, 90);
        path.CloseFigure();

        this.Region = new Region(path);
        base.OnPaint(e);
    }
}
"@

# ----------------
# 1. Lecture args
# ----------------
if ($args.Count -lt 1) {
    [System.Windows.Forms.MessageBox]::Show("Aucun fichier JSON fourni.","wingui.ps1")
    exit
}

$jsonPath = $args[0]

if (-not (Test-Path $jsonPath)) {
    [System.Windows.Forms.MessageBox]::Show("Fichier JSON introuvable : `n$jsonPath","wingui.ps1")
    exit
}

# ----------------
# 2. Lecture lib.txt
# ----------------
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$libPath   = Join-Path $scriptDir "lib.txt"

if (-not (Test-Path $libPath)) {
    [System.Windows.Forms.MessageBox]::Show("Fichier lib.txt introuvable dans : `n$scriptDir","wingui.ps1")
    exit
}

$NormalizeMap = @{}

Get-Content $libPath | ForEach-Object {
    $line = $_.Trim()
    if ([string]::IsNullOrWhiteSpace($line)) { return }
    if ($line.StartsWith("#")) { return }

    $parts = $line -split "=", 2
    if ($parts.Count -ne 2) { return }

    $canonical = $parts[0].Trim().ToLower()
    $aliases   = $parts[1].Split(",") | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ -ne "" }

    if (-not $NormalizeMap.ContainsKey($canonical)) {
        $NormalizeMap[$canonical] = @()
    }

    $NormalizeMap[$canonical] += $aliases
    $NormalizeMap[$canonical] = $NormalizeMap[$canonical] | Select-Object -Unique
}

# ----------------
# 3. Fonction de normalisation
# ----------------
function Normalize-Type {
    param(
        [string]$raw
    )

    if ([string]::IsNullOrWhiteSpace($raw)) {
        return $null
    }

    $clean = $raw.Trim().ToLower()

    foreach ($key in $NormalizeMap.Keys) {
        if ($NormalizeMap[$key] -contains $clean -or $key -eq $clean) {
            return $key
        }
    }

    # Fallback : chercher le plus proche en longueur
    $closest = $NormalizeMap.Keys | Sort-Object {
        [System.Math]::Abs($_.Length - $clean.Length)
    } | Select-Object -First 1

    return $closest
}

# ----------------
# 4. Lecture du JSON
# ----------------
try {
    $json = Get-Content $jsonPath -Raw | ConvertFrom-Json
} catch {
    [System.Windows.Forms.MessageBox]::Show("Erreur de lecture JSON : `n$($_.Exception.Message)","wingui.ps1")
    exit
}

if (-not $json.window) {
    [System.Windows.Forms.MessageBox]::Show("Section 'window' manquante dans le JSON.","wingui.ps1")
    exit
}

# ----------------
# 5. Cr�ation de la fen�tre
# ----------------
$win = $json.window

$form = New-Object System.Windows.Forms.Form

# Titre
if ($win.PSObject.Properties.Name -contains "title") {
    $form.Text = [string]$win.title
} else {
    $form.Text = "Window"
}

# Lecture du son
if ($win.PSObject.Properties.Name -contains "playSound") {
    $snd = $win.playSound

    if ($snd.file) {
        $soundPath = $snd.file
        if (-not [System.IO.Path]::IsPathRooted($soundPath)) {
            $soundPath = Join-Path $scriptDir $soundPath
        }

        if (Test-Path $soundPath) {
            $player = New-Object System.Media.SoundPlayer $soundPath

            if ($snd.loop -eq $true) {
                $form.Add_Shown({ $player.PlayLooping() })
            } else {
                $form.Add_Shown({ $player.Play() })
            }
        }
    }
}

# Taille
if ($win.PSObject.Properties.Name -contains "width") {
    $form.Width = [int]$win.width
} else {
    $form.Width = 600
}
if ($win.PSObject.Properties.Name -contains "height") {
    $form.Height = [int]$win.height
} else {
    $form.Height = 400
}

# Couleur de fond
if ($win.PSObject.Properties.Name -contains "background") {
    try {
        $form.BackColor = [System.Drawing.ColorTranslator]::FromHtml($win.background)
    } catch {
        $form.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)
    }
} else {
    $form.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)
}

# Police
$fontName = "Segoe UI"
$fontSize = 10

if ($win.PSObject.Properties.Name -contains "fontSize") {
    $fontSize = [float]$win.fontSize
}

if ($win.PSObject.Properties.Name -contains "font") {
    $fontRaw = [string]$win.font

    if ($fontRaw.StartsWith("/")) {
        # Police personnalis�e dans le dossier Fonts
        $fontFile = $fontRaw.TrimStart("/")
        $fontPath = Join-Path $scriptDir "Fonts\$fontFile"

        if (Test-Path $fontPath) {
            Add-Type -AssemblyName System.Drawing
            $privateFonts = New-Object System.Drawing.Text.PrivateFontCollection
            $privateFonts.AddFontFile($fontPath)
            $fontFamily = $privateFonts.Families[0]
            $form.Font = New-Object System.Drawing.Font($fontFamily, $fontSize)
        } else {
            $form.Font = New-Object System.Drawing.Font("Segoe UI", $fontSize)
        }
    } else {
        # Police syst�me classique
        try {
            $form.Font = New-Object System.Drawing.Font($fontRaw, $fontSize)
        } catch {
            $form.Font = New-Object System.Drawing.Font("Segoe UI", $fontSize)
        }
    }
}

$form.StartPosition = "CenterScreen"

# ----------------
# 6. Cr�ation des contr�les
# ----------------
$ControlsByName = @{}

if ($json.controls) {
    foreach ($ctrl in $json.controls) {

        if (-not $ctrl.type) { continue }

        $type = Normalize-Type $ctrl.type
        if (-not $type) { continue }

        $obj = $null

        switch ($type) {

            "label" {
                $obj = New-Object System.Windows.Forms.Label
                if ($ctrl.PSObject.Properties.Name -contains "text") {
                    $obj.Text = [string]$ctrl.text
                }
                $obj.AutoSize = $true
            }

            "button" {
                if ($ctrl.round -eq $true) {
                    $obj = New-Object RoundButton
                } else {
                    $obj = New-Object System.Windows.Forms.Button
                }
                if ($ctrl.PSObject.Properties.Name -contains "text") {
                    $obj.Text = [string]$ctrl.text
                }

                # Actions simples (safe)
                if ($ctrl.PSObject.Properties.Name -contains "action") {
                    $action = $ctrl.action
                    if ($action -and $action.type) {
                        $actType = ($action.type).ToString().ToLower()

                        switch ($actType) {

                            "message" {
                                $msg = [string]$action.value
                                $obj.Add_Click({
                                    [System.Windows.Forms.MessageBox]::Show($msg)
                                })
                            }

                            "url" {
                                $url = [string]$action.value
                                $obj.Add_Click({
                                    try { Start-Process $url } catch {}
                                })
                            }
                        }
                    }
                }
            }

            "textbox" {
                $obj = New-Object System.Windows.Forms.TextBox
                if ($ctrl.PSObject.Properties.Name -contains "width") {
                    $obj.Width = [int]$ctrl.width
                } else {
                    $obj.Width = 150
                }
                if ($ctrl.PSObject.Properties.Name -contains "placeholder") {
                    $obj.Text = [string]$ctrl.placeholder
                    $obj.ForeColor = [System.Drawing.Color]::Gray
                    $obj.Add_GotFocus({
                        if ($obj.ForeColor -eq [System.Drawing.Color]::Gray) {
                            $obj.Text = ""
                            $obj.ForeColor = [System.Drawing.Color]::White
                        }
                    })
                }
            }

            "checkbox" {
                $obj = New-Object System.Windows.Forms.CheckBox
                if ($ctrl.PSObject.Properties.Name -contains "text") {
                    $obj.Text = [string]$ctrl.text
                }
                if ($ctrl.PSObject.Properties.Name -contains "checked") {
                    $obj.Checked = [bool]$ctrl.checked
                }
                $obj.AutoSize = $true
            }

            "image" {
                $obj = New-Object System.Windows.Forms.PictureBox
                $obj.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage

                if ($ctrl.PSObject.Properties.Name -contains "source") {
                    $imgPath = [string]$ctrl.source
                    if (-not [System.IO.Path]::IsPathRooted($imgPath)) {
                        $imgPath = Join-Path $scriptDir $imgPath
                    }
                    if (Test-Path $imgPath) {
                        try { $obj.Image = [System.Drawing.Image]::FromFile($imgPath) } catch {}
                    }
                }
            }

            default {
                # Type inconnu -> on ignore
                continue
            }
        }

        if (-not $obj) { continue }

        # Nom (optionnel)
        if ($ctrl.PSObject.Properties.Name -contains "name") {
            $name = [string]$ctrl.name
            $obj.Name = $name
            $ControlsByName[$name] = $obj
        }

        # Position
        if ($ctrl.PSObject.Properties.Name -contains "left") {
            $obj.Left = [int]$ctrl.left
        }
        if ($ctrl.PSObject.Properties.Name -contains "top") {
            $obj.Top = [int]$ctrl.top
        }

        # Taille
        if ($ctrl.PSObject.Properties.Name -contains "width") {
            $obj.Width = [int]$ctrl.width
        }
        if ($ctrl.PSObject.Properties.Name -contains "height") {
            $obj.Height = [int]$ctrl.height
        }

        # Couleurs
        if ($ctrl.PSObject.Properties.Name -contains "color") {
            try {
                $obj.BackColor = [System.Drawing.ColorTranslator]::FromHtml($ctrl.color)
            } catch {}
        }
        if ($ctrl.PSObject.Properties.Name -contains "textColor") {
            try {
                $obj.ForeColor = [System.Drawing.ColorTranslator]::FromHtml($ctrl.textColor)
            } catch {}
        }

        $form.Controls.Add($obj)
    }
}

# ----------------
# 7. Affichage
# ----------------
[void]$form.ShowDialog()