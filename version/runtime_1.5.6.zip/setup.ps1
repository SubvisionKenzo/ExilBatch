Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================
# CONFIG
# ============================

$BasePath    = Split-Path -Parent $MyInvocation.MyCommand.Definition
$LicenseFile = Join-Path $BasePath "licence.txt"
$SideImage   = Join-Path $BasePath "logo.png"
$IconFile    = Join-Path $BasePath "setup.ico"

# ============================
# DETECTION THEME WINDOWS
# ============================

$ThemeKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
$IsLight = 1

try {
    $IsLight = (Get-ItemProperty -Path $ThemeKey -Name AppsUseLightTheme).AppsUseLightTheme
} catch {}

$DarkMode = ($IsLight -eq 0)

# ============================
# DETECTION LANGUE WINDOWS
# ============================

$Lang = (Get-Culture).TwoLetterISOLanguageName

switch ($Lang) {
    "fr" { $L = "FR" }
    "es" { $L = "ES" }
    default { $L = "EN" }
}

# ============================
# CHARGEMENT DES LANGUES
# ============================

function Load-LanguageFile {
    param($langCode)

    $langFile = Join-Path $BasePath "lang\$langCode.lang"

    if (-not (Test-Path $langFile)) {
        $langFile = Join-Path $BasePath "lang\EN.lang"
    }

    $Global:LANGDATA = @{}

    foreach ($line in Get-Content $langFile) {
        if ($line -match "^\s*$") { continue }
        if ($line -match "^\s*#") { continue }
        $parts = $line -split "=", 2
        if ($parts.Count -eq 2) {
            $Global:LANGDATA[$parts[0]] = $parts[1]
        }
    }
}

function T {
    param($key)
    if ($Global:LANGDATA.ContainsKey($key)) {
        return $Global:LANGDATA[$key]
    }
    return $key
}

# Charger la langue détectée
Load-LanguageFile $L

# ============================
# FENÊTRE PRINCIPALE
# ============================

$form = New-Object Windows.Forms.Form
$form.Text = "Setup"
$form.Size = New-Object Drawing.Size(630, 480)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [Drawing.Color]::White

if (Test-Path $IconFile) {
    $form.Icon = New-Object System.Drawing.Icon($IconFile)
}

# ============================
# BANDE GAUCHE
# ============================

$panelLeft = New-Object Windows.Forms.Panel
$panelLeft.Width = 160
$panelLeft.Dock  = 'Left'
$panelLeft.BackColor = [Drawing.Color]::FromArgb(230,230,230)
$form.Controls.Add($panelLeft)

if (Test-Path $SideImage) {
    $pic = New-Object Windows.Forms.PictureBox
    $pic.Image = [System.Drawing.Image]::FromFile($SideImage)
    $pic.Dock = 'Fill'
    $panelLeft.Controls.Add($pic)
}

# ============================
# BANDE BAS (FOOTER)
# ============================

$footer = New-Object Windows.Forms.Panel
$footer.Height = 55
$footer.Dock   = 'Bottom'
$footer.BackColor = [Drawing.Color]::FromArgb(230,230,230)
$form.Controls.Add($footer)

$line = New-Object Windows.Forms.Label
$line.BorderStyle = 'Fixed3D'
$line.Height = 2
$line.Dock   = 'Top'
$form.Controls.Add($line)

# Bouton Fermer
$btnClose = New-Object Windows.Forms.Button
$btnClose.Text = T "BTN_CANCEL"
$btnClose.Size = "80,30"
$btnClose.Location = "500,12"
$btnClose.Add_Click({ $form.Close() })
$footer.Controls.Add($btnClose)

# ============================
# PANNEAU CENTRAL
# ============================

$panelMain = New-Object Windows.Forms.Panel
$panelMain.Left   = 170
$panelMain.Top    = 10
$panelMain.Width  = 520
$panelMain.Height = 380
$form.Controls.Add($panelMain)

# ============================
# PAGE UNIQUE : LICENCE
# ============================

$pageLicense = New-Object Windows.Forms.Panel
$pageLicense.Dock = 'Fill'
$pageLicense.BackColor = 'White'

# Titre
$lblTitle = New-Object Windows.Forms.Label
$lblTitle.Text = T "LICENSE_TITLE"
$lblTitle.Font = New-Object Drawing.Font("Segoe UI", 14, [Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $true
$lblTitle.Location = "10,10"
$pageLicense.Controls.Add($lblTitle)

# Texte licence
$txtLicense = New-Object Windows.Forms.TextBox
$txtLicense.Multiline = $true
$txtLicense.ScrollBars = 'Vertical'
$txtLicense.ReadOnly = $true
$txtLicense.Size = "430,260"
$txtLicense.Location = "10,50"
$txtLicense.Font = New-Object Drawing.Font("Segoe UI", 9)

if (Test-Path $LicenseFile) {
    $txtLicense.Text = Get-Content $LicenseFile -Raw
} else {
    $txtLicense.Text = "Not found licence.txt"
}

$pageLicense.Controls.Add($txtLicense)

# Lien vers site
$linkSite = New-Object Windows.Forms.Label
$linkSite.Text = T "OPEN_WEBSITE"
$linkSite.Font = New-Object Drawing.Font("Segoe UI", 9, [Drawing.FontStyle]::Underline)
$linkSite.ForeColor = [Drawing.Color]::FromArgb(0, 102, 204)
$linkSite.AutoSize = $true
$linkSite.Location = "10,330"
$linkSite.Cursor = [System.Windows.Forms.Cursors]::Hand

$linkSite.Add_MouseEnter({
    $linkSite.ForeColor = [Drawing.Color]::FromArgb(30, 144, 255)
})
$linkSite.Add_MouseLeave({
    $linkSite.ForeColor = [Drawing.Color]::FromArgb(0, 102, 204)
})
$linkSite.Add_Click({
    $htmlFile = Join-Path $BasePath "link\index.html"
    if (Test-Path $htmlFile) {
        Start-Process $htmlFile
    } else {
        [System.Windows.Forms.MessageBox]::Show("index.html not found in /link/")
    }
})

$pageLicense.Controls.Add($linkSite)

# Ajouter la page au panel principal
$panelMain.Controls.Add($pageLicense)

# ============================
# THEME SOMBRE (ADAPTATION)
# ============================

if ($DarkMode) {

    $bgDark  = [Drawing.Color]::FromArgb(25,25,25)
    $bgPanel = [Drawing.Color]::FromArgb(35,35,35)
    $bgMode  = [Drawing.Color]::FromArgb(250,250,250)
    $fgText  = [Drawing.Color]::White

    $form.BackColor = $bgMode
    $form.ForeColor = $bgDark

    $panelLeft.BackColor = $bgPanel
    $footer.BackColor    = $bgPanel
    $line.BackColor      = $bgPanel

    $pageLicense.BackColor = $bgDark

    $lblTitle.ForeColor    = $fgText
    $txtLicense.BackColor  = [Drawing.Color]::FromArgb(45,45,45)
    $txtLicense.ForeColor  = $fgText

    $linkSite.BackColor    = $bgDark
    $linkSite.ForeColor    = [Drawing.Color]::FromArgb(0, 153, 255)

    $btnClose.BackColor    = $bgPanel
    $btnClose.ForeColor    = $fgText
    $btnClose.FlatStyle    = 'Flat'
    $btnClose.FlatAppearance.BorderColor = $fgText
}

# ============================
# LANCEMENT
# ============================

$form.ShowDialog()